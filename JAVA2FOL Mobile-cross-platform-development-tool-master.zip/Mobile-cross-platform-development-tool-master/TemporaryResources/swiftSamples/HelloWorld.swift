print("Hello, world!")

