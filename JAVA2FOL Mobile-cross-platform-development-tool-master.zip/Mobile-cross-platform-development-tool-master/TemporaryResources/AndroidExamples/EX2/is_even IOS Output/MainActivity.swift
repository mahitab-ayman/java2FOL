import UIKit


 class MainActivity: UIViewController{
	@IBOutlet weak var edt1:UITextField!, edt2:UITextField!
	@IBOutlet weak var btn:UIButton!

	override internal func viewDidLoad() {
		super.viewDidLoad()
		btn.removeTarget(nil, action: nil, for: .allEvents)
		btn.addTarget(self, action: #selector(targetMethod0), for: .touchUpInside)
	}

	@objc func targetMethod0(_ sender: UIButton){
		var n1String:String = edt1.text!
		var n2String:String = edt2.text!
		var n1:Int = Int(n1String)!
		var n2:Int = Int(n2String)!
		if n1 % 2 == 0 && n2 % 2 == 0 {
		print("Both are even")
		}
		if n1 % 2 == 0 || n2 % 2 == 0 {
		print("any one can be even")
		}
	}
}