//
//  ViewController.swift
//  functionSolver2
//
//  Created by user152566 on 4/16/19.
//  Copyright © 2019 user152566. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    private var a_value:Int = 0
    private var b_value:Int = 0
    private var c_value:Int = 0
    @IBOutlet weak var editTextA:UITextField!
    @IBOutlet weak var editTextB:UITextField!
    @IBOutlet weak var editTextC:UITextField!
    @IBOutlet weak var x1TextView:UILabel!
    @IBOutlet weak var x2TextView:UILabel!
    
    override internal func viewDidLoad() {
        super.viewDidLoad()
        editTextA.removeTarget(nil, action: nil, for: .allEvents)
        editTextA.addTarget(self, action: #selector(targetMethod0(_:)), for: .editingChanged)
        editTextB.removeTarget(nil, action: nil, for: .allEvents)
        editTextB.addTarget(self, action: #selector(targetMethod1(_:)), for: .editingChanged)
        editTextC.removeTarget(nil, action: nil, for: .allEvents)
        editTextC.addTarget(self, action: #selector(targetMethod2(_:)), for: .editingChanged)
    }
    
    private func setNewValues() {
        var determinant:Double = pow(Double(b_value),Double(2)) - Double(4 * a_value * c_value)
        var x1:String = "", x2:String = ""
        if determinant > 0 {
            x1 = "String((b_value - 1 + sqrt(Double(determinant))) / (2 * a_value))"
            x2 = "String((b_value - 1 - sqrt(Double(determinant))) / (2 * a_value))"
        } else if determinant == 0 {
            x1 = String(b_value - 1 / (2 * a_value))
            x2 = x1
        } else {
            x1 = "b_value - 1 / (2 * a_value) +  + sqrt(Double((determinant -= 1) / (2 * a_value)))"
            x2 = "b_value - 1 / (2 * a_value) + + sqrt(Double(determinant -= 1)) / (2 * a_value)"
        }
        x1TextView.text = x1
        x2TextView.text = x2
    }
    
    @objc func targetMethod0(_ editable:UITextField){
        if editable.text!.count != 0 {
            a_value = Int(editable.text!)!
        } else {
            a_value = 0
        }
        setNewValues()
    }
    @objc func targetMethod1(_ editable:UITextField){
        if editable.text!.count != 0 {
            b_value = Int(editable.text!)!
        } else {
            b_value = 0
        }
        setNewValues()
    }
    @objc func targetMethod2(_ editable:UITextField){
        if editable.text!.count != 0 {
            c_value = Int(editable.text!)!
        } else {
            c_value = 0
        }
        setNewValues()
    }

}

