import UIKit


 class MainActivity: UIViewController{

	override internal func viewDidLoad() {
		super.viewDidLoad()
		var key:String = "theme"
		var value:String = "red"
		saveIntoSharedPreferences(key, value)
		var themeValue:String = readFromSharedPreference(key)
	}

	private func saveIntoSharedPreferences(key:String, value:String) {
		var sharedPref = UserDefaults.standard
		sharedPref.setValue(value, forKey: key)
	}

	private func readFromSharedPreference(key:String) -> String{
		var sharedPref = UserDefaults.standard
		var defaultValue:String = ""
		guard let value:String = sharedPref.string(forKey: key) else { return defaultValue }
		return value
	}

}