import UIKit

 class MainActivity: UIViewController{

	override internal func viewDidLoad() {
		super.viewDidLoad()
		var url:String = "https://www.twitter.com"
		performSegue(withIdentifier: "FromnullTonullID", sender: nil)
	}

}