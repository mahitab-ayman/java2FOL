import UIKit


 class MainActivity: UIViewController{
	private var a_value:Double = 0.0
	private var b_value:Double = 0.0
	private var c_value:Double = 0.0
	@IBOutlet weak var editTextA:UITextField!
	@IBOutlet weak var editTextB:UITextField!
	@IBOutlet weak var editTextC:UITextField!
	@IBOutlet weak var x1TextView:UILabel!
	@IBOutlet weak var x2TextView:UILabel!

	override internal func viewDidLoad() {
		super.viewDidLoad()
		//todo Convert: editTextA.addTextChangedListener(new TextWatcher() {
		            @Override
		            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
		
		            }
		
		            @Override
		            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
		
		            }
		
		            @Override
		            public void afterTextChanged(Editable editable) {
		                if (editable.length() != 0)
		                    a_value = Double.parseDouble(editable.toString());
		                else {
		                    a_value = 0;
		                }
		                setNewValues();
		            }
		        });
		
		//todo Convert: editTextB.addTextChangedListener(new TextWatcher() {
		            @Override
		            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
		
		            }
		
		            @Override
		            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
		
		            }
		
		            @Override
		            public void afterTextChanged(Editable editable) {
		                if (editable.length() != 0)
		                    b_value = Double.parseDouble(editable.toString());
		                else {
		                    b_value = 0;
		                }
		                setNewValues();
		
		            }
		        });
		
		//todo Convert: editTextC.addTextChangedListener(new TextWatcher() {
		            @Override
		            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
		
		            }
		
		            @Override
		            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
		
		            }
		
		            @Override
		            public void afterTextChanged(Editable editable) {
		                if (editable.length() != 0)
		                    c_value = Double.parseDouble(editable.toString());
		                else {
		                    c_value = 0;
		                }
		                setNewValues();
		
		            }
		        });
		
	}

	private func setNewValues() {
		//todo Convert: double determinant = Math.pow(b_value,2) - 4*a_value*c_value;
		
		var x1:String = "", x2:String = ""
		if determinant > 0 {
					var temp1:Double = -b_value / (2 * a_value)
					//todo Convert: double temp2 = Math.sqrt(determinant)/(2*a_value);
					
					//todo Convert: x1 = String.valueOf((temp1+temp2));
					
					//todo Convert: x2 = String.valueOf(temp1-temp2);
					
				} else if determinant == 0 {
					//todo Convert: x1 = String.valueOf(-b_value/(2*a_value));
					
					x2 = x1
				} else {
					//todo Convert: x1 =  -b_value/(2*a_value) + "+i" +
					                    Math.sqrt(-determinant)/(2*a_value)  ;
					
					//todo Convert: x2 = -b_value/(2*a_value) + "-i" + Math.sqrt(-determinant)/(2*a_value);
					
				}
		x1TextView.text = x1
		x2TextView.text = x2
	}

}