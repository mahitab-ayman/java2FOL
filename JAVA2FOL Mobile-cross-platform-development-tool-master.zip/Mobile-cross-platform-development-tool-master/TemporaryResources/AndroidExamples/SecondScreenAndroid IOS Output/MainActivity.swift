import UIKit


 class MainActivity: UIViewController{
	@IBOutlet weak var button:UIButton!

	override public func viewDidLoad() {
		super.viewDidLoad()
		button.removeTarget(nil, action: nil, for: .allEvents)
		button.addTarget(self, action: #selector(targetMethod0), for: .touchUpInside)
	}

	@objc func targetMethod0(_ sender: UIButton){
		performSegue(withIdentifier: "FromMainActivityToMain2ActivityID", sender: nil)
	}
}