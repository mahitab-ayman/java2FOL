import UIKit


 class Main2Activity: UIViewController{
	@IBOutlet weak var button2:UIButton!

	override public func viewDidLoad() {
		super.viewDidLoad()
		button2.removeTarget(nil, action: nil, for: .allEvents)
		button2.addTarget(self, action: #selector(targetMethod0), for: .touchUpInside)
	}

	@objc func targetMethod0(_ sender: UIButton){
		performSegue(withIdentifier: "FromMain2ActivityToMainActivityID", sender: nil)
	}
}