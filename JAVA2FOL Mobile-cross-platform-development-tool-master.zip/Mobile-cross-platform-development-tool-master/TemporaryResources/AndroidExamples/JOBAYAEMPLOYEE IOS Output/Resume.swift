import UIKit


 class Resume{
	var occupation:String = ""
	var exp:String = ""
	var skills:String = ""
	var gender:String = ""
	init(ocp:String, exp:String, skills:String, gender:String)  {
	self.occupation = ocp
	self.exp = exp
	self.skills = skills
	self.gender = gender

 }

}