import UIKit


 class SignupActivity: UIViewController{
	@IBOutlet weak var fullNameTxt:UITextField!
	@IBOutlet weak var userNameTxt:UITextField!
	@IBOutlet weak var passwordTxt:UITextField!
	@IBOutlet weak var passAgainTxt:UITextField!
	@IBOutlet weak var emailTxt:UITextField!
	@IBOutlet weak var ageTxt:UITextField!
	//todo Convert: ToggleSwitch genderSelector;

	override internal func viewDidLoad() {
		super.viewDidLoad()
	}

	public func createAccount(//todo Convert: View  v
	) {
		if //todo Convert: fullNameTxt.getText().toString().equals("")
		 || //todo Convert: userNameTxt.getText().toString().equals("")
		 || //todo Convert: passwordTxt.getText().toString().equals("")
		 || //todo Convert: passAgainTxt.getText().toString().equals("")
		 || //todo Convert: emailTxt.getText().toString().equals("")
		 || //todo Convert: ageTxt.getText().toString().equals("")
		 {
					//todo Convert: Toast.makeText(this, "please fill all the fields", Toast.LENGTH_SHORT).show();
					
				} else {
					if //todo Convert: passwordTxt.getText().toString().equals(passAgainTxt.getText().toString())
					 {
									var gender:String = ""
									//todo Convert: if(genderSelector.getCheckedTogglePosition() == 0)
									                {
									                    gender = "male";
									                }
									                else {
									                    gender = "female";
									                }
									
									var jobayaApi:JobayaApi = JobayaApi()
									jobayaApi.register(fullName:fullNameTxt.text! ,userName:userNameTxt.text! ,pass:passwordTxt.text! ,email:emailTxt.text! ,age:ageTxt.text! ,gender:gender)
								} else {
									//todo Convert: Toast.makeText(this, "passwords do not match", Toast.LENGTH_SHORT).show();
									
								}
				}
	}


	override public func onBackPressed() {
		finish()
		performSegue(withIdentifier: "FromSignupActivityToLoginActivityID", sender: nil)
	}

}