import UIKit


 class FragmentMatchedJobs//todo Convert: Fragment
{
	//todo Convert: static List<Job> matchedJobs;
	 var adapterMatchedJobs:AdapterAllJobs
	//todo Convert: static LinearLayout errorMessage;

	override public func onCreate( savedInstanceState:Bundle) {
		//todo Convert: super.onCreate(savedInstanceState);
		
		matchedJobs = Array()
		adapterMatchedJobs = AdapterAllJobs()
	}

	 override public //todo convert return type: 
	func onCreateView( //todo Convert: LayoutInflater  inflater
	,  //todo Convert: ViewGroup  container
	,  savedInstanceState:Bundle) -> View{
		//todo Convert: View v = inflater.inflate(R.layout.fragment_matchedjobs_layout , container , false);
		
		getUserInfo()
		//todo Convert: RecyclerView recyclerView = v.findViewById(R.id.recycler_view_matched_jobs);
		
		//todo Convert: recyclerView.setAdapter(adapterMatchedJobs);
		
		//todo Convert: recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
		
		//todo Convert: errorMessage.setVisibility(View.INVISIBLE);
		
		return v
	}

	private var getResumeUrl:String = "https://jobayaback.herokuapp.com/resume/email/" + LoginActivity.userEmail
	public func getUserInfo() {
		//todo Convert: final ProgressDialog progressDialog = new ProgressDialog(getContext());
		
		//todo Convert: progressDialog.setTitle("Please wait");
		
		//todo Convert: progressDialog.setMessage("loading data...");
		
		//todo Convert: progressDialog.setCancelable(false);
		
		//todo Convert: progressDialog.show();
		
		//todo Convert: StringRequest stringRequest = new StringRequest(Request.Method.GET, getResumeUrl, new Response.Listener<String>() {
		            @Override
		            public void onResponse(String response) {
		                // cancel the loading on success
		                progressDialog.cancel();
		
		                // request successful , parse the json response
		                Log.i("response" , response);
		                try {
		                    JSONArray jobsArray = new JSONArray(response);
		                    if(jobsArray.length()>0)
		                    {
		
		                        JSONObject resumeJSON = jobsArray.getJSONObject(jobsArray.length()-1);
		                        String education = resumeJSON.isNull("education") ? null : resumeJSON.getString("education");
		                        String experience = resumeJSON.isNull("experience") ? null : resumeJSON.getString("experience");
		                        String skills = resumeJSON.isNull("skills") ? null : resumeJSON.getString("skills");
		                        String gender = resumeJSON.isNull("gender") ? null : resumeJSON.getString("gender");
		
		
		
		                       JobayaApi jobayaApi = new JobayaApi(getContext());
		                       jobayaApi.findMatchedJobs(gender , education);
		
		                    }
		                    else
		                    {
		                        errorMessage.setVisibility(View.VISIBLE);
		                        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
		                        builder.setCancelable(false);
		                        builder.setTitle("Find jobs that match you");
		                        builder.setIcon(R.drawable.resume);
		                        builder.setMessage("please fill your resume to get your job matches");
		                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
		                            @Override
		                            public void onClick(DialogInterface dialog, int which) {
		
		                            }
		                        });
		                        builder.show();
		                    }
		
		
		
		
		
		
		
		
		                } catch (JSONException e) {
		                    e.printStackTrace();
		                }
		
		            }
		        }, new Response.ErrorListener() {
		            @Override
		            public void onErrorResponse(VolleyError error) {
		                // cancel the loading on fail
		                progressDialog.cancel();
		
		
		
		
		
		            }
		        });
		
		//todo Convert: Volley.newRequestQueue(getContext()).add(stringRequest);
		
	}

}