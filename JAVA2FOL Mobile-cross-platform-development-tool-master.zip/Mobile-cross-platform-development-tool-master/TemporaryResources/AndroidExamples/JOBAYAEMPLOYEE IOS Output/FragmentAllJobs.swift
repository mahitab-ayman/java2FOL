import UIKit


 class FragmentAllJobs// todo Convert:	Fragment{
	 var adapterAllJobs:AdapterAllJobs
	 var jobsList:Array<Job>
	@IBOutlet weak var errorImage:UIImageView!
	@IBOutlet weak var errorText:UILabel!
	// todo Convert:	static MaterialButton errorButton;	@IBOutlet weak var showingSearchFor:UILabel!
	// todo Convert:	static ToggleSwitch multipleToggleSwitch;
	override public func onCreate( savedInstanceState:Bundle) {
		// todo Convert:	super.onCreate(savedInstanceState);
		jobsList = Array()
		adapterAllJobs = AdapterAllJobs()
	}

	 override public func onCreateView( //todo Convert: LayoutInflater  inflater
	,  //todo Convert: ViewGroup  container
	,  savedInstanceState:Bundle) -> View{
		// todo Convert:	View v = inflater.inflate(R.layout.fragment_alljobs_layout , container , false);
		// todo Convert:	final RecyclerView recyclerView = v.findViewById(R.id.recycler_view);
		// todo Convert:	recyclerView.setAdapter(adapterAllJobs);
		// todo Convert:	recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
		let jobayaApi:JobayaApi = JobayaApi()
		// todo Convert:	jobayaApi.getAllJobs()
		// todo Convert:	errorImage.setVisibility(View.INVISIBLE)
		// todo Convert:	errorText.setVisibility(View.INVISIBLE)
		// todo Convert:	errorButton.setVisibility(View.INVISIBLE);
		/*todo Convert: 
			errorButton.setOnClickListener(new View.OnClickListener() {
		            @Override
		            public void onClick(View v) {
		                MainActivity.fragmentManager.beginTransaction().replace(R.id.main_frame , new FragmentAllJobs()).commit();
		            }
		        });
		*/
		/*todo Convert: 
			multipleToggleSwitch.setOnToggleSwitchChangeListener(new BaseToggleSwitch.OnToggleSwitchChangeListener() {
		            @Override
		            public void onToggleSwitchChangeListener(int position, boolean isChecked) {
		                if(position == 0) // get all jobs
		                {
		                    // set the list to view all the jobs
		                    filter("*");
		                   // Toast.makeText(getContext(), "all", Toast.LENGTH_SHORT).show();
		
		                }else if(position == 1) // get part time jobs
		                {
		
		                   filter("art");
		                 //   Toast.makeText(getContext(), "part", Toast.LENGTH_SHORT).show();
		
		                }else {  // get ushering jobs
		
		                    filter("sher");
		
		                    //Toast.makeText(getContext(), "usher", Toast.LENGTH_SHORT).show();
		
		                }
		            }
		        });
		*/
		return v
	}

	private func filter(text:String) {
		var filterdNames:Array<Job> = Array()
		if // todo Convert:	text.equals("*") {
					// todo Convert:	adapterAllJobs.filterList((ArrayList)jobsList)
				} else {
					/*todo Convert: 
						for (Job s : jobsList) {
					                //if the existing elements contains the search input
					                if (s.category.toLowerCase().contains(text.toLowerCase())) {
					                    //adding the element to filtered list
					                    filterdNames.add(s);
					                }
					            }
					*/
					adapterAllJobs.filterList(filterdNames:filterdNames)
				}
	}

}