import UIKit


 class LoginActivity: UIViewController{
	//todo Convert: TextInputEditText emailTxt;
	//todo Convert: TextInputEditText passTxt;
	@IBOutlet weak var signupTxt:UILabel!
	 var sharedPreferences = UserDefaults.standard
	 var userEmail:String = ""
	 var password:String = ""

	override internal func viewDidLoad() {
		super.viewDidLoad()
		sharedPreferences = //todo Convert: PreferenceManager.getDefaultSharedPreferences(LoginActivity.this)
		
		checkSharedPref()
		if //todo Convert: getIntent().getStringExtra("email")
		 != null {
					//todo Convert: emailTxt.setText(getIntent().getStringExtra("email"));
					
					//todo Convert: passTxt.setText(getIntent().getStringExtra("pass"));
					
				}
		//todo Convert: signupTxt.setOnClickListener(new View.OnClickListener() {
		            @Override
		            public void onClick(View v) {
		                // open signuo activity
		                Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
		                finish();
		                startActivity(intent);
		            }
		        });
		
	}

	public func loginFunction(//todo Convert: View  v
	) throws null{
		//todo Convert: final ProgressDialog progressDialog = new ProgressDialog(this);
		
		//todo Convert: progressDialog.setTitle("Please Wait");
		
		//todo Convert: progressDialog.setMessage("logging in...");
		
		//todo Convert: progressDialog.setCancelable(false);
		
		//todo Convert: progressDialog.show();
		
		//todo Convert: JSONObject jsonObject = new JSONObject();
		
		//todo Convert: Gson gson = new Gson();
		
		//todo Convert: final String email = gson.toJson(emailTxt.getText().toString());
		
		//todo Convert: final String pass = gson.toJson(passTxt.getText().toString());
		
		//todo Convert: jsonObject.put("email", emailTxt.getText().toString());
		
		//todo Convert: jsonObject.put("password", passTxt.getText().toString());
		
		var url:String = "https://jobayaback.herokuapp.com/login"
		//todo Convert: JsonObjectRequest loginRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObject, new Response.Listener<JSONObject>() {
		            @Override
		            public void onResponse(JSONObject response) {
		                progressDialog.cancel();
		
		
		                //  handle the response (login or prevent access)
		                try {
		                    String result = response.getString("found");
		                    if (result.equals("true")) {
		
		                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
		                        userEmail = emailTxt.getText().toString();
		
		                        // login success - place data in shared pref
		                        SharedPreferences.Editor editor = sharedPreferences.edit();
		                        editor.putString("loggedIn" , "true");
		                        editor.putString("email" , emailTxt.getText().toString());
		                        editor.commit();
		                        intent.putExtra("email", emailTxt.getText().toString());
		                        finish();
		                        startActivity(intent);
		                    } else {
		
		                        Toast.makeText(LoginActivity.this, "failed, incorrect email or password", Toast.LENGTH_SHORT).show();
		
		                    }
		
		
		                } catch (JSONException e) {
		                    e.printStackTrace();
		
		                }
		
		            }
		        }, new Response.ErrorListener() {
		            @Override
		            public void onErrorResponse(VolleyError error) {
		                progressDialog.cancel();
		
		                // volley error
		                Toast.makeText(LoginActivity.this, "failed, please check network connection", Toast.LENGTH_SHORT).show();
		            }
		
		
		        });
		
		//todo Convert: Volley.newRequestQueue(this).add(loginRequest);
		
	}

	public func checkSharedPref() {
		//todo Convert: if(sharedPreferences.getString("loggedIn" , "false").equals("true"))
		        {
		            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
		            // if logged in get the email from shared pref to pass to later activities and fragments
		            userEmail = sharedPreferences.getString("email" , null);
		            finish();
		            startActivity(intent);
		
		        }
		
	}

}