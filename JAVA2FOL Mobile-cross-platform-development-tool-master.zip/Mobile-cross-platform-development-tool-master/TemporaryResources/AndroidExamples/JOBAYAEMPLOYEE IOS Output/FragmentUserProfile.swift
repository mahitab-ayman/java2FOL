import UIKit


 class FragmentUserProfile//todo Convert: Fragment
{
	//todo Convert: AutoCompleteTextView autoCompleteTextView ;
	@IBOutlet weak var expView:UITextField!
	@IBOutlet weak var skillsView:UITextField!
	//todo Convert: ToggleSwitch genderSelector ;
	//todo Convert: MaterialButton saveResume;

	override public func onCreate( savedInstanceState:Bundle) {
		//todo Convert: super.onCreate(savedInstanceState);
		
	}

	 override public //todo convert return type: 
	func onCreateView( //todo Convert: LayoutInflater  inflater
	,  //todo Convert: ViewGroup  container
	,  savedInstanceState:Bundle) -> View{
		//todo Convert: View v = inflater.inflate(R.layout.fragment_user_layout , container , false);
		
		var occupationArray:[String] = String()
		//todo Convert: ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext() , android.R.layout.simple_list_item_1 , occupationArray);
		
		//todo Convert: autoCompleteTextView.setAdapter(adapter);
		
		getUserInfo()
		//todo Convert: saveResume.setOnClickListener(new View.OnClickListener() {
		            @Override
		            public void onClick(View v) {
		                String occup , exp , skills , gender;
		                occup = autoCompleteTextView.getText().toString();
		                exp = expView.getText().toString();
		                skills = skillsView.getText().toString();
		                if(genderSelector.getCheckedTogglePosition() == 0)
		                {
		                    gender = "male";
		                }
		                else {
		                    gender = "female";
		                }
		                JobayaApi jobayaApi = new JobayaApi(getContext());
		                jobayaApi.postResume(occup , exp , skills , gender , LoginActivity.userEmail);
		
		
		
		            }
		        });
		
		return v
	}

	private var getResumeUrl:String = "https://jobayaback.herokuapp.com/resume/email/" + LoginActivity.userEmail
	public func getUserInfo() {
		//todo Convert: final ProgressDialog progressDialog = new ProgressDialog(getContext());
		
		//todo Convert: progressDialog.setTitle("Please wait");
		
		//todo Convert: progressDialog.setMessage("loading data...");
		
		//todo Convert: progressDialog.setCancelable(false);
		
		//todo Convert: progressDialog.show();
		
		//todo Convert: StringRequest stringRequest = new StringRequest(Request.Method.GET, getResumeUrl, new Response.Listener<String>() {
		            @Override
		            public void onResponse(String response) {
		                // cancel the loading on success
		                progressDialog.cancel();
		
		                // request successful , parse the json response
		                Log.i("response" , response);
		                try {
		                    JSONArray jobsArray = new JSONArray(response);
		                    if(jobsArray.length()>0)
		                    {
		                        JSONObject resumeJSON = jobsArray.getJSONObject(jobsArray.length()-1);
		                        String education = resumeJSON.isNull("education") ? null : resumeJSON.getString("education");
		                        String experience = resumeJSON.isNull("experience") ? null : resumeJSON.getString("experience");
		                        String skills = resumeJSON.isNull("skills") ? null : resumeJSON.getString("skills");
		                        String gender = resumeJSON.isNull("gender") ? null : resumeJSON.getString("gender");
		
		
		
		                        autoCompleteTextView.setText(education);
		                        expView.setText(experience);
		                        skillsView.setText(skills);
		                        if(gender.equals("male")){
		                            genderSelector.setCheckedTogglePosition(0);
		                        }
		                        else if (gender.equals("female"))
		                        {
		                            genderSelector.setCheckedTogglePosition(1);
		                        }
		                        else {
		                            genderSelector.setCheckedTogglePosition(0);
		
		                        }
		
		
		                    }
		
		
		
		
		
		
		
		
		                } catch (JSONException e) {
		                    e.printStackTrace();
		                }
		
		            }
		        }, new Response.ErrorListener() {
		            @Override
		            public void onErrorResponse(VolleyError error) {
		                // cancel the loading on fail
		                progressDialog.cancel();
		
		
		
		
		
		            }
		        });
		
		//todo Convert: Volley.newRequestQueue(getContext()).add(stringRequest);
		
	}

}