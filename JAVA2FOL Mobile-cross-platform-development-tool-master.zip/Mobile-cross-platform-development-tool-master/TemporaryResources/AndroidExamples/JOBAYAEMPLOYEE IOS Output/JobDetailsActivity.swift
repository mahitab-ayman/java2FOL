import UIKit


 class JobDetailsActivity: UIViewController{
	@IBOutlet weak var name:UILabel!
	@IBOutlet weak var desc:UILabel!
	@IBOutlet weak var duration:UILabel!
	@IBOutlet weak var agetTxt:UILabel!
	@IBOutlet weak var cat:UILabel!
	@IBOutlet weak var gender:UILabel!
	@IBOutlet weak var hasAppliedTxt:UILabel!
	// todo Convert:	static MaterialButton applyButton;	var email:String = ""
	var ID:String = ""
	var skills:String = ""
	var exp:String = ""
	var lang:String = ""
	var empMail:String = ""
	@IBOutlet weak var toggleDetail:UILabel!
	// todo Convert:	ToggleSwitch toggleSwitch;	@IBOutlet weak var mailTxt:UILabel!

	override internal func viewDidLoad() {
		super.viewDidLoad()
		// todo Convert:	name.setText(getIntent().getStringExtra("job"))
		// todo Convert:	desc.setText(getIntent().getStringExtra("desc"))
		// todo Convert:	duration.setText(getIntent().getStringExtra("duration"))
		// todo Convert:	cat.setText(getIntent().getStringExtra("cat"))
		// todo Convert:	gender.setText(getIntent().getStringExtra("gender"))
		// todo Convert:	agetTxt.setText(getIntent().getStringExtra("age"))
		// todo Convert:	hasAppliedTxt.setVisibility(View.INVISIBLE)
		email = LoginActivity.userEmail
		ID = // todo Convert:	getIntent().getStringExtra("ID")
		var jobayaApi:JobayaApi = JobayaApi()
		jobayaApi.apply(email:email ,ID:ID)
		skills = // todo Convert:	getIntent().getStringExtra("skills")
		exp = // todo Convert:	getIntent().getStringExtra("exp")
		lang = // todo Convert:	getIntent().getStringExtra("lang")
		empMail = // todo Convert:	getIntent().getStringExtra("empMail")
		toggleDetail.text = skills
		mailTxt.text = empMail
		if // todo Convert:	getIntent().getStringExtra("gender") == null {
					gender.text = "Not specified"
				}
		if empMail == null {
					mailTxt.text = "Not specified"
				}
		if skills == null {
					toggleDetail.text = "Not specified"
				}
		/*todo Convert: 
			toggleSwitch.setOnToggleSwitchChangeListener(new BaseToggleSwitch.OnToggleSwitchChangeListener() {
		            @Override
		            public void onToggleSwitchChangeListener(int position, boolean isChecked) {
		                if(position == 0) // skill
		                {
		
		                    toggleDetail.setText(skills);
		                    if(skills == null)
		                    {
		                        toggleDetail.setText("Not specified");
		
		                    }
		
		
		                }
		                else if(position == 1)//
		
		                {
		
		                    toggleDetail.setText(exp);
		                    if(exp == null)
		                    {
		                        toggleDetail.setText("Not specified");
		
		                    }
		
		
		
		                }
		                else  {  // lang
		                    toggleDetail.setText(lang);
		                    if(lang == null)
		                    {
		                        toggleDetail.setText("Not specified");
		
		                    }
		
		
		
		                }
		            }
		        });
		*/
	}

	public func applyFunction(v:View) {
		var jobayaApi:JobayaApi = JobayaApi()
		// todo Convert:	jobayaApi.postApplications( email, ID , getIntent().getStringExtra("job") , getIntent().getStringExtra("desc") , getIntent().getStringExtra("education") , getIntent().getStringExtra("duration") , getIntent().getStringExtra("age") , getIntent().getStringExtra("cat") , getIntent().getStringExtra("gender") , getIntent().getStringExtra("lang") , getIntent().getStringExtra("skills") , getIntent().getStringExtra("exp") , getIntent().getStringExtra("empMail"))
	}

}