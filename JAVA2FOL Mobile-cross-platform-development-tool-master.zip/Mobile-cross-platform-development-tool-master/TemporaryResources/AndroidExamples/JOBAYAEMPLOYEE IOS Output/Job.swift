import UIKit


 class Job{
	var title:String = ""
	var description:String = ""
	var duration:String = ""
	var education:String = ""
	var category:String = ""
	var age:String = ""
	var gender:String = ""
	var mail:String = ""
	var ID:String = ""
	var skills:String = ""
	var exp:String = ""
	var lang:String = ""
	var empMail:String = ""
	init(title:String, description:String, category:String, duration:String, age:String, ID:String, gender:String, skills:String, exp:String, lang:String, empMail:String, education:String)  {
	self.title = title
	self.description = description
	self.category = category
	self.duration = duration
	self.age = age
	self.gender = gender
	self.ID = ID
	self.skills = skills
	self.exp = exp
	self.lang = lang
	self.empMail = empMail
	self.education = education

 }

}