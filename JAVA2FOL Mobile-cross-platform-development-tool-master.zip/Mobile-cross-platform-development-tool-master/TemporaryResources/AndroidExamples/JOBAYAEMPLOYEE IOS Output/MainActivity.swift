import UIKit


 class MainActivity: UIViewController{
	//todo Convert: ActionBar actionBar ;
	//todo Convert: MenuItem searchItem;
	//todo Convert: static List<Job> AllJobsList;
	//todo Convert: static  List<Job> AppliedJobsList;
	//todo Convert: static FragmentManager fragmentManager;

	override internal func viewDidLoad() {
		super.viewDidLoad()
		fragmentManager = getSupportFragmentManager()
		actionBar = getSupportActionBar()
		//todo Convert: actionBar.setTitle("Jobs");
		
		//todo Convert: BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_nav);
		
		//todo Convert: bottomNavigationView.setOnNavigationItemSelectedListener(navListener);
		
		//todo Convert: getSupportFragmentManager().beginTransaction().replace(R.id.main_frame , new FragmentAllJobs()).commit();
		
		AllJobsList = Array()
		AppliedJobsList = Array()
	}

	//todo Convert: private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    Fragment selectedFragment = null;
                    switch (menuItem.getItemId())
                    {
                        case R.id.allJobsTab:
                            selectedFragment = new FragmentAllJobs();
                           // screenTitleTxt.setText("Jobs");
                            searchItem.setVisible(true);
                            searchItem.collapseActionView();
                            actionBar.setTitle("Jobs");
                            break;
                        case R.id.appliedJobsTab:
                            selectedFragment = new FragmentAppliedJobs();
                           // screenTitleTxt.setText("Applied Jobs");
                            actionBar.setTitle("Applied Jobs");
                            searchItem.collapseActionView();
                            searchItem.setVisible(false);
                            break;
                        case R.id.matchedJobsTab:
                            selectedFragment = new FragmentMatchedJobs();
                          //  screenTitleTxt.setText("Matched Jobs");
                            actionBar.setTitle("Matched Jobs");
                            searchItem.setVisible(false);
                            searchItem.collapseActionView();
                            break;
                        case R.id.userTab:
                            selectedFragment = new FragmentUserProfile();
                           // screenTitleTxt.setText("Profile");
                            actionBar.setTitle("Profile");
                            searchItem.setVisible(false);
                            searchItem.collapseActionView();
                            break;
                    }

                    fragmentManager.beginTransaction().replace(R.id.main_frame , selectedFragment).commit();
                    return true;
                }
            };

	override public func onBackPressed() {
		//todo Convert: AlertDialog.Builder builder = new AlertDialog.Builder(this);
		
		//todo Convert: builder.setTitle("Exit App");
		
		//todo Convert: builder.setMessage("leave app ?");
		
		//todo Convert: builder.setCancelable(false);
		
		//todo Convert: builder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
		            @Override
		            public void onClick(DialogInterface dialog, int which) {
		                MainActivity.super.onBackPressed();
		
		            }
		        });
		
		//todo Convert: builder.setNegativeButton("Stay", new DialogInterface.OnClickListener() {
		            @Override
		            public void onClick(DialogInterface dialog, int which) {
		                // do nothing
		            }
		        });
		
		//todo Convert: builder.show();
		
	}


	override public func onCreateOptionsMenu(//todo Convert: Menu  menu
	) -> Bool{
		//todo Convert: MenuInflater menuInflater = getMenuInflater();
		
		//todo Convert: menuInflater.inflate(R.menu.action_bar_menu , menu);
		
		//todo Convert: MenuItem logoutItem = menu.findItem(R.id.logout_action_bar);
		
		//todo Convert: MenuItem messageItem = menu.findItem(R.id.messenger_action_bar);
		
		//todo Convert: searchItem = menu.findItem(R.id.search_action_bar);
		
		//todo Convert: android.support.v7.widget.SearchView searchView = (android.support.v7.widget.SearchView) searchItem.getActionView();
		
		//todo Convert: searchView.setOnQueryTextListener(new android.support.v7.widget.SearchView.OnQueryTextListener() {
		            @Override
		            public boolean onQueryTextSubmit(String query) {
		                //FragmentAllJobs.multipleToggleSwitch.setVisibility(View.VISIBLE);
		                return false;
		            }
		
		            @Override
		            public boolean onQueryTextChange(String newText) {
		                filterSearch(newText);
		                // reset toggle to all jobs
		               // FragmentAllJobs.multipleToggleSwitch.setVisibility(View.INVISIBLE);
		                FragmentAllJobs.showingSearchFor.setText("showing search results for \" "+newText+" \"");
		                return false;
		            }
		        });
		
		//todo Convert: searchItem.setOnActionExpandListener(new MenuItem.OnActionExpandListener() {
		            @Override
		            public boolean onMenuItemActionExpand(MenuItem item) {
		                FragmentAllJobs.multipleToggleSwitch.setVisibility(View.INVISIBLE);
		                FragmentAllJobs.showingSearchFor.setVisibility(View.VISIBLE);
		                FragmentAllJobs.showingSearchFor.setText("showing search results for \" \"");
		                return true;
		            }
		
		            @Override
		            public boolean onMenuItemActionCollapse(MenuItem item) {
		                FragmentAllJobs.multipleToggleSwitch.setVisibility(View.VISIBLE);
		                FragmentAllJobs.showingSearchFor.setVisibility(View.INVISIBLE);
		                FragmentAllJobs.multipleToggleSwitch.setCheckedTogglePosition(0);
		                return true;
		            }
		        });
		
		return true
	}

	private func filterSearch(text:String) {
		var filterdNames:Array<Job> = Array()
		//todo Convert: for (Job s : FragmentAllJobs.jobsList) {
		            //if the existing elements contains the search input
		            if (s.title.toLowerCase().contains(text.toLowerCase())) {
		                //adding the element to filtered list
		                filterdNames.add(s);
		            }
		        }
		
		if filterdNames.count == 0 {
					//todo Convert: FragmentAllJobs.errorImage.setImageResource(R.drawable.problem);
					
					//todo Convert: FragmentAllJobs.errorImage.setVisibility(View.VISIBLE);
					
					//todo Convert: FragmentAllJobs.errorText.setText("no results found matching your search");
					
					//todo Convert: FragmentAllJobs.errorText.setVisibility(View.VISIBLE);
					
				} else {
					//todo Convert: FragmentAllJobs.errorImage.setVisibility(View.INVISIBLE);
					
					//todo Convert: FragmentAllJobs.errorText.setVisibility(View.INVISIBLE);
					
				}
		//todo Convert: FragmentAllJobs.adapterAllJobs.filterList(filterdNames);
		
	}


	override public func onOptionsItemSelected(//todo Convert: MenuItem  item
	) -> Bool{
		//todo Convert: switch (item.getItemId())
		        {
		            case R.id.logout_action_bar:
		               // Toast.makeText(this, "logout", Toast.LENGTH_SHORT).show();
		                // logout logic
		                // prompt the user
		                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
		                builder.setTitle("Log-out");
		                builder.setMessage("Are you sure you want to log-out ?");
		                builder.setIcon(R.drawable.ic_exit_to_app_black_24dp);
		                builder.setCancelable(false);
		                builder.setPositiveButton("log-out", new DialogInterface.OnClickListener() {
		                    @Override
		                    public void onClick(DialogInterface dialog, int which) {
		                        SharedPreferences sharedPreferences = LoginActivity.sharedPreferences;
		                        SharedPreferences.Editor editor = sharedPreferences.edit();
		                        editor.putString("loggedIn" , "false");
		                        editor.commit();
		                        // return to login
		                        Intent intent = new Intent(MainActivity.this , LoginActivity.class);
		                        finish();
		                        startActivity(intent);
		                    }
		                });
		                builder.setNegativeButton("stay", new DialogInterface.OnClickListener() {
		                    @Override
		                    public void onClick(DialogInterface dialog, int which) {
		                    }
		                });
		                builder.show();
		                break;
		            case R.id.messenger_action_bar:
		               // Toast.makeText(this, "messenger", Toast.LENGTH_SHORT).show();
		                String url = "https://www.facebook.com/JobayaEgypt";
		                Uri uri = Uri.parse(url);
		                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
		                // Verify that the intent will resolve to an activity
		                if (intent.resolveActivity(getPackageManager()) != null) {
		                    // Here we use an intent without a Chooser unlike the next example
		                    startActivity(intent);
		                }
		                break;
		            case R.id.search_action_bar:
		               // Toast.makeText(this, "search", Toast.LENGTH_SHORT).show();
		                break;
		        }
		
		return //todo Convert: super.onOptionsItemSelected(item)
		
	}

}