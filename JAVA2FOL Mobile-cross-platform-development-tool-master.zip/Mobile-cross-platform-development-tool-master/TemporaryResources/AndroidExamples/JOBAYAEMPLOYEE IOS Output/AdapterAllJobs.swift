import UIKit


 class AdapterAllJobs//todo Convert: RecyclerView.Adapter<AdapterAllJobs.JobHolder>
{
	//todo Convert: Context context;
	//todo Convert: List<Job> jobsList;
	var showApply:Bool
	public func filterList(filterdNames:Array<Job>) {
		self.jobsList = filterdNames
		notifyDataSetChanged()
	}

	init(//todo Convert: Context  context
	, //todo Convert: List<Job>  jobsList
	, showApply:Bool)  {
	self.context = context
	self.jobsList = jobsList
	self.showApply = showApply

 }

	 override public func onCreateViewHolder( //todo Convert: ViewGroup  viewGroup
	, i:Int) -> JobHolder{
		//todo Convert: View v = LayoutInflater.from(context).inflate(R.layout.recycler_view_item_alljobs , viewGroup , false);
		
		var holder:JobHolder = JobHolder()
		return holder
	}


	override public func onBindViewHolder( jobHolder:JobHolder, i:Int) {
		//todo Convert: final Job job = jobsList.get(i);
		
		//todo Convert: jobHolder.title.setText(job.title);
		
		//todo Convert: jobHolder.cat.setText(job.category);
		
		//todo Convert: jobHolder.duration.setText(job.duration);
		
		if showApply {
					//todo Convert: jobHolder.applyBtn.setText("APPLY");
					
				} else {
					//todo Convert: jobHolder.applyBtn.setText("DETAILS");
					
				}
		//todo Convert: jobHolder.applyBtn.setOnClickListener(new View.OnClickListener() {
		            @Override
		            public void onClick(View v) {
		                Intent intent = new Intent(context , JobDetailsActivity.class);
		                if(!showApply)
		                {
		                    intent.putExtra("fromApplied" , "true");
		                }
		                intent.putExtra("job" , job.title);
		                intent.putExtra("desc" , job.description);
		                intent.putExtra("duration" , job.duration);
		                intent.putExtra("cat" , job.category);
		                intent.putExtra("ID" , job.ID);
		                intent.putExtra("age" , job.age);
		                intent.putExtra("gender" , job.gender);
		                intent.putExtra("skills" , job.skills);
		                intent.putExtra("exp" , job.exp);
		                intent.putExtra("lang" , job.lang);
		                intent.putExtra("empMail" , job.empMail);
		                intent.putExtra("education" , job.education);
		
		                // finish activity
		
		
		                context.startActivity(intent);
		            }
		        });
		
	}


	override public func getItemCount() -> Int{
		//todo Convert: return jobsList.size();
		
	}

	class JobHolder//todo Convert: RecyclerView.ViewHolder
{
	@IBOutlet weak var title:UILabel!
	@IBOutlet weak var cat:UILabel!
	@IBOutlet weak var duration:UILabel!
	//todo Convert: MaterialButton applyBtn;
	init( //todo Convert: View  itemView
	)  {
	
	
	
	

 }

}
}