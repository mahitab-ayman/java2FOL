import UIKit


 class JobayaApi{
	private var allJobsUrl:String = "https://jobayaback.herokuapp.com/jobs/all"
	private var appliedJobsUrl:String = "https://jobayaback.herokuapp.com/applications/" + LoginActivity.userEmail
	private var applyForJobUrl:String = "https://jobayaback.herokuapp.com/applications"
	private var registerApiUrl:String = "https://jobayaback.herokuapp.com/register"
	private var applyUrl:String = "https://jobayaback.herokuapp.com/apply"
	private var matchingUrl:String = "https://jobayaback.herokuapp.com/matching"
	private var resumeUrl:String = "https://jobayaback.herokuapp.com/resume"
	//todo Convert: Context context;
	init(//todo Convert: Context  context
	)  {
	self.context = context

 }

	public func getAllJobs() {
		//todo Convert: final ProgressDialog progressDialog = new ProgressDialog(context);
		
		//todo Convert: progressDialog.setTitle("Please wait");
		
		//todo Convert: progressDialog.setMessage("loading data...");
		
		//todo Convert: progressDialog.setCancelable(false);
		
		//todo Convert: progressDialog.show();
		
		//todo Convert: StringRequest allJobsRequest = new StringRequest(Request.Method.GET, allJobsUrl, new Response.Listener<String>() {
		            @Override
		            public void onResponse(String response) {
		                // cancel the loading on success
		                progressDialog.cancel();
		
		                // request successful , parse the json response
		                Log.i("response" , response);
		                try {
		                    JSONArray jobsArray = new JSONArray(response);
		                    // clear the all jobs list first to prevent duplicates
		                    MainActivity.AllJobsList.clear();
		                    FragmentAllJobs.jobsList.clear();
		                    for(int i =0 ; i<jobsArray.length() ; i++)
		                    {
		
		                        JSONObject retrievedJob = jobsArray.getJSONObject(i);
		                        String gender = retrievedJob.isNull("gender") ? null : retrievedJob.getString("gender");
		                        String title = retrievedJob.isNull("title") ? null : retrievedJob.getString("title");
		                        String desc = retrievedJob.isNull("description") ? null : retrievedJob.getString("description");
		                        String cat = retrievedJob.isNull("category") ? null : retrievedJob.getString("category");
		                        String duration = retrievedJob.isNull("duration") ? null : retrievedJob.getString("duration");
		                        String age = retrievedJob.isNull("age") ? null : retrievedJob.getString("age");
		                        String ID = retrievedJob.isNull("_id") ? null : retrievedJob.getString("_id");
		                        String skills = retrievedJob.isNull("skills") ? null : retrievedJob.getString("skills");
		                        String exp = retrievedJob.isNull("experience") ? null : retrievedJob.getString("experience");
		                        String lang = retrievedJob.isNull("language") ? null : retrievedJob.getString("language");
		                        String education = retrievedJob.isNull("education") ? null : retrievedJob.getString("education");
		                        String empMail = retrievedJob.isNull("employer_email") ? null : retrievedJob.getString("employer_email");
		                        Job job = new Job(title , desc , cat , duration , age ,ID , gender , skills , exp , lang , empMail , education);
		                        FragmentAllJobs.jobsList.add(job);
		                        // send the data to the host activity
		                        MainActivity.AllJobsList.add(job); // will be used later by the applied job function
		
		                    }
		
		
		                    Collections.reverse(FragmentAllJobs.jobsList);
		                    FragmentAllJobs.adapterAllJobs.notifyDataSetChanged();
		                } catch (JSONException e) {
		                    e.printStackTrace();
		                }
		
		            }
		        }, new Response.ErrorListener() {
		            @Override
		            public void onErrorResponse(VolleyError error) {
		                // cancel the loading on fail
		                progressDialog.cancel();
		
		                // request failed
		                // will return null list
		                //Log.i("error" , error.getMessage());
		                FragmentAllJobs.errorImage.setVisibility(View.VISIBLE);
		                FragmentAllJobs.errorText.setVisibility(View.VISIBLE);
		                FragmentAllJobs.errorText.setText("Please check internet connection");
		                FragmentAllJobs.errorButton.setVisibility(View.VISIBLE);
		
		
		
		            }
		        });
		
		//todo Convert: Volley.newRequestQueue(context).add(allJobsRequest);
		
	}

	public func getAppliedJobs() {
		//todo Convert: final ProgressDialog progressDialog = new ProgressDialog(context);
		
		//todo Convert: progressDialog.setTitle("Please wait");
		
		//todo Convert: progressDialog.setMessage("loading data...");
		
		//todo Convert: progressDialog.setCancelable(false);
		
		//todo Convert: progressDialog.show();
		
		//todo Convert: final List<String> jobIds;
		
		//todo Convert: final List<Job> jobsList;
		
		jobIds = Array()
		jobsList = MainActivity.AllJobsList
		//todo Convert: final List<Job> appliedJobsList = new ArrayList<S>();
		
		//todo Convert: StringRequest appliedJobsRequest = new StringRequest(Request.Method.GET, appliedJobsUrl, new Response.Listener<String>() {
		            @Override
		            public void onResponse(String response) {
		                progressDialog.cancel();
		
		
		                try {
		                    MainActivity.AppliedJobsList.clear();
		                    FragmentAppliedJobs.appliedJobsLst.clear();
		                    JSONArray idsArray = new JSONArray(response);
		                    // check if there is any applied jobs or not
		                    if(idsArray.length() == 0)
		                    {
		                        Toast.makeText(context, "apply for jobs", Toast.LENGTH_SHORT).show();
		                        FragmentAppliedJobs.errorImage.setVisibility(View.VISIBLE);
		                        FragmentAppliedJobs.errorImage.setImageResource(R.drawable.noapply);
		                        FragmentAppliedJobs.errorText.setVisibility(View.VISIBLE);
		                        FragmentAppliedJobs.errorText.setText("You have not applied for any job yet !");
		                    }
		                    for(int i =0 ; i<idsArray.length() ; i++)
		                    {
		                        JSONObject idJSON = idsArray.getJSONObject(i);
		                        jobIds.add(idJSON.getString("job_ID"));
		                        for (int j =0 ; j<jobsList.size() ; j++)
		                        {
		                            if(jobsList.get(j).ID.equals(idJSON.getString("job_ID"))){
		                               // appliedJobsList.add(jobsList.get(j));
		                               // adapterAllJobs.notifyDataSetChanged();
		                                Log.i("applied" , jobsList.get(j).title);
		                                appliedJobsList.add(jobsList.get(j));
		                                MainActivity.AppliedJobsList.add(jobsList.get(j));
		                                FragmentAppliedJobs.appliedJobsLst.add(jobsList.get(j));
		
		
		
		                            }
		
		                            //MainActivity.AllJobsList = appliedJobsList;
		                        }
		
		                    }
		                    Collections.reverse(FragmentAppliedJobs.appliedJobsLst);
		                    FragmentAppliedJobs.adapterAppliedJobs.notifyDataSetChanged();
		                } catch (JSONException e) {
		                    e.printStackTrace();
		                }
		
		
		
		            }
		        }, new Response.ErrorListener() {
		            @Override
		            public void onErrorResponse(VolleyError error) {
		                progressDialog.cancel();
		
		                FragmentAppliedJobs.errorImage.setVisibility(View.VISIBLE);
		                FragmentAppliedJobs.errorImage.setImageResource(R.drawable.xmark);
		                FragmentAppliedJobs.errorText.setVisibility(View.VISIBLE);
		                FragmentAppliedJobs.errorText.setText("Please check internet connection");
		                FragmentAppliedJobs.errorButton.setVisibility(View.VISIBLE);
		
		            }
		        });
		
		//todo Convert: Volley.newRequestQueue(context).add(appliedJobsRequest);
		
	}

	public func register(fullName:String, userName:String, pass:String, email:String, age:String, gender:String) {
		//todo Convert: final ProgressDialog progressDialog = new ProgressDialog(context);
		
		//todo Convert: progressDialog.setTitle("Please wait");
		
		//todo Convert: progressDialog.setMessage("creating account...");
		
		//todo Convert: progressDialog.setCancelable(false);
		
		//todo Convert: progressDialog.show();
		
		//todo Convert: JSONObject regBody = new JSONObject();
		
		//todo Convert: try {
		            regBody.put("name" , fullName );
		            regBody.put("username" , userName );
		            regBody.put("password" , pass );
		            regBody.put("email" , email );
		            regBody.put("age" , age );
		            regBody.put("gender" , gender );
		
		            // start the request after the body is populated
		            JsonObjectRequest registerRequest = new JsonObjectRequest(Request.Method.POST, registerApiUrl, regBody, new Response.Listener<JSONObject>() {
		                @Override
		                public void onResponse(JSONObject response) {
		                    progressDialog.cancel();
		
		                   // Toast.makeText(context, ""+response.toString(), Toast.LENGTH_SHORT).show();
		                    Intent intent = new Intent(context , LoginActivity.class);
		                    ((SignupActivity)context).finish();
		                    intent.putExtra("email" , email);
		                    intent.putExtra("pass" , pass);
		                    context.startActivity(intent);
		
		
		                }
		            }, new Response.ErrorListener() {
		                @Override
		                public void onErrorResponse(VolleyError error) {
		                    progressDialog.cancel();
		                    Toast.makeText(context, "failed, please check internet connection", Toast.LENGTH_LONG).show();
		
		                }
		            });
		
		            Volley.newRequestQueue(context).add(registerRequest);
		
		        } catch (JSONException e) {
		            e.printStackTrace();
		        }
		
	}

	public func apply(email:String, ID:String) {
		//todo Convert: final ProgressDialog progressDialog = new ProgressDialog(context);
		
		//todo Convert: progressDialog.setTitle("Please wait");
		
		//todo Convert: progressDialog.setMessage("loading data...");
		
		//todo Convert: progressDialog.setCancelable(false);
		
		//todo Convert: progressDialog.show();
		
		//todo Convert: JSONObject applyBody = new JSONObject();
		
		//todo Convert: try {
		            applyBody.put("email" , email);
		            applyBody.put("job_ID" , ID);
		
		            // start the request
		            JsonObjectRequest applyRequest = new JsonObjectRequest(Request.Method.POST, applyUrl, applyBody, new Response.Listener<JSONObject>() {
		                @Override
		                public void onResponse(JSONObject response) {
		                    progressDialog.cancel();
		
		                    try {
		                        String  result = response.isNull("found") ? null : response.getString("found");
		                        if (result.equals("true"))
		                        {
		                            JobDetailsActivity.applyButton.setVisibility(View.INVISIBLE);
		                            JobDetailsActivity.hasAppliedTxt.setVisibility(View.VISIBLE);
		
		                        }else {
		
		                            JobDetailsActivity.applyButton.setVisibility(View.VISIBLE);
		                            JobDetailsActivity.hasAppliedTxt.setVisibility(View.INVISIBLE);
		
		
		                        }
		                    } catch (JSONException e) {
		                        e.printStackTrace();
		                    }
		
		                   // Toast.makeText(context, ""+response, Toast.LENGTH_SHORT).show();
		
		                }
		            }, new Response.ErrorListener() {
		                @Override
		                public void onErrorResponse(VolleyError error) {
		                    progressDialog.cancel();
		                    Toast.makeText(context, "failed to connect , please check yor internet connection !", Toast.LENGTH_SHORT).show();
		                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
		                    builder.setTitle("Connection failed !");
		                    builder.setMessage("check internet connection and try again");
		                    builder.setIcon(R.drawable.ic_error_black_24dp);
		                    builder.setCancelable(false);
		                    builder.setPositiveButton("try again", new DialogInterface.OnClickListener() {
		                        @Override
		                        public void onClick(DialogInterface dialog, int which) {
		
		                            apply(email , ID);
		
		                        }
		                    });
		
		                    builder.show();
		
		                }
		            });
		
		            Volley.newRequestQueue(context).add(applyRequest);
		        } catch (JSONException e) {
		            e.printStackTrace();
		        }
		
	}

	public func postApplications(email:String, ID:String, title:String, description:String, education:String, duration:String, age:String, category:String, gender:String, language:String, skills:String, experience:String, employer_email:String) {
		//todo Convert: final ProgressDialog progressDialog = new ProgressDialog(context);
		
		//todo Convert: progressDialog.setTitle("Please wait");
		
		//todo Convert: progressDialog.setMessage("Applying for job...");
		
		//todo Convert: progressDialog.setCancelable(false);
		
		//todo Convert: progressDialog.show();
		
		//todo Convert: JSONObject body = new JSONObject();
		
		//todo Convert: JSONObject job = new JSONObject();
		
		//todo Convert: try {
		            body.put("email" , email);
		            body.put("job_ID" , ID);
		            job.put("title" , title);
		            job.put("description" , description);
		            job.put("education" , education);
		            job.put("duration" , duration);
		            job.put("age" , age);
		            job.put("gender" , gender);
		            job.put("language" , language);
		            job.put("skills" , skills);
		            job.put("experience" , experience);
		            job.put("employer_email" , employer_email);
		            body.put("Job" , job);
		
		
		
		            // start the request
		            JsonObjectRequest applyForJobRequest = new JsonObjectRequest(Request.Method.POST, applyForJobUrl, body, new Response.Listener<JSONObject>() {
		                @Override
		                public void onResponse(JSONObject response) {
		                    progressDialog.cancel();
		
		                    // remove apply option
		                    JobDetailsActivity.applyButton.setVisibility(View.INVISIBLE);
		                    JobDetailsActivity.hasAppliedTxt.setVisibility(View.VISIBLE);
		
		                    View v = LayoutInflater.from(context).inflate(R.layout.apply_success_view , null , false);
		                    CheckView checkView = v.findViewById(R.id.check);
		
		                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
		                   // builder.setIcon(R.drawable.ic_ticked);
		                    builder.setView(v);
		                    builder.setCancelable(false);
		                    builder.setTitle("Applied for job successfully");
		                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
		                        @Override
		                        public void onClick(DialogInterface dialog, int which) {
		
		                        }
		                    });
		                    builder.show();
		                    checkView.check();
		
		
		                    //builder.setTitle("")
		
		                }
		            }, new Response.ErrorListener() {
		                @Override
		                public void onErrorResponse(VolleyError error) {
		                    progressDialog.cancel();
		
		                    Toast.makeText(context, "failed, please check internet connection !", Toast.LENGTH_SHORT).show();
		
		                }
		            });
		
		            Volley.newRequestQueue(context).add(applyForJobRequest);
		        } catch (JSONException e) {
		            e.printStackTrace();
		        }
		
	}

	public func findMatchedJobs(gender:String, education:String) {
		//todo Convert: final ProgressDialog progressDialog = new ProgressDialog(context);
		
		//todo Convert: progressDialog.setTitle("Please wait");
		
		//todo Convert: progressDialog.setMessage("loading data...");
		
		//todo Convert: progressDialog.setCancelable(false);
		
		//todo Convert: progressDialog.show();
		
		//todo Convert: JSONObject matchingRequestBody = new JSONObject();
		
		//todo Convert: try {
		            matchingRequestBody.put("gender" , gender);
		            matchingRequestBody.put("education" , education);
		
		            // start the request
		            JsonObjectRequest matchingRequest = new JsonObjectRequest(Request.Method.POST, matchingUrl, matchingRequestBody, new Response.Listener<JSONObject>() {
		                @Override
		                public void onResponse(JSONObject response) {
		                    progressDialog.cancel();
		                    try {
		                        if(response.getString("found").equals("true"))
		                        {
		                            FragmentMatchedJobs.errorMessage.setVisibility(View.INVISIBLE);
		                            //Toast.makeText(context, ""+response, Toast.LENGTH_SHORT).show();
		                            JSONArray matchedJSON = response.getJSONArray("result");
		                            for(int i=0 ; i<matchedJSON.length() ; i++){
		                                JSONObject retrievedJob =  matchedJSON.getJSONObject(i);
		                                String gender = retrievedJob.isNull("gender") ? null : retrievedJob.getString("gender");
		                                String title = retrievedJob.isNull("title") ? null : retrievedJob.getString("title");
		                                String desc = retrievedJob.isNull("description") ? null : retrievedJob.getString("description");
		                                String cat = retrievedJob.isNull("category") ? null : retrievedJob.getString("category");
		                                String duration = retrievedJob.isNull("duration") ? null : retrievedJob.getString("duration");
		                                String age = retrievedJob.isNull("age") ? null : retrievedJob.getString("age");
		                                String ID = retrievedJob.isNull("_id") ? null : retrievedJob.getString("_id");
		                                String skills = retrievedJob.isNull("skills") ? null : retrievedJob.getString("skills");
		                                String exp = retrievedJob.isNull("experience") ? null : retrievedJob.getString("experience");
		                                String lang = retrievedJob.isNull("language") ? null : retrievedJob.getString("language");
		                                String education = retrievedJob.isNull("education") ? null : retrievedJob.getString("education");
		                                String empMail = retrievedJob.isNull("employer_email") ? null : retrievedJob.getString("employer_email");
		                                Job job = new Job(title , desc , cat , duration , age ,ID , gender , skills , exp , lang , empMail , education);
		                                FragmentMatchedJobs.matchedJobs.add(job);
		                            }
		                            Collections.reverse(FragmentMatchedJobs.matchedJobs);
		                            FragmentMatchedJobs.adapterMatchedJobs.notifyDataSetChanged();
		                        }
		                        else {
		                            FragmentMatchedJobs.errorMessage.setVisibility(View.VISIBLE);
		                            //Toast.makeText(context, "no match", Toast.LENGTH_SHORT).show();
		                        }
		
		
		                    } catch (JSONException e) {
		                        e.printStackTrace();
		                    }
		
		                }
		            }, new Response.ErrorListener() {
		                @Override
		                public void onErrorResponse(VolleyError error) {
		                    progressDialog.cancel();
		
		                }
		            });
		
		            Volley.newRequestQueue(context).add(matchingRequest);
		        } catch (JSONException e) {
		            e.printStackTrace();
		        }
		
	}

	{
	}
	public func postResume(occup:String, exp:String, skills:String, gender:String, email:String) {
		//todo Convert: final ProgressDialog progressDialog = new ProgressDialog(context);
		
		//todo Convert: progressDialog.setTitle("Please wait");
		
		//todo Convert: progressDialog.setMessage("loading data...");
		
		//todo Convert: progressDialog.setCancelable(false);
		
		//todo Convert: progressDialog.show();
		
		//todo Convert: JSONObject applyBody = new JSONObject();
		
		//todo Convert: try {
		            applyBody.put("education" , occup);
		            applyBody.put("experience" , exp);
		            applyBody.put("skills" , skills);
		            applyBody.put("email" , email);
		            applyBody.put("language" , "English");
		            applyBody.put("gender" , gender);
		
		            // start the request
		            JsonObjectRequest applyRequest = new JsonObjectRequest(Request.Method.POST, resumeUrl, applyBody, new Response.Listener<JSONObject>() {
		                @Override
		                public void onResponse(JSONObject response) {
		                    progressDialog.cancel();
		
		                    try {
		                        String  result = response.isNull("done") ? null : response.getString("done");
		                        if (result.equals("true"))
		                        {
		                            View v = LayoutInflater.from(context).inflate(R.layout.resume_sucess_view , null , false);
		                            CheckView checkView = v.findViewById(R.id.check);
		
		                            AlertDialog.Builder builder = new AlertDialog.Builder(context);
		                            // builder.setIcon(R.drawable.ic_ticked);
		                            builder.setView(v);
		                            builder.setCancelable(false);
		                            builder.setTitle("Resume saved successfully");
		                            builder.setIcon(R.drawable.resume);
		
		                            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
		                                @Override
		                                public void onClick(DialogInterface dialog, int which) {
		
		                                }
		                            });
		                            builder.show();
		                            checkView.check();
		
		
		                        }else {
		                            Toast.makeText(context, "not done", Toast.LENGTH_SHORT).show();
		
		
		
		
		                        }
		                    } catch (JSONException e) {
		                        e.printStackTrace();
		                    }
		
		                    // Toast.makeText(context, ""+response, Toast.LENGTH_SHORT).show();
		
		                }
		            }, new Response.ErrorListener() {
		                @Override
		                public void onErrorResponse(VolleyError error) {
		                    progressDialog.cancel();
		                    Toast.makeText(context, "failed to connect , please check yor internet connection !", Toast.LENGTH_SHORT).show();
		                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
		                    builder.setTitle("Connection failed !");
		                    builder.setMessage("check internet connection and try again");
		                    builder.setIcon(R.drawable.ic_error_black_24dp);
		                    builder.setCancelable(false);
		                    builder.setPositiveButton("try again", new DialogInterface.OnClickListener() {
		                        @Override
		                        public void onClick(DialogInterface dialog, int which) {
		
		                            postResume(occup , exp , skills , gender , email);
		
		                        }
		                    });
		
		                    builder.show();
		
		                }
		
		
		            });
		
		            Volley.newRequestQueue(context).add(applyRequest);
		        } catch (JSONException e) {
		            e.printStackTrace();
		        }
		
	}

}