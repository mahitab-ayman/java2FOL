import UIKit


 class scientific: UIViewController{
	@IBOutlet weak var result_scientific:UILabel!
	var mValueOne:Float = 0.0, mValueTwo:Float = 0.0
	var a:Double = 0.0
	var ans:Double = 0
	var mAddition:Bool!, mSubtract:Bool!, mMultiplication:Bool!, mDivision:Bool!, mReminder:Bool!, mNoPower:Bool!, istpower2ndno:Bool!, mSin:Bool!, mArithmetic:Bool!, mCos:Bool!, mTan:Bool!, mSinH:Bool!, mCosH:Bool!, mTanH:Bool!
	var piecheck:Bool = false
	@IBOutlet weak var button_standard:UIButton!, button_equationSolver:UIButton!, clearbutton:UIButton!, dividebutton:UIButton!, multiplybutton:UIButton!, deletebutton:UIButton!, button07:UIButton!, button08:UIButton!, button09:UIButton!, minusbutton:UIButton!, button04:UIButton!, button05:UIButton!, button06:UIButton!, buttonAdd:UIButton!, button01:UIButton!, button02:UIButton!, button03:UIButton!, button00:UIButton!, pointbutton:UIButton!, button_equal:UIButton!, xcubebutton:UIButton!, squarebutton:UIButton!, xfactorialbutton:UIButton!, logbutton:UIButton!, exponentbutton:UIButton!, lnbutton:UIButton!, sinbutton:UIButton!, cosbutton:UIButton!, tanbutton:UIButton!, oneoverxbutton:UIButton!, sinhbutton:UIButton!, coshbutton:UIButton!, tanhbutton:UIButton!, tenexponent:UIButton!, piebutton:UIButton!, squarerootbutton:UIButton!, cuberootbutton:UIButton!, modulosbutton:UIButton!, epowerbtn:UIButton!, stpower2nd:UIButton!, ansbuttton:UIButton!

	override internal func viewDidLoad() {
		super.viewDidLoad()
		button_standard.removeTarget(nil, action: nil, for: .allEvents)
		button_standard.addTarget(self, action: #selector(targetMethod0), for: .touchUpInside)
		button_equationSolver.removeTarget(nil, action: nil, for: .allEvents)
		button_equationSolver.addTarget(self, action: #selector(targetMethod1), for: .touchUpInside)
		stpower2nd.removeTarget(nil, action: nil, for: .allEvents)
		stpower2nd.addTarget(self, action: #selector(targetMethod2), for: .touchUpInside)
		epowerbtn.removeTarget(nil, action: nil, for: .allEvents)
		epowerbtn.addTarget(self, action: #selector(targetMethod3), for: .touchUpInside)
		modulosbutton.removeTarget(nil, action: nil, for: .allEvents)
		modulosbutton.addTarget(self, action: #selector(targetMethod4), for: .touchUpInside)
		cuberootbutton.removeTarget(nil, action: nil, for: .allEvents)
		cuberootbutton.addTarget(self, action: #selector(targetMethod5), for: .touchUpInside)
		tenexponent.removeTarget(nil, action: nil, for: .allEvents)
		tenexponent.addTarget(self, action: #selector(targetMethod6), for: .touchUpInside)
		deletebutton.removeTarget(nil, action: nil, for: .allEvents)
		deletebutton.addTarget(self, action: #selector(targetMethod7), for: .touchUpInside)
		piebutton.removeTarget(nil, action: nil, for: .allEvents)
		piebutton.addTarget(self, action: #selector(targetMethod8), for: .touchUpInside)
		lnbutton.removeTarget(nil, action: nil, for: .allEvents)
		lnbutton.addTarget(self, action: #selector(targetMethod9), for: .touchUpInside)
		tanhbutton.removeTarget(nil, action: nil, for: .allEvents)
		tanhbutton.addTarget(self, action: #selector(targetMethod10), for: .touchUpInside)
		coshbutton.removeTarget(nil, action: nil, for: .allEvents)
		coshbutton.addTarget(self, action: #selector(targetMethod11), for: .touchUpInside)
		sinhbutton.removeTarget(nil, action: nil, for: .allEvents)
		sinhbutton.addTarget(self, action: #selector(targetMethod12), for: .touchUpInside)
		sinbutton.removeTarget(nil, action: nil, for: .allEvents)
		sinbutton.addTarget(self, action: #selector(targetMethod13), for: .touchUpInside)
		cosbutton.removeTarget(nil, action: nil, for: .allEvents)
		cosbutton.addTarget(self, action: #selector(targetMethod14), for: .touchUpInside)
		tanbutton.removeTarget(nil, action: nil, for: .allEvents)
		tanbutton.addTarget(self, action: #selector(targetMethod15), for: .touchUpInside)
		xfactorialbutton.removeTarget(nil, action: nil, for: .allEvents)
		xfactorialbutton.addTarget(self, action: #selector(targetMethod16), for: .touchUpInside)
		squarerootbutton.removeTarget(nil, action: nil, for: .allEvents)
		squarerootbutton.addTarget(self, action: #selector(targetMethod17), for: .touchUpInside)
		logbutton.removeTarget(nil, action: nil, for: .allEvents)
		logbutton.addTarget(self, action: #selector(targetMethod18), for: .touchUpInside)
		exponentbutton.removeTarget(nil, action: nil, for: .allEvents)
		exponentbutton.addTarget(self, action: #selector(targetMethod19), for: .touchUpInside)
		oneoverxbutton.removeTarget(nil, action: nil, for: .allEvents)
		oneoverxbutton.addTarget(self, action: #selector(targetMethod20), for: .touchUpInside)
		squarebutton.removeTarget(nil, action: nil, for: .allEvents)
		squarebutton.addTarget(self, action: #selector(targetMethod21), for: .touchUpInside)
		xcubebutton.removeTarget(nil, action: nil, for: .allEvents)
		xcubebutton.addTarget(self, action: #selector(targetMethod22), for: .touchUpInside)
		clearbutton.removeTarget(nil, action: nil, for: .allEvents)
		clearbutton.addTarget(self, action: #selector(targetMethod23), for: .touchUpInside)
		dividebutton.removeTarget(nil, action: nil, for: .allEvents)
		dividebutton.addTarget(self, action: #selector(targetMethod24), for: .touchUpInside)
		button01.removeTarget(nil, action: nil, for: .allEvents)
		button01.addTarget(self, action: #selector(targetMethod25), for: .touchUpInside)
		button02.removeTarget(nil, action: nil, for: .allEvents)
		button02.addTarget(self, action: #selector(targetMethod26), for: .touchUpInside)
		button03.removeTarget(nil, action: nil, for: .allEvents)
		button03.addTarget(self, action: #selector(targetMethod27), for: .touchUpInside)
		button04.removeTarget(nil, action: nil, for: .allEvents)
		button04.addTarget(self, action: #selector(targetMethod28), for: .touchUpInside)
		button05.removeTarget(nil, action: nil, for: .allEvents)
		button05.addTarget(self, action: #selector(targetMethod29), for: .touchUpInside)
		button06.removeTarget(nil, action: nil, for: .allEvents)
		button06.addTarget(self, action: #selector(targetMethod30), for: .touchUpInside)
		button07.removeTarget(nil, action: nil, for: .allEvents)
		button07.addTarget(self, action: #selector(targetMethod31), for: .touchUpInside)
		button08.removeTarget(nil, action: nil, for: .allEvents)
		button08.addTarget(self, action: #selector(targetMethod32), for: .touchUpInside)
		button09.removeTarget(nil, action: nil, for: .allEvents)
		button09.addTarget(self, action: #selector(targetMethod33), for: .touchUpInside)
		button00.removeTarget(nil, action: nil, for: .allEvents)
		button00.addTarget(self, action: #selector(targetMethod34), for: .touchUpInside)
		buttonAdd.removeTarget(nil, action: nil, for: .allEvents)
		buttonAdd.addTarget(self, action: #selector(targetMethod35), for: .touchUpInside)
		minusbutton.removeTarget(nil, action: nil, for: .allEvents)
		minusbutton.addTarget(self, action: #selector(targetMethod36), for: .touchUpInside)
		multiplybutton.removeTarget(nil, action: nil, for: .allEvents)
		multiplybutton.addTarget(self, action: #selector(targetMethod37), for: .touchUpInside)
		dividebutton.removeTarget(nil, action: nil, for: .allEvents)
		dividebutton.addTarget(self, action: #selector(targetMethod38), for: .touchUpInside)
		button_equal.removeTarget(nil, action: nil, for: .allEvents)
		button_equal.addTarget(self, action: #selector(targetMethod39), for: .touchUpInside)
		clearbutton.removeTarget(nil, action: nil, for: .allEvents)
		clearbutton.addTarget(self, action: #selector(targetMethod40), for: .touchUpInside)
		pointbutton.removeTarget(nil, action: nil, for: .allEvents)
		pointbutton.addTarget(self, action: #selector(targetMethod41), for: .touchUpInside)
		ansbuttton.removeTarget(nil, action: nil, for: .allEvents)
		ansbuttton.addTarget(self, action: #selector(targetMethod42), for: .touchUpInside)
	}

	private func openEquationSolverActivity() {
		performSegue(withIdentifier: "FromscientificToequationSolverID", sender: nil)
	}

	private func openMainActivity() {
		performSegue(withIdentifier: "FromscientificToMainActivityID", sender: nil)
	}

	@objc func targetMethod0(_ sender: UIButton){
		openMainActivity()
	}
	@objc func targetMethod1(_ sender: UIButton){
		openEquationSolverActivity()
	}
	@objc func targetMethod2(_ sender: UIButton){
		mValueOne = Float(result_scientific.text! + "")!
		istpower2ndno = true
		result_scientific.text = nil
	}
	@objc func targetMethod3(_ sender: UIButton){
		var n:Double = Double(result_scientific.text! + "")!
		var exp:Double = pow(2.718281828,n)
		result_scientific.text = String(exp)
	}
	@objc func targetMethod4(_ sender: UIButton){
		mValueOne = Float(result_scientific.text! + "")!
		mReminder = true
		result_scientific.text = nil
	}
	@objc func targetMethod5(_ sender: UIButton){
		a = pow(Double(result_scientific.text! + "")!, 1.0/3.0)
		result_scientific.text = ""
		result_scientific.text = result_scientific.text! + "" + a
	}
	@objc func targetMethod6(_ sender: UIButton){
		var n:Int = Int(result_scientific.text! + "")!
		var exp:Double = pow(Double(10),Double(n))
		result_scientific.text = String(exp)
	}
	@objc func targetMethod7(_ sender: UIButton){
		var str:String = ""
		str = result_scientific.text! + ""
		let start = str.index(str.startIndex, offsetBy: 0)
		let end = str.index(str.startIndex, offsetBy: str.count - 1)
		let range = start..<end
		str = String(str[range])
		result_scientific.text = str
	}
	@objc func targetMethod8(_ sender: UIButton){
		result_scientific.text = Math.PI + ""
	}
	@objc func targetMethod9(_ sender: UIButton){
		a = Double(result_scientific.text! + "")!
		var answer:Double = (-log(Double(1 - a))) / a
		result_scientific.text = ""
		result_scientific.text = result_scientific.text! + "" + answer
	}
	@objc func targetMethod10(_ sender: UIButton){
		a = tanh(Double(Double(result_scientific.text! + "")!))
		result_scientific.text = ""
		result_scientific.text = result_scientific.text! + "" + a
		result_scientific.text = "tanh"
		mTanH = true
	}
	@objc func targetMethod11(_ sender: UIButton){
		result_scientific.text = "cosh"
		mCosH = true
	}
	@objc func targetMethod12(_ sender: UIButton){
		result_scientific.text = "sinh"
		mSinH = true
	}
	@objc func targetMethod13(_ sender: UIButton){
		result_scientific.text = "sin"
		mSin = true
	}
	@objc func targetMethod14(_ sender: UIButton){
		result_scientific.text = "cos"
		mCos = true
	}
	@objc func targetMethod15(_ sender: UIButton){
		result_scientific.text = "tan"
		mTan = true
	}
	@objc func targetMethod16(_ sender: UIButton){
		a = Double(result_scientific.text! + "")!
		var er:Int = 0
		var i:Double = 0.0, s:Double = 1
		if a < 0 {
		er = 20
		} else {
		for i in stride(from: 2, through: a, by: 1.0)s *= i
		}
		result_scientific.text = ""
		result_scientific.text = result_scientific.text! + "" + s
	}
	@objc func targetMethod17(_ sender: UIButton){
		a = sqrt(Double(Double(result_scientific.text! + "")!))
		result_scientific.text = ""
		result_scientific.text = result_scientific.text! + "" + a
	}
	@objc func targetMethod18(_ sender: UIButton){
		a = log(Double(Double(result_scientific.text! + "")!))
		result_scientific.text = ""
		result_scientific.text = result_scientific.text! + "" + a
	}
	@objc func targetMethod19(_ sender: UIButton){
		a = exp(Double(Double(result_scientific.text! + "")!)
		result_scientific.text = ""
		result_scientific.text = result_scientific.text! + "" + a
	}
	@objc func targetMethod20(_ sender: UIButton){
		a = 1 / Double(result_scientific.text! + "")!
		result_scientific.text = ""
		result_scientific.text = result_scientific.text! + "" + a
	}
	@objc func targetMethod21(_ sender: UIButton){
		a = pow(Double(result_scientific.text! + "")!,Double(2))
		result_scientific.text = ""
		result_scientific.text = result_scientific.text! + String(a)
	}
	@objc func targetMethod22(_ sender: UIButton){
		a = pow(Double(result_scientific.text! + "")!,Double(3))
		result_scientific.text = ""
		result_scientific.text = result_scientific.text! + "" + a
	}
	@objc func targetMethod23(_ sender: UIButton){
		result_scientific.text = ""
	}
	@objc func targetMethod24(_ sender: UIButton){
		result_scientific.text = nil
	}
	@objc func targetMethod25(_ sender: UIButton){
		result_scientific.text = result_scientific.text! + "1"
		mArithmetic = true
	}
	@objc func targetMethod26(_ sender: UIButton){
		result_scientific.text = result_scientific.text! + "2"
		mArithmetic = true
	}
	@objc func targetMethod27(_ sender: UIButton){
		result_scientific.text = result_scientific.text! + "3"
		mArithmetic = true
	}
	@objc func targetMethod28(_ sender: UIButton){
		result_scientific.text = result_scientific.text! + "4"
		mArithmetic = true
	}
	@objc func targetMethod29(_ sender: UIButton){
		result_scientific.text = result_scientific.text! + "5"
		mArithmetic = true
	}
	@objc func targetMethod30(_ sender: UIButton){
		result_scientific.text = result_scientific.text! + "6"
		mArithmetic = true
	}
	@objc func targetMethod31(_ sender: UIButton){
		result_scientific.text = result_scientific.text! + "7"
		mArithmetic = true
	}
	@objc func targetMethod32(_ sender: UIButton){
		result_scientific.text = result_scientific.text! + "8"
		mArithmetic = true
	}
	@objc func targetMethod33(_ sender: UIButton){
		result_scientific.text = result_scientific.text! + "9"
		mArithmetic = true
	}
	@objc func targetMethod34(_ sender: UIButton){
		result_scientific.text = result_scientific.text! + "0"
		mArithmetic = true
	}
	@objc func targetMethod35(_ sender: UIButton){
		mValueOne = Float(result_scientific.text! + "")!
		mAddition = true
		result_scientific.text = nil
	}
	@objc func targetMethod36(_ sender: UIButton){
		mValueOne = Float(result_scientific.text! + "")!
		mSubtract = true
		result_scientific.text = nil
	}
	@objc func targetMethod37(_ sender: UIButton){
		mValueOne = Float(result_scientific.text! + "")!
		mMultiplication = true
		result_scientific.text = nil
	}
	@objc func targetMethod38(_ sender: UIButton){
		mValueOne = Float(result_scientific.text! + "")!
		mDivision = true
		result_scientific.text = nil
	}
	@objc func targetMethod39(_ sender: UIButton){
		if mSin == true {
		if mArithmetic == true {
		var str:String = ""
		str = result_scientific.text! + ""
		let start = str.index(str.startIndex, offsetBy: 3)
		let end = str.index(str.startIndex, offsetBy: str.count)
		let range = start..<end
		str = String(str[range])
		a = sin(Double(Double(str)!))
		result_scientific.text = String(a)
		mArithmetic = false
		mSin = false
		}
		}
		if mCos == true {
		if mArithmetic == true {
		var str:String = ""
		str = result_scientific.text! + ""
		let start = str.index(str.startIndex, offsetBy: 3)
		let end = str.index(str.startIndex, offsetBy: str.count)
		let range = start..<end
		str = String(str[range])
		a = cos(Double(Double(str)!))
		result_scientific.text = String(a)
		mArithmetic = false
		mCos = false
		}
		}
		if mTan == true {
		if mArithmetic == true {
		var str:String = ""
		str = result_scientific.text! + ""
		let start = str.index(str.startIndex, offsetBy: 3)
		let end = str.index(str.startIndex, offsetBy: str.count)
		let range = start..<end
		str = String(str[range])
		a = sin(Double(Double(str)!))
		result_scientific.text = String(a)
		mArithmetic = false
		mTan = false
		}
		}
		if mSinH == true {
		if mArithmetic == true {
		var str:String = ""
		str = result_scientific.text! + ""
		let start = str.index(str.startIndex, offsetBy: 4)
		let end = str.index(str.startIndex, offsetBy: str.count)
		let range = start..<end
		str = String(str[range])
		a = sinh(Double(Double(str)!))
		result_scientific.text = String(a)
		mArithmetic = false
		mSinH = false
		}
		}
		if mCosH == true {
		if mArithmetic == true {
		var str:String = ""
		str = result_scientific.text! + ""
		let start = str.index(str.startIndex, offsetBy: 4)
		let end = str.index(str.startIndex, offsetBy: str.count)
		let range = start..<end
		str = String(str[range])
		a = cosh(Double(Double(str)!))
		result_scientific.text = String(a)
		mArithmetic = false
		mCosH = false
		}
		}
		if mTanH == true {
		if mArithmetic == true {
		var str:String = ""
		str = result_scientific.text! + ""
		let start = str.index(str.startIndex, offsetBy: 4)
		let end = str.index(str.startIndex, offsetBy: str.count)
		let range = start..<end
		str = String(str[range])
		a = cosh(Double(Double(str)!))
		result_scientific.text = String(a)
		mArithmetic = false
		mTanH = false
		}
		}
		if istpower2ndno == true {
		mValueTwo = Float(result_scientific.text! + "")!
		var exp:Int = pow(mValueOne,mValueTwo): Int
		result_scientific.text = String(exp)
		istpower2ndno = false
		}
		if mAddition == true {
		mValueTwo = Float(result_scientific.text! + "")!
		result_scientific.text = String(mValueOne + mValueTwo)
		mAddition = false
		}
		if mReminder == true {
		mValueTwo = Float(result_scientific.text! + "")!
		result_scientific.text = ""
		mReminder = false
		}
		if mNoPower == true {
		mValueTwo = Float(result_scientific.text! + "")!
		var exp:Int = pow(mValueOne,mValueTwo): Int
		result_scientific.text = String(exp)
		mNoPower = false
		}
		if mSubtract == true {
		mValueTwo = Float(result_scientific.text! + "")!
		result_scientific.text = String(mValueOne - mValueTwo)
		mSubtract = false
		}
		if mMultiplication == true {
		mValueTwo = Float(result_scientific.text! + "")!
		result_scientific.text = String(mValueOne * mValueTwo)
		mMultiplication = false
		}
		if mDivision == true {
		mValueTwo = Float(result_scientific.text! + "")!
		result_scientific.text = String(mValueOne / mValueTwo)
		mDivision = false
		}
		ans = Double(result_scientific.text! + "")!
	}
	@objc func targetMethod40(_ sender: UIButton){
		result_scientific.text = nil
	}
	@objc func targetMethod41(_ sender: UIButton){
		result_scientific.text = result_scientific.text! + "."
	}
	@objc func targetMethod42(_ sender: UIButton){
		result_scientific.text = String(ans)
	}
}