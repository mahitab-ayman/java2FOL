import UIKit


 class MainActivity: UIViewController{
	var input1:Double = 0, input2:Double = 0
	@IBOutlet weak var result:UILabel!
	@IBOutlet weak var workSpace:UILabel!
	var Addition:Bool!, Subtract:Bool!, Multiplication:Bool!, Division:Bool!, decimal:Bool!, Equal:Bool!
	@IBOutlet weak var buttonScientific:UIButton!, buttonEquationSolver:UIButton!, button0:UIButton!, button1:UIButton!, button2:UIButton!, button3:UIButton!, button4:UIButton!, button5:UIButton!, button6:UIButton!, button7:UIButton!, button8:UIButton!, button9:UIButton!, buttonAdd:UIButton!, buttonSub:UIButton!, buttonMul:UIButton!, buttonDivision:UIButton!, buttonEqual:UIButton!, buttonDel:UIButton!

	override public func viewDidLoad() {
		super.viewDidLoad()
		buttonScientific.removeTarget(nil, action: nil, for: .allEvents)
		buttonScientific.addTarget(self, action: #selector(targetMethod0), for: .touchUpInside)
		buttonEquationSolver.removeTarget(nil, action: nil, for: .allEvents)
		buttonEquationSolver.addTarget(self, action: #selector(targetMethod1), for: .touchUpInside)
		button1.removeTarget(nil, action: nil, for: .allEvents)
		button1.addTarget(self, action: #selector(targetMethod2), for: .touchUpInside)
		button2.removeTarget(nil, action: nil, for: .allEvents)
		button2.addTarget(self, action: #selector(targetMethod3), for: .touchUpInside)
		button3.removeTarget(nil, action: nil, for: .allEvents)
		button3.addTarget(self, action: #selector(targetMethod4), for: .touchUpInside)
		button4.removeTarget(nil, action: nil, for: .allEvents)
		button4.addTarget(self, action: #selector(targetMethod5), for: .touchUpInside)
		button5.removeTarget(nil, action: nil, for: .allEvents)
		button5.addTarget(self, action: #selector(targetMethod6), for: .touchUpInside)
		button6.removeTarget(nil, action: nil, for: .allEvents)
		button6.addTarget(self, action: #selector(targetMethod7), for: .touchUpInside)
		button7.removeTarget(nil, action: nil, for: .allEvents)
		button7.addTarget(self, action: #selector(targetMethod8), for: .touchUpInside)
		button8.removeTarget(nil, action: nil, for: .allEvents)
		button8.addTarget(self, action: #selector(targetMethod9), for: .touchUpInside)
		button9.removeTarget(nil, action: nil, for: .allEvents)
		button9.addTarget(self, action: #selector(targetMethod10), for: .touchUpInside)
		button0.removeTarget(nil, action: nil, for: .allEvents)
		button0.addTarget(self, action: #selector(targetMethod11), for: .touchUpInside)
		buttonAdd.removeTarget(nil, action: nil, for: .allEvents)
		buttonAdd.addTarget(self, action: #selector(targetMethod12), for: .touchUpInside)
		buttonSub.removeTarget(nil, action: nil, for: .allEvents)
		buttonSub.addTarget(self, action: #selector(targetMethod13), for: .touchUpInside)
		buttonMul.removeTarget(nil, action: nil, for: .allEvents)
		buttonMul.addTarget(self, action: #selector(targetMethod14), for: .touchUpInside)
		buttonDivision.removeTarget(nil, action: nil, for: .allEvents)
		buttonDivision.addTarget(self, action: #selector(targetMethod15), for: .touchUpInside)
		buttonEqual.removeTarget(nil, action: nil, for: .allEvents)
		buttonEqual.addTarget(self, action: #selector(targetMethod16), for: .touchUpInside)
		buttonDel.removeTarget(nil, action: nil, for: .allEvents)
		buttonDel.addTarget(self, action: #selector(targetMethod17), for: .touchUpInside)
	}

	private func openEquationSolverActivity() {
		performSegue(withIdentifier: "FromMainActivityToequationSolverID", sender: nil)
	}

	private func openScientificActivity() {
		performSegue(withIdentifier: "FromMainActivityToscientificID", sender: nil)
	}

	@objc func targetMethod0(_ sender: UIButton){
		openScientificActivity()
	}
	@objc func targetMethod1(_ sender: UIButton){
		openEquationSolverActivity()
	}
	@objc func targetMethod2(_ sender: UIButton){
		if Equal {
		Equal = false
		result.text = ""
		workSpace.text = ""
		}
		result.text = result.text! + "1"
	}
	@objc func targetMethod3(_ sender: UIButton){
		if Equal {
		Equal = false
		result.text = ""
		workSpace.text = ""
		}
		result.text = result.text! + "2"
	}
	@objc func targetMethod4(_ sender: UIButton){
		if Equal {
		Equal = false
		result.text = ""
		workSpace.text = ""
		}
		result.text = result.text! + "3"
	}
	@objc func targetMethod5(_ sender: UIButton){
		if Equal {
		Equal = false
		result.text = ""
		workSpace.text = ""
		}
		result.text = result.text! + "4"
	}
	@objc func targetMethod6(_ sender: UIButton){
		if Equal {
		Equal = false
		result.text = ""
		workSpace.text = ""
		}
		result.text = result.text! + "5"
	}
	@objc func targetMethod7(_ sender: UIButton){
		if Equal {
		Equal = false
		result.text = ""
		workSpace.text = ""
		}
		result.text = result.text! + "6"
	}
	@objc func targetMethod8(_ sender: UIButton){
		if Equal {
		Equal = false
		result.text = ""
		workSpace.text = ""
		}
		result.text = result.text! + "7"
	}
	@objc func targetMethod9(_ sender: UIButton){
		if Equal {
		Equal = false
		result.text = ""
		workSpace.text = ""
		}
		result.text = result.text! + "8"
	}
	@objc func targetMethod10(_ sender: UIButton){
		if Equal {
		Equal = false
		result.text = ""
		workSpace.text = ""
		}
		result.text = result.text! + "9"
	}
	@objc func targetMethod11(_ sender: UIButton){
		if Equal {
		Equal = false
		result.text = ""
		workSpace.text = ""
		}
		result.text = result.text! + "0"
	}
	@objc func targetMethod12(_ sender: UIButton){
		if result.text!.count != 0 {
		input1 = Double(result.text! + "")!
		Addition = true
		decimal = false
		workSpace.text = result.text! + "+"
		result.text = nil
		}
	}
	@objc func targetMethod13(_ sender: UIButton){
		if result.text!.count != 0 {
		input1 = Double(result.text! + "")!
		Subtract = true
		decimal = false
		workSpace.text = result.text! + "-"
		result.text = nil
		}
	}
	@objc func targetMethod14(_ sender: UIButton){
		if result.text!.count != 0 {
		input1 = Double(result.text! + "")!
		Multiplication = true
		decimal = false
		workSpace.text = result.text! + "*"
		result.text = nil
		}
	}
	@objc func targetMethod15(_ sender: UIButton){
		if result.text!.count != 0 {
		input1 = Double(result.text! + "")!
		Division = true
		decimal = false
		workSpace.text = result.text! + "/"
		result.text = nil
		}
	}
	@objc func targetMethod16(_ sender: UIButton){
		Equal = true
		if Addition || Subtract || Multiplication || Division {
		input2 = Double(result.text! + "")!
		workSpace.text = result.text! + "="
		}
		if Addition {
		result.text = String(input1 + input2)
		Addition = false
		}
		if Subtract {
		result.text = String(input1 - input2)
		Subtract = false
		}
		if Multiplication {
		result.text = String(input1 * input2)
		Multiplication = false
		}
		if Division {
		result.text = String(input1 / input2)
		Division = false
		}
	}
	@objc func targetMethod17(_ sender: UIButton){
		workSpace.text = ""
		result.text = ""
		input1 = 0.0
		input2 = 0.0
	}
}