package com.example.android.jobaya_employee;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class FragmentMatchedJobs extends Fragment {
    static List<Job> matchedJobs;
    static AdapterAllJobs adapterMatchedJobs;
    static LinearLayout errorMessage;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        matchedJobs = new ArrayList<>();
        adapterMatchedJobs = new AdapterAllJobs(getContext() , matchedJobs , true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_matchedjobs_layout , container , false);

        getUserInfo();
      // jobayaApi.getUserInfo();

        RecyclerView recyclerView = v.findViewById(R.id.recycler_view_matched_jobs);
        recyclerView.setAdapter(adapterMatchedJobs);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        errorMessage = v.findViewById(R.id.error_matched_jobs);
        errorMessage.setVisibility(View.INVISIBLE);

        return v;
    }
    private String getResumeUrl = "https://jobayaback.herokuapp.com/resume/email/"+LoginActivity.userEmail;
    public void getUserInfo()
    {
        // start the loading progress
        final ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setTitle("Please wait");
        progressDialog.setMessage("loading data...");
        progressDialog.setCancelable(false);
        progressDialog.show();


        // start the volley request
        StringRequest stringRequest = new StringRequest(Request.Method.GET, getResumeUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // cancel the loading on success
                progressDialog.cancel();

                // request successful , parse the json response
                Log.i("response" , response);
                try {
                    JSONArray jobsArray = new JSONArray(response);
                    if(jobsArray.length()>0)
                    {

                        JSONObject resumeJSON = jobsArray.getJSONObject(jobsArray.length()-1);
                        String education = resumeJSON.isNull("education") ? null : resumeJSON.getString("education");
                        String experience = resumeJSON.isNull("experience") ? null : resumeJSON.getString("experience");
                        String skills = resumeJSON.isNull("skills") ? null : resumeJSON.getString("skills");
                        String gender = resumeJSON.isNull("gender") ? null : resumeJSON.getString("gender");



                       JobayaApi jobayaApi = new JobayaApi(getContext());
                       jobayaApi.findMatchedJobs(gender , education);

                    }
                    else
                    {
                        errorMessage.setVisibility(View.VISIBLE);
                        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                        builder.setCancelable(false);
                        builder.setTitle("Find jobs that match you");
                        builder.setIcon(R.drawable.resume);
                        builder.setMessage("please fill your resume to get your job matches");
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                        builder.show();
                    }








                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // cancel the loading on fail
                progressDialog.cancel();





            }
        });

        Volley.newRequestQueue(getContext()).add(stringRequest);



    }
}
