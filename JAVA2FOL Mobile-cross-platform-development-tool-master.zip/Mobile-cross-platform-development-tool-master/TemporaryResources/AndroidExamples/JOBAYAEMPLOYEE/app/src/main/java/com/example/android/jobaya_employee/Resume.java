package com.example.android.jobaya_employee;

public class Resume {
    String occupation;
    String exp;
    String skills;
    String gender;

    public Resume (String ocp , String exp , String skills , String gender)
    {

        this.occupation = ocp;
        this.exp = exp;
        this.skills = skills;
        this.gender = gender;

    }
}
