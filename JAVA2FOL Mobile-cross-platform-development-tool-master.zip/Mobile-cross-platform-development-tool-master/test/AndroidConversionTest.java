import UIConversion.UIUtilites.UIUtilities;
import androidToiOS.Main;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

import static org.junit.Assert.assertEquals;

public class AndroidConversionTest {
    private static final boolean PRODUCE_COMPLETE_XCODE_PROJECT = false ;
    private boolean setUpOnce = false;
    private ArrayList<String> testProjectDirectories = new ArrayList<>();
    private String androidConversionTestDirectoryPath = "TestResources/AndroidConversionTestProjects/";

    @Before
    public void setUp() throws Exception {
        if (!setUpOnce) {
            testProjectDirectories.add("EquationSolver");
            testProjectDirectories.add("SecondScreenAndroid");
        }
    }

    @Test
    public void testAndroidConversion() throws IOException{
        for (String testProjectDirectoryPath : testProjectDirectories) {
            String actualOutputDirectory = Main.convertAndroidToIOSProject(new File(androidConversionTestDirectoryPath + testProjectDirectoryPath ), PRODUCE_COMPLETE_XCODE_PROJECT);
            File expectedOutputDirectory = new File(androidConversionTestDirectoryPath + testProjectDirectoryPath + " Expected Output");
            //System.out.println(actualOutputDirectory.getName());
            //System.out.println(androidConversionTestDirectoryPath + testProjectDirectoryPath);

            try{
                for (final File expectedFile : Objects.requireNonNull(expectedOutputDirectory.listFiles())) {
                    String fileName = expectedFile.getName();
                    File actualFile = new File(actualOutputDirectory+"/"+fileName);

                    String expectedCode = Main.readFile(expectedFile);
                    String actualCode = Main.readFile(actualFile);
                    assertEquals(Main.removeAllWhiteSpaces(expectedCode), Main.removeAllWhiteSpaces(actualCode));
                }
            }catch(NullPointerException n){
                System.out.println("Missing or no files were produced from the conversion process");
                assertEquals(0,1);
            }
            UIUtilities.idCounter=0;
        }

    }
}
