import JavaToSwiftConversion.AndroidIntent;
import JavaToSwiftConversion.ConvertedJavaFileData;
import UIConversion.StoryboardMaker;
import UIConversion.UIUtilites.UIUtilities;

import androidToiOS.AndroidProject;
import androidToiOS.Main;
import org.junit.Before;
import org.junit.Test;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

import static org.junit.Assert.assertEquals;

public class UIConverterTest {
    boolean setUpOnce = false;
    private ArrayList<String> testFileNames = new ArrayList<>();
    private String testFilesDirectoryPath = "TestResources/UIConversionTestFiles";

    //this function is called before everyTest
    @Before
    public void setUp() throws Exception {
        if (!setUpOnce) {
            testFileNames.add("Button");
            testFileNames.add("TextView");
            testFileNames.add("EditText");
        }
    }

    @Test
    public void testUIConversion() throws IOException {
        for (String testFileName : testFileNames) {
            testStoryboardConversion(testFileName);
        }
        System.out.println("\nTested UI Converter with " + testFileNames.size() + " files\n");
    }

    private void testStoryboardConversion(String testFileName) throws IOException {
        String sourceXMLCode = Main.readFile(testFilesDirectoryPath + '/' + testFileName + ".xml");
        String storyboardEquivalentCode = Main.readFile(testFilesDirectoryPath + '/' + testFileName + ".storyboard");

        ConvertedJavaFileData convertedJavaFileData = formTestConvertedJavaFileData();
        AndroidProject androidProject = new AndroidProject();

        StoryboardMaker storyboardMaker = new StoryboardMaker();
        storyboardMaker.addNewScene(sourceXMLCode, convertedJavaFileData, androidProject);

        String storyboardConvertedCode = storyboardMaker.toString();
        //Main.writeFile(testFilesDirectoryPath + '/' + testFileName + ".storyboard",storyboardConvertedCode);

        assertEquals(Main.removeAllWhiteSpaces(storyboardEquivalentCode), Main.removeAllWhiteSpaces(storyboardConvertedCode));
        UIUtilities.idCounter=0;
    }

    private ConvertedJavaFileData formTestConvertedJavaFileData() {

        AndroidIntent androidIntent = new AndroidIntent();
        androidIntent.setTargetedActivity("target");
        androidIntent.setCurrentActivity("current");
        ArrayList<AndroidIntent> androidIntentArrayList = new ArrayList<>();
        androidIntentArrayList.add(androidIntent);

        HashMap<String,String> mConnections = new HashMap<>();
        mConnections.put("buttonIDinXML","buttonIDinMainActivity");
        ConvertedJavaFileData convertedJavaFileData = new ConvertedJavaFileData("",mConnections,"tunaController");
        convertedJavaFileData.setExplicitIntents(androidIntentArrayList);

        return convertedJavaFileData;
    }

}