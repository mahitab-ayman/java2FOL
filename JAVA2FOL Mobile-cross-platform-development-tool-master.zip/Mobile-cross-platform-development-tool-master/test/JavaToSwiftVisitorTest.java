
import JavaToSwiftConversion.JavaToSwiftVisitor;
import androidToiOS.Controller;
import androidToiOS.Main;
import generatedAntlr.JavaLexer;
import generatedAntlr.JavaParser;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.junit.Before;
import org.junit.Test;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;


public class JavaToSwiftVisitorTest {
    private JavaToSwiftVisitor visitor;
    private JavaParser parser;// share single parser instance
    boolean setUpOnce = false;
    private ArrayList<String> testFileNames = new ArrayList<>();
    private String testFilesDirectoryPath = "TestResources/JavaConversionTestFiles";

    //this function is called before everyTest
    @Before
    public void setUp() throws Exception {
        if (!setUpOnce) {
            parser = new JavaParser(null);
            visitor = new JavaToSwiftVisitor();
            testFileNames.add("Calculation");
            testFileNames.add("MainActivity");
            testFileNames.add("Button");
            testFileNames.add("CheckBox");
            testFileNames.add("EditText");
            testFileNames.add("ImageView");
            testFileNames.add("TextView");
        }
    }

    @Test
    public void visitLocalVariableDeclarationStatement() {
        testVisitorFunction("TestResources/LocalVariableDeclarationStatementTestData.json"
                ,"localVariableDeclarationStatement","visitLocalVariableDeclarationStatement"
                , JavaParser.LocalVariableDeclarationStatementContext.class);
    }

    private void testVisitorFunction(String jsonFileTestDataPath, String parserMethodName,String visitorMethodName,
                                     Class visitorMethodArgumentClass){
        HashMap<String, String> tests = loadTests(jsonFileTestDataPath);
        Method parserMethod = null;
        Method visitorMethod = null;

        try {
            parserMethod = JavaParser.class.getMethod(parserMethodName);

            //converting first character to capital;

            Class[] parameterTypes = new Class[1];
            parameterTypes[0] =visitorMethodArgumentClass;
            visitorMethod = JavaToSwiftVisitor.class.getMethod(visitorMethodName,parameterTypes);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }

        for (Map.Entry<String, String> javaTest : tests.entrySet()) {
            ANTLRInputStream input = new ANTLRInputStream(javaTest.getKey());
            JavaLexer lexer = new JavaLexer(input);
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            parser.setInputStream(tokens);
            ParseTree tree; // parse
            String swiftcodeReturned = null;
            try {
                tree = (ParseTree) parserMethod.invoke(parser,null);
                Object[] parameters = {tree};

                swiftcodeReturned = (String) visitorMethod.invoke(visitor,parameters);
            } catch (IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
            }
            assertEquals(javaTest.getValue().trim(), swiftcodeReturned.trim());
        }
        System.out.println("Tested "+parserMethodName+" with "+tests.size()+" tests");
    }

    private HashMap<String, String> loadTests(String fileName) {
        Gson gson = new GsonBuilder().create();
        HashMap tests = null;
        try {
            Reader reader = new InputStreamReader(new FileInputStream(fileName));

            tests = gson.fromJson(reader, HashMap.class);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return tests;
    }

    @Test
    public void visitArrayInitializer() {
        testVisitorFunction("TestResources/arrayInitializerTestData.json"
                ,"arrayInitializer","visitArrayInitializer",JavaParser.ArrayInitializerContext.class);
    }

    @Test
    public void visitArrayCreatorRest() {
        testVisitorFunction("TestResources/arrayCreatorRestTestData.json"
                ,"arrayCreatorRest","visitArrayCreatorRest",JavaParser.ArrayCreatorRestContext.class);
    }

    @Test
    public void visitIfStatement(){
        testVisitorFunction("TestResources/ifStatementTestData.json"
                ,"statement","visitIfStatement",JavaParser.IfStatementContext.class);
    }

    @Test public void visitWhileStatement(){
        testVisitorFunction("TestResources/whileStatementTestData.json"
                ,"statement","visitWhileStatement",JavaParser.WhileStatementContext.class);
    }

    @Test public void visitDoWhileStatement(){
        testVisitorFunction("TestResources/doWhileStatementTestData.json"
                ,"statement","visitDoWhileStatement",JavaParser.DoWhileStatementContext.class);
    }


    @Test
    public void visitAssignmentExpression() {
        testVisitorFunction("TestResources/assignmentExpressionTestData.json","expression"
                ,"visitAssignmentExpression", JavaParser.AssignmentExpressionContext.class);
    }

    @Test
    public void visitForStatement(){
        testVisitorFunction("TestResources/forStatementTestData.json","statement"
                ,"visitForStatement", JavaParser.ForStatementContext.class);
    }

    @Test
    public void visitExpressionTemp2() {
        testVisitorFunction("TestResources/expressionTemp2TestData.json","expression"
                ,"visitExpressionTemp2",JavaParser.ExpressionTemp2Context.class);
    }

    @Test
    public void visitExpressionTemp1() {
        testVisitorFunction("TestResources/expressionTemp1TestData.json","expression"
                ,"visitExpressionTemp1",JavaParser.ExpressionTemp1Context.class);
    }

    @Test
    public void visitConditionalExpression() {
        testVisitorFunction("TestResources/conditionalExpressionTestData.json","expression"
                ,"visitConditionalExpression",JavaParser.ConditionalExpressionContext.class);
    }

    @Test
    public void testFunctionCalls() {

        testVisitorFunction("TestResources/functionCallTestData.json","block"
                ,"visitBlock",JavaParser.BlockContext.class);
    }


    @Test
    public void visitSwitchLabel() {
        testVisitorFunction("TestResources/switchLabelTestData.json"
                ,"switchLabel","visitSwitchLabel",JavaParser.SwitchLabelContext.class);
    }

    @Test
    public void visitSwitchBlockStatementGroup() {
        testVisitorFunction("TestResources/switchBlockStatementGroupTestData.json"
                ,"switchBlockStatementGroup","visitSwitchBlockStatementGroup",JavaParser.SwitchBlockStatementGroupContext.class);
    }
    @Test
    public void visitSwitchBlock(){
        testVisitorFunction("TestResources/switchBlockTestData.json"
                ,"switchBlock","visitSwitchBlock",JavaParser.SwitchBlockContext.class);
    }
    @Test
    public void visitSwitchStatement(){
        testVisitorFunction("TestResources/switchStatementTestData.json"
                ,"statement","visitSwitchStatement",JavaParser.SwitchStatementContext.class);
    }
    @Test
    public void visitClassDeclaration(){
        testVisitorFunction("TestResources/classDeclarationTestData.json"
                ,"typeDeclaration","visitTypeDeclaration",JavaParser.TypeDeclarationContext.class);
    }

    @Test
    public void visitConstructorDeclaration(){
    }

    @Test
    public void testCompleteFilesConversion() throws IOException {
        for (String testFileName : testFileNames) {
            //todo use controller convertToSwift
            File javaFile = new File(testFilesDirectoryPath+'/'+testFileName+".java");
            //.replaceAll("\r\n","\n").replace("    ","\t")
            String equivalentSwiftCode = Main.readFile(testFilesDirectoryPath+'/'+testFileName+".swift");
            equivalentSwiftCode = Main.removeAllWhiteSpaces(equivalentSwiftCode);
            String swiftConvertedCode = Controller.convertJavaFile(javaFile).swiftCode;
            swiftConvertedCode = Main.removeAllWhiteSpaces(swiftConvertedCode);
            assertEquals(equivalentSwiftCode,swiftConvertedCode);
        }
        System.out.println("\nTested Java to Swift Converter with "+ testFileNames.size()+" files\n");
    }
}