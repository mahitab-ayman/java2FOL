import UIKit


 class MainActivity: UIViewController{
	@IBOutlet weak var button:UIButton!

	override public func viewDidLoad() {
		super.viewDidLoad()
		//todo Convert: button.setOnClickListener(new View.OnClickListener() {
		
		            @Override
		            public void onClick(View arg0) {
		
		                Intent intent = new Intent(arg0.getContext(), Main2Activity.class);
		                startActivity(intent);
		
		            }
		
		        });
		
	}

}