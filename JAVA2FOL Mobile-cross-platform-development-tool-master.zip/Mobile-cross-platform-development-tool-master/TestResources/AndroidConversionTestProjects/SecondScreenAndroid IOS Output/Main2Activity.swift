import UIKit


 class Main2Activity: UIViewController{
	@IBOutlet weak var button2:UIButton!

	override public func viewDidLoad() {
		super.viewDidLoad()
		//todo Convert: button2.setOnClickListener(new View.OnClickListener() {
		
		            @Override
		            public void onClick(View arg0) {
		
		                Intent intent = new Intent(arg0.getContext(), MainActivity.class);
		                startActivity(intent);
		
		            }
		
		        });
		
	}

}