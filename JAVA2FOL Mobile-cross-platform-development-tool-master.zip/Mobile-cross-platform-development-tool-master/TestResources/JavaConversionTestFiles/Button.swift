import UIKit


 class MainActivity: UIViewController{
	@IBOutlet weak var button:UIButton!

	override internal func viewDidLoad() {
		super.viewDidLoad()
		button.removeTarget(nil, action: nil, for: .allEvents)
		button.addTarget(self, action: #selector(targetMethod0), for: .touchUpInside)
		button.setTitle("newButtonTitle" ,for: .normal)
	}

	@objc func targetMethod0(_ sender: UIButton){
		print("Hello")
	}
}