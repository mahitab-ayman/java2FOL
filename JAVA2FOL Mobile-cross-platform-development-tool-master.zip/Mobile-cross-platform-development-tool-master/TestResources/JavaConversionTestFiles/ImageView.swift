import UIKit

 class MainActivity: UIViewController{
	@IBOutlet weak var imageView:UIImageView!

	override internal func viewDidLoad() {
		super.viewDidLoad()
		imageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(targetFn)))
		imageView.isUserInteractionEnabled = true
	}

	@objc func targetMethod0(_ sender: UIGestureRecognizer){
		print("Image Tapped")
	}
}