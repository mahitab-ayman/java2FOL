import UIKit


 class MainActivity: UIViewController{
	@IBOutlet weak var textField:UITextField!
	@IBOutlet weak var editable:UITextField!
	var x:Int = editable.text!.count

	override internal func viewDidLoad() {
		super.viewDidLoad()
		textField.removeTarget(nil, action: nil, for: .allEvents)
		textField.addTarget(self, action: #selector(targetMethod0(_:)), for: .editingChanged)
	}

	@objc func targetMethod0(_ editable:UITextField){
		print(editable.text!)
	}
}