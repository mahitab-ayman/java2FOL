import UIKit

 class MainActivity: UIViewController{
	@IBOutlet weak var checkBox:UISwitch!

	override internal func viewDidLoad() {
		super.viewDidLoad()
		checkBox.removeTarget(nil, action: nil, for: .allEvents)
		checkBox.addTarget(self, action: #selector(targetMethod0), for: UIControlEvents.valueChanged)
	}

	@objc func targetMethod0(checkBox : UISwitch){
		print(checkBox.isOn)
	}
}