import UIKit


 class MainActivity: UIViewController{

	override internal func viewDidLoad() {
		super.viewDidLoad()
		var textView:UILabel! = findViewById(R.id.text_id)
		textView.text = "david"
		textView.text!
	}

}