package UIConversion.UIUtilites;

public class UILabel extends UIControlComponent {

    public String text = "Label";
    public boolean adjustsFontSizeToFit = false;
    //public boolean highlighted = false;

    public UIColor textColor;
    public UIColor highlightedColor;

    public BaselineAdjustment baselineAdjustment = BaselineAdjustment.alignBaselines;
    public UIFontDescription fontDescription;
    public UIUtilities.LineBreakMode lineBreakMode = UIUtilities.LineBreakMode.tailTruncation;
    public UIUtilities.TextAlignment textAlignment = UIUtilities.TextAlignment.natural;

    public UILabel(){
        id = UIUtilities.getID();
        frame = new UIRect(42,21);
        autoresizingMask = new UIAutoresizingMask("autoresizingMask");
        fontDescription = new UIFontDescription("fontDescription");
    }

    public String getLabelLocalizable(String stringKey, String stringValue) {
        return "\n /* Class = \"UILabel\"; text = "
                + UIUtilities.getStringQuote(stringKey)
                + "; ObjectID = " + UIUtilities.getStringQuote(id)
                + "; */\n" + UIUtilities.getStringQuote(id + ".text")
                + " = "
                + UIUtilities.getStringQuote(stringValue);
    }

    public enum BaselineAdjustment{
        alignBaselines, alignCenters, none
    }
    @Override
    public String toString() {
        StringBuilder returnValue = new StringBuilder
                ("<label"+
                " opaque=" + UIUtilities.getBooleanStringQuote(opaque)+
                " userInteractionEnabled=" + UIUtilities.getBooleanStringQuote(userInteractionEnabled)+
                " contentMode=" + UIUtilities.getStringQuote(contentMode.name()) +
                " horizontalHuggingPriority=" + UIUtilities.getStringQuote(String.valueOf(horizontalHuggingPriority)) +
                " verticalHuggingPriority=" + UIUtilities.getStringQuote(String.valueOf(verticalHuggingPriority)) +
                " fixedFrame=" + UIUtilities.getBooleanStringQuote(fixedFrame) +
                " text=" + UIUtilities.getStringQuote(text) +
                " textAlignment=" + UIUtilities.getStringQuote(textAlignment.name()) +
                " lineBreakMode=" + UIUtilities.getStringQuote(lineBreakMode.name()) +
                " baselineAdjustment=" + UIUtilities.getStringQuote(baselineAdjustment.name()) +
                " adjustsFontSizeToFit=" + UIUtilities.getBooleanStringQuote(adjustsFontSizeToFit)+
                " translatesAutoresizingMaskIntoConstraints=" + UIUtilities.getBooleanStringQuote(translatesAutoresizingMaskIntoConstraints)+
                " id=" + UIUtilities.getStringQuote(id) +
                ">");
        returnValue.append(frame).append(autoresizingMask).append(fontDescription);

        if(textColor!=null)
            returnValue.append(textColor);
        else
            returnValue.append("<nil key=\"textColor\"/>");
        if(highlightedColor!=null)
            returnValue.append(highlightedColor);
        else
            returnValue.append("<nil key=\"highlightedColor\"/>");

        if(backgroundColor!=null)
            returnValue.append(backgroundColor);
        if(tintColor!=null)
            returnValue.append(tintColor);

        if(connections!=null)
            returnValue.append(connections);

        returnValue.append("</label>").append(unSupportedCode);

        return returnValue.toString();
    }
}
