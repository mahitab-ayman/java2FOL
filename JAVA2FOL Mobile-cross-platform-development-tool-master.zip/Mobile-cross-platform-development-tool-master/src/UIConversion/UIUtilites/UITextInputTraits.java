package UIConversion.UIUtilites;

public class UITextInputTraits {
    String key;
    public TextContentType textContentType;

    public UITextInputTraits(String key){
        this.key=key;
        textContentType = TextContentType.unspecified;
    }

    @Override
    public String toString() {
        StringBuilder value = new StringBuilder();
        value.append("<textInputTraits")
                .append(" key=").append(UIUtilities.getStringQuote(key));
        if(textContentType!=TextContentType.unspecified)
            value.append(" textContentType=").append(UIUtilities.getStringQuote(textContentType.name()));
        value.append("/>");
        return value.toString();
    }

    public enum TextContentType {
        url, unspecified, email, password
    }
}
