package UIConversion.UIUtilites;

public class UINavigationItem {
    public String key = "navigationItem";
    public String id = UIUtilities.getID();

    @Override
    public String toString() {
        return "<navigationItem" +
                " key=" + UIUtilities.getStringQuote(key) +
                " id=" + UIUtilities.getStringQuote(id) +
                "/>";
    }
}
