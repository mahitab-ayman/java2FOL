package UIConversion.UIUtilites;

public class UIState {
    public String key;
    public String title;

    public UIState(String key) {
        this.key = key;
    }

    public UIState(String key, String title){
        this.key = key;
        this.title = title;
    }

    @Override
    public String toString() {
        return "<state" +
                " key=" + UIUtilities.getStringQuote(key) +
                " title=" + UIUtilities.getStringQuote(title) +
                "/>";
    }
}
