package UIConversion.UIUtilites;

public class UIPlaceholder {
    //todo: fix placeholder
    String id = UIUtilities.getID();;
    PlaceholderIdentifier placeholderIdentifier = PlaceholderIdentifier.IBFirstResponder;
    String sceneMemberID = "firstResponder";
    enum PlaceholderIdentifier{
        IBFirstResponder
    }
    @Override
    public String toString() {
        return "<placeholder" +
                " placeholderIdentifier=" + UIUtilities.getStringQuote(placeholderIdentifier.name()) +
                " id=" + UIUtilities.getStringQuote(id) +
                " sceneMemberID=" + UIUtilities.getStringQuote(sceneMemberID) +
                "/>";
    }
}
