package UIConversion.UIUtilites;

public class UIColor{
    public String key;
    public double red, green, blue, white, alpha=1;

    public ColorSpace colorSpace = ColorSpace.custom;
    public CustomColorSpace customColorSpace = CustomColorSpace.sRGB;

    public enum ColorSpace{
        custom, calibratedWhite
    }

    public enum CustomColorSpace{
        sRGB
    }

    //todo:maintain constructor for different color spaces
    public UIColor(String key) {
        this.key = key;
        colorSpace = ColorSpace.custom;
        customColorSpace = CustomColorSpace.sRGB;
        red = green = blue = 0;
    }

    @Override
    public String toString() {
        StringBuilder returnValue = new StringBuilder
                ("<color" +
                " key=" + UIUtilities.getStringQuote(key));
        if(colorSpace==ColorSpace.custom){
            returnValue.append(" red=").append( UIUtilities.getStringQuote(String.valueOf(red)))
                    .append(" green=").append(UIUtilities.getStringQuote(String.valueOf(green)))
                    .append(" blue=").append(UIUtilities.getStringQuote(String.valueOf(blue)))
                    .append(" alpha=").append(UIUtilities.getStringQuote(String.valueOf(alpha)))
                    .append(" colorSpace=").append(UIUtilities.getStringQuote(colorSpace.name()))
                    .append(" customColorSpace=").append(UIUtilities.getStringQuote(customColorSpace.name()))
                    .append("/>");
        }
        else if(colorSpace==ColorSpace.calibratedWhite) {
            returnValue.append(" white=").append(UIUtilities.getStringQuote(String.valueOf(white)))
                    .append(" alpha=").append(UIUtilities.getStringQuote(String.valueOf(alpha)))
                    .append(" colorSpace=").append(UIUtilities.getStringQuote(colorSpace.name()))
                    .append("/>");
        }

        return returnValue.toString();
    }

    public void white() {
        colorSpace=ColorSpace.calibratedWhite;
        white=1;
    }
}
