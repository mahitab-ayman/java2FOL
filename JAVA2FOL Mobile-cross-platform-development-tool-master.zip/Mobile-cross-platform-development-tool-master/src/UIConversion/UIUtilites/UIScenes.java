package UIConversion.UIUtilites;

import java.util.ArrayList;

public class UIScenes{
    public ArrayList<UIScene> sceneArrayList;

    public UIScenes(){
        sceneArrayList = new ArrayList<>();
    }

    @Override
    public String toString() {
        StringBuilder returnValue = new StringBuilder("<scenes>");
        if (sceneArrayList !=null){
            for (UIScene uiScene : sceneArrayList) {
                returnValue.append(uiScene);
            }
        }

        returnValue.append("</scenes>");
        return returnValue.toString();
    }
}
