package UIConversion.UIUtilites;

public class UITableViewCell extends UIViewComponent{
    String selectionStyle = SelectionStyle.DEFAULT;
    int indentationWidth = 10;

    UITableViewCellContentView tableViewCellContentView;

    public UITableViewCell(){
        super.clipsSubviews = true;
        super.contentMode = ContentMode.scaleToFill;
        id = UIUtilities.getID();

        //todo: connect width and height to parent
        super.frame = new UIRect(240,44);
        super.autoresizingMask = new UIAutoresizingMask();
        tableViewCellContentView = new UITableViewCellContentView();

    }

    class SelectionStyle{
        public static final String DEFAULT = "default";
    }

    public String toString() {
        StringBuilder value = new StringBuilder("<tableViewCell");
        value.append(" clipsSubviews").append(UIUtilities.getBooleanStringQuote(clipsSubviews))
                .append(" contentMode").append(UIUtilities.getStringQuote(contentMode.name()))
                .append(" selectionStyle").append(UIUtilities.getStringQuote(selectionStyle))
                .append(" indentationWidth").append(UIUtilities.getStringQuote(String.valueOf(indentationWidth)))
                .append(" id").append(UIUtilities.getStringQuote(id))
                .append(">");
        return value.toString();
    }
}
