package UIConversion.UIUtilites;

public class UIUtilities {

    static String indentation = "";

    public static String incrementIndentation(){
        indentation+="/t";
        return indentation;
    }

    public static String decrementIndentation(){
        if(!indentation.isEmpty()){
            indentation=indentation.substring(0,indentation.length()-1);
        }
        return indentation;
    }

    public static int idCounter = 0;
    static float pointX = 0;
    static float pointY = 0;

    public static int supportedFeaturesCounter = 0;
    public static int supportedComponentsCounter = 0;
    public static int unsupportedFeaturesCounter = 0;
    public static int unsupportedComponentsCounter = 0;

    public static void resetStaticVariables(){
        //idCounter=0;
        pointX=0;
        pointY=0;
    }
    public static float getX(float width){
        if(pointX>=375) {
            pointX = 0;
            pointY+= 50;
        }
        float x = pointX;
        pointX+=width;
        return x;
    }
    public static float getY(){
        return pointY;
    }
    public static String getID(){
        idCounter++;
        return "id" + idCounter;
    }

    public static String getStringCommented(String text) {
        return "\n<!--" + text + "-->";
    }

    public static void resetCounters() {
        supportedFeaturesCounter=0;
        supportedComponentsCounter=0;
        unsupportedFeaturesCounter=0;
        unsupportedComponentsCounter=0;
    }

    enum LineBreakMode{
        characterWrap, clip, headTruncation, middleTruncation, tailTruncation, wordWrap
    }

    public static String booleanString(boolean bool){
        if (bool){
            return "YES";
        }
        return "NO";
    }
    public static String getBooleanStringQuote(boolean bool){
        return  "\""+ booleanString(bool)+"\"";
    }

    public static String getStringQuote(String string){
        return  "\""+string+"\"";
    }

    public enum TextAlignment {
        center,justified,left,natural,right
    }

    public enum EventType{
        touchDown, touchDownRepeat, touchDragInside, touchDragOutside,
        touchDragEnter, touchDragExit, touchUpInside, touchUpOutside,
        touchCancel, valueChanged, primaryActionTriggered, editingDidBegin,
        editingChanged, editingDidEnd, editingDidEndOnExit, allTouchEvents,
        allEditingEvents, applicationReserved, systemReserved, allEvents
    }
    public static double getConversionPercentage(){
        int supportedComponents = UIUtilities.supportedComponentsCounter;
        int supportedFeatures = UIUtilities.supportedFeaturesCounter;
        int totalComponents = UIUtilities.supportedComponentsCounter+UIUtilities.unsupportedComponentsCounter;
        int totalFeatures = UIUtilities.supportedFeaturesCounter+UIUtilities.unsupportedFeaturesCounter;

        double supportedPercentage = 66.6666667*((supportedComponents/(float)totalComponents) + 0.5*(supportedFeatures/(float)totalFeatures));
        if(supportedPercentage>=0)
            return supportedPercentage;
        else return 0;
    }
}
