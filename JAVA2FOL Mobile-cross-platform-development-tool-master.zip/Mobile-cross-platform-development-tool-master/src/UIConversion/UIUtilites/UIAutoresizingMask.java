package UIConversion.UIUtilites;

public class UIAutoresizingMask {
    String key;
    private boolean flexibleMaxX = true, flexibleMaxY=true;
    private boolean flexibleMinX = false, flexibleMinY = false;
    //boolean flexibleWidth, flexibleRightMargin;


    public UIAutoresizingMask() {
        this.key = "autoresizingMask";
    }

    public UIAutoresizingMask(String key) {
        this.key = key;
    }

    @Override
    public String toString() {
        StringBuilder returnValue = new StringBuilder
                ("<autoresizingMask" +
                " key=" + UIUtilities.getStringQuote(key));
        if(!flexibleMaxX&&!flexibleMinX)
                returnValue.append(" widthSizable=").append(UIUtilities.getBooleanStringQuote(true));
        if (flexibleMinX)
                returnValue.append(" flexibleMinX=").append(UIUtilities.getBooleanStringQuote(flexibleMinX));
        if (flexibleMaxX)
                returnValue.append(" flexibleMaxX=").append(UIUtilities.getBooleanStringQuote(flexibleMaxX));

        if(!flexibleMaxY&&!flexibleMinY)
            returnValue.append(" heightSizable=").append(UIUtilities.getBooleanStringQuote(true));

        if (flexibleMinY)
            returnValue.append(" flexibleMinY=").append(UIUtilities.getBooleanStringQuote(flexibleMinY));
        if (flexibleMaxY)
            returnValue.append(" flexibleMaxY=").append(UIUtilities.getBooleanStringQuote(flexibleMaxY));


        //" flexibleWidth=" + UIUtilities.getBooleanStringQuote(flexibleWidth) +
        //" flexibleRightMargin=" + UIUtilities.getBooleanStringQuote(flexibleRightMargin) +

        returnValue.append("/>");
        return returnValue.toString();
    }

    public void setFlexibleMaxX(boolean flexibleMaxX) {
        this.flexibleMaxX=flexibleMaxX;
    }
    public void setFlexibleMaxY(boolean flexibleMaxY) {
        this.flexibleMaxY=flexibleMaxY;
    }
    public void setFlexibleMinX(boolean flexibleMinX) {
        this.flexibleMinX=flexibleMinX;
    }
    public void setFlexibleMinY(boolean flexibleMinY) {
        this.flexibleMinY=flexibleMinY;
    }
}
