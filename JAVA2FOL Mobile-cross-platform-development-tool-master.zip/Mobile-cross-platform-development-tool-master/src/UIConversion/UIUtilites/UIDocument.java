package UIConversion.UIUtilites;

public class UIDocument {
    //todo:maintain this intro part in a proper way
    public String intro = "<device id=\"retina4_7\" orientation=\"portrait\">\n" +
            "        <adaptation id=\"fullscreen\"/>\n" +
            "    </device>\n" +
            "    <dependencies>\n" +
            "        <deployment identifier=\"iOS\"/>\n" +
            "        <plugIn identifier=\"com.apple.InterfaceBuilder.IBCocoaTouchPlugin\" version=\"12086\"/>\n" +
            "        <capability name=\"documents saved in the Xcode 8 format\" minToolsVersion=\"8.0\"/>\n" +
            "    </dependencies>";
    public UIScenes scenes;
    //todo:add other attributes in the tag itself and in its content
    public UIColor tintColor;

    public UIDocument(){
        scenes = new UIScenes();
    }

    @Override
    public String toString() {
        StringBuilder returnValue = new StringBuilder("<document type=\"com.apple.InterfaceBuilder3.CocoaTouch.Storyboard.XIB\" version=\"3.0\" toolsVersion=\"12118\" systemVersion=\"16A323\" targetRuntime=\"iOS.CocoaTouch\" propertyAccessControl=\"none\" useAutolayout=\"YES\" useTraitCollections=\"YES\" colorMatched=\"YES\">\n");
        returnValue.append(intro).append(scenes);

        if (tintColor!=null)
            returnValue.append(tintColor);

        returnValue.append("</document>");
        return returnValue.toString();
    }
}
