package UIConversion.UIUtilites;

public class UIAction {
    public Selector selector = Selector.buttonPressed;
    public String destination = "";
    public UIUtilities.EventType eventType = UIUtilities.EventType.touchUpInside;
    public String id = UIUtilities.getID();

    public enum Selector{
        buttonPressed
    }

    @Override
    public String toString() {
        return "<action" +
                " selector=" + UIUtilities.getStringQuote(selector.name() + ":") +
                " destination=" + UIUtilities.getStringQuote(destination) +
                " eventType=" + UIUtilities.getStringQuote(eventType.name()) +
                " id=" + UIUtilities.getStringQuote(id) +
                ">";
    }
}
