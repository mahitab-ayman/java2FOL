package UIConversion.UIUtilites;

public class UIControlComponent extends UIViewComponent {
    public UIState state;
    public UIConnections connections;
    public ContentHorizontalAlignment contentHorizontalAlignment = ContentHorizontalAlignment.center;
    public ContentVerticalAlignment contentVerticalAlignment = ContentVerticalAlignment.center;

    public enum ContentVerticalAlignment {
        bottom,center,fill,top
    }

    public enum ContentHorizontalAlignment {
        center,fill,leading,left,right,trailing
    }

    public UIControlComponent(){
    }
}
