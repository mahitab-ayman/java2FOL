package UIConversion.UIUtilites;

public class UIViewComponent extends XMLTag {
    public String id;
    public ContentMode contentMode = ContentMode.scaleToFill;
    public UIRect frame;
    public UIAutoresizingMask autoresizingMask;
    public UIColor backgroundColor;
    public UIColor tintColor;
    public int horizontalHuggingPriority = 251;
    public int verticalHuggingPriority = 251;
    public boolean opaque = false;
    public boolean fixedFrame = true;
    public boolean translatesAutoresizingMaskIntoConstraints = false;
    public boolean userInteractionEnabled = false;
    public boolean clipsSubviews;
    public String unSupportedCode;

    public UIViewComponent(){
        id = UIUtilities.getID();
        unSupportedCode = "";
    }

    public String getComponentLocalizable(String stringKey, String stringValue) {
        if (this instanceof UIButton){
            return ((UIButton)this).getButtonLocalizable(stringKey, stringValue);
        }
        else if (this instanceof UILabel){
            return ((UILabel)this).getLabelLocalizable(stringKey, stringValue);
        }
        else if (this instanceof UISearchBar){
            return ((UISearchBar)this).getSearchBarLocalizable(stringKey, stringValue);
        }
        else if (this instanceof UITextField){
            return ((UITextField)this).getTextFieldLocalizable(stringKey, stringValue);
        }
        return null;
    }

    public void setText(String value) {
        if (this instanceof UIButton)
            ((UIButton) this).state.title = value;

        else if (this instanceof UILabel)
            ((UILabel) this).text = value;
    }

    public enum ContentMode{
        bottom, bottomLeft, bottomRight, center, left, redraw, right, scaleAspectFill, scaleAspectFit, scaleToFill, top,
        topLeft, topRight
    }
}