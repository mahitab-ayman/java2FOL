package UIConversion.UIUtilites;

import java.util.ArrayList;

public class UIConnections {
    public ArrayList<UISegue> segueArrayList;
    public ArrayList<UIAction> actionArrayList;
    private ArrayList<UIOutlet> outletArrayList;

    public void setSegueArrayList(ArrayList<UISegue> segueArrayList) {
        this.segueArrayList = segueArrayList;
    }

    public void setActionArrayList(ArrayList<UIAction> actionArrayList) {
        this.actionArrayList = actionArrayList;
    }

    public void setOutletArrayList(ArrayList<UIOutlet> outletArrayList) {
        this.outletArrayList = outletArrayList;
    }

    public ArrayList<UISegue> getSegueArrayList() {
        return segueArrayList;
    }

    public ArrayList<UIAction> getActionArrayList() {
        return actionArrayList;
    }

    public ArrayList<UIOutlet> getOutletArrayList() {
        return outletArrayList;
    }

    //todo:when to initialize arraylists?
    public UIConnections(){
    }

    @Override
    public String toString() {
        StringBuilder returnValue = new StringBuilder();
        returnValue.append("<connections>");

        if(segueArrayList !=null){
            for (UISegue uiSegue : segueArrayList) {
                returnValue.append(uiSegue);
            }
        }
        if(actionArrayList !=null){
            for (UIAction uiAction : actionArrayList) {
                returnValue.append(uiAction);
            }
        }
        if(outletArrayList !=null){
            for (UIOutlet uiOutlet : outletArrayList) {
                returnValue.append(uiOutlet);
            }
        }

        returnValue.append("</connections>");
        return returnValue.toString();
    }
}
