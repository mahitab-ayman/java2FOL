package UIConversion.UIUtilites;

public class UIFontDescription {
    String key;
    Type type = Type.system;
    public int pointSize = 17;

    enum Type{
        system
    }

    public UIFontDescription(String key) {
        this.key = key;
    }

    @Override
    public String toString() {
        return "<fontDescription" +
                " key=" + UIUtilities.getStringQuote(key) +
                " type=" + UIUtilities.getStringQuote(type.name()) +
                " pointSize=" + UIUtilities.getStringQuote(String.valueOf(pointSize)) +
                "/>";

    }
}
