package UIConversion.UIUtilites;

public class UIViewController {
    public String id;
    public String customClass = "ViewController";
    public String customModule = "Module1";
    public String customModuleProvider="target";
    public String sceneMemberID = "viewController";
    private UILayoutGuides layoutGuides;
    private UIView view;
    private UINavigationItem navigationItem;
    public UIConnections connections;

    public UIViewController() {

        layoutGuides = new UILayoutGuides();
        view = new UIView();
    }

    public UIView getView() {
        return view;
    }
    public UIConnections getConnections() {
        return connections;
    }

    public void setConnections(UIConnections connections) {
        this.connections = connections;
    }

    @Override
    public String toString() {
        StringBuilder returnValue = new StringBuilder
                ("<viewController" +
                        " id=" + UIUtilities.getStringQuote(id) +
                        " customClass=" + UIUtilities.getStringQuote(customClass) +
                        " customModule=" + UIUtilities.getStringQuote(customModule) +
                        " customModuleProvider=" + UIUtilities.getStringQuote(customModuleProvider) +
                " sceneMemberID=" + UIUtilities.getStringQuote(sceneMemberID) +
                ">" +
                layoutGuides +
                view);

        if(navigationItem!=null)
               returnValue.append(navigationItem);
        if(connections!=null)
            returnValue.append(connections);

        returnValue.append("</viewController>");
        return returnValue.toString();
    }

    public void setCustomClass(String controllerFileName) {
        this.customClass=controllerFileName;
    }

    public void setId(String id) {
        this.id = id;
    }
}
