package UIConversion.UIUtilites;

public class UIProlog {
    public String prolog = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
    public UIDocument document;

    public UIProlog(){
        document = new UIDocument();
    }

    @Override
    public String toString() {
        return prolog + document;
    }
}
