package UIConversion.UIUtilites;

public class UITableView extends UIViewComponent {
    UIPrototypes prototypes;
    DataMode dataMode = DataMode.prototypes;
    boolean alwaysBounceVertical = true;
    Style style = Style.plain;
    String separatorStyle= SeparatorStyle.DEFAULT;
    float rowHeight=44;
    float sectionHeaderHeight=28;
    float sectionFooterHeight=28;

    class SeparatorStyle{
        public static final String DEFAULT="default";
    }

    enum Style{
        plain
    }
    enum DataMode{
        prototypes
    }

    public UITableView(){
        clipsSubviews=true;
        contentMode=ContentMode.scaleToFill;
        fixedFrame=true;
        alwaysBounceVertical=true;
        prototypes = new UIPrototypes();
        translatesAutoresizingMaskIntoConstraints=false;
        id = UIUtilities.getID();

        frame = new UIRect("frame");
        //todo: different X and Y for this frame
        frame.width=240;
        frame.height=330;
        autoresizingMask = new UIAutoresizingMask("autoresizingMask");
        backgroundColor = new UIColor("backgroundColor");
        backgroundColor.white();
    }

    @Override
    public String toString() {
        StringBuilder returnValue = new StringBuilder("<tableView" +
                " clipsSubviews=" + UIUtilities.getBooleanStringQuote(clipsSubviews) +
                " contentMode=" + UIUtilities.getStringQuote(contentMode.name()) +
                " fixedFrame=" + UIUtilities.getBooleanStringQuote(fixedFrame) +
                " alwaysBounceVertical=" + UIUtilities.getBooleanStringQuote(alwaysBounceVertical) +
                " dataMode=" + UIUtilities.getStringQuote(dataMode.name()) +
                " style=" + UIUtilities.getStringQuote(style.name()) +
                " separatorStyle=" + UIUtilities.getStringQuote(separatorStyle) +
                " rowHeight=" + UIUtilities.getStringQuote(String.valueOf(rowHeight)) +
                " sectionHeaderHeight=" + UIUtilities.getStringQuote(String.valueOf(sectionHeaderHeight)) +
                " sectionFooterHeight=" + UIUtilities.getStringQuote(String.valueOf(sectionFooterHeight)) +
                " translatesAutoresizingMaskIntoConstraints=" + UIUtilities.getBooleanStringQuote(translatesAutoresizingMaskIntoConstraints) +
                " id=" + UIUtilities.getStringQuote(id) +
                ">" +
                frame +
                autoresizingMask +
                backgroundColor +
                prototypes +
                "</tableView>").append(unSupportedCode);
    return returnValue.toString();
    }

}
