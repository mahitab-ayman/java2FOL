package UIConversion.UIUtilites;

import java.util.ArrayList;

public class UISubviews {
    private ArrayList<UIViewComponent> uiViewComponents;

    public UISubviews() {
        uiViewComponents = new ArrayList<>();
    }

    public void addViewComponent(UIViewComponent uiViewComponent){
        uiViewComponents.add(uiViewComponent);
    }
    @Override
    public String toString() {
        StringBuilder returnString = new StringBuilder("<subviews>");
        if(!uiViewComponents.isEmpty()) {
            for (UIViewComponent uiViewComponent : uiViewComponents) {
                returnString.append(uiViewComponent.toString());
            }
        }
        returnString.append("</subviews>");
        return returnString.toString();
    }
}
