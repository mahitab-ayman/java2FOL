package UIConversion.UIUtilites;

public class UITableViewCellContentView extends UIViewComponent{
    /*<tableViewCell clipsSubviews="YES" contentMode="scaleToFill" selectionStyle="default" indentationWidth="10" id="VJk-IA-J5j">
		<rect key="frame" x="0.0" y="28" width="240" height="44"/>
		<autoresizingMask key="autoresizingMask"/>
		<tableViewCellContentView key="contentView" opaque="NO" clipsSubviews="YES" multipleTouchEnabled="YES" contentMode="center" tableViewCell="VJk-IA-J5j" id="Kbr-Fm-Reg">
			<rect key="frame" x="0.0" y="0.0" width="240" height="44"/>
			<autoresizingMask key="autoresizingMask"/>
		</tableViewCellContentView>
	</tableViewCell>
*/
}
