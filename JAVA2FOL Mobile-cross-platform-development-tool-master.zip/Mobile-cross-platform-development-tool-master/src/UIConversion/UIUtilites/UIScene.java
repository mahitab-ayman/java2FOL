package UIConversion.UIUtilites;

import java.util.ArrayList;

public class UIScene {
    String sceneID = UIUtilities.getID();
    public UIObjects objects;
    public UIPoint point;
    String unsupportedCode;

    public UIScene(){
        objects = new UIObjects();
        point = new UIPoint();
    }

    @Override
    public String toString() {
        return "<scene" +
                " sceneID=" + UIUtilities.getStringQuote(sceneID) +
                ">" +
                objects +
                point +
                "</scene>" +
                unsupportedCode;
    }

    public UISubviews getSubviews(){
        return objects.getViewController().getView().getSubviews();
    }

    public void setConnections(UIConnections uiConnections) {
        objects.getViewController().setConnections(uiConnections);
    }

    public void setOutletArrayList(ArrayList<UIOutlet> outletArrayList){
        objects.getViewController().getConnections().setOutletArrayList(outletArrayList);
    }

    public void setSegueArrayList(ArrayList<UISegue> segueArrayList){
        objects.getViewController().getConnections().setSegueArrayList(segueArrayList);
    }

    public UIConnections getConnections(){
        return objects.getViewController().getConnections();
    }

    public ArrayList<UIOutlet> getOutletArrayList(){ return objects.getViewController().getConnections().getOutletArrayList(); }

    public ArrayList<UISegue> getSegueArrayList() {
        return objects.getViewController().getConnections().getSegueArrayList();
    }

    public UIObjects getObjects() {
        return objects;
    }

    public void setUnsupportedCode(String unsupportedCode) {
        this.unsupportedCode=unsupportedCode;
    }
}
