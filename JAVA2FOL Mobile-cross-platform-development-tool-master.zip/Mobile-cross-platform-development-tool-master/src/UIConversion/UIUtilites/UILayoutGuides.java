package UIConversion.UIUtilites;

public class UILayoutGuides {
    UIViewControllerLayoutGuide topLayoutGuide = new UIViewControllerLayoutGuide("top");
    UIViewControllerLayoutGuide bottomLayoutGuide = new UIViewControllerLayoutGuide("bottom");

    @Override
    public String toString() {
        //todo: settle this part later
        return "<layoutGuides>" +
                topLayoutGuide +
                bottomLayoutGuide +
                "</layoutGuides>";
    }
}
