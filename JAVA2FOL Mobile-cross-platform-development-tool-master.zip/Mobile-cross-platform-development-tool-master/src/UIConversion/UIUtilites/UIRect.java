package UIConversion.UIUtilites;

public class UIRect {
    public String key;
    float x, y;
    float width = 414, height = 896;

    public UIRect() {
        this.key = "frame";
        //todo: re-maintain x and y
        this.x=UIUtilities.getX(width);
        this.y=UIUtilities.getY();
    }

    public UIRect(float width, float height) {
        this.key = "frame";
        //todo: re-maintain x and y
        this.x=UIUtilities.getX(width);
        this.y=UIUtilities.getY();
        this.width=width;
        this.height=height;
    }

    public UIRect(String key) {
        this.key = key;
        //todo: re-maintain x and y
        this.x=UIUtilities.getX(width);
        this.y=UIUtilities.getY();
    }

    public void setWidth(float width) {
        this.width = width;
        this.x=UIUtilities.getX(width);
        this.y=UIUtilities.getY();
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setX(float x) {
        this.x = x;
    }

    public void setY(float y) {
        this.y = y;
    }

    public String getKey() {
        return key;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    @Override
    public String toString() {
        return "<rect" +
                " key=" + UIUtilities.getStringQuote(key) +
                " x=" + UIUtilities.getStringQuote(String.valueOf(x)) +
                " y=" + UIUtilities.getStringQuote(String.valueOf(y)) +
                " width=" + UIUtilities.getStringQuote(String.valueOf(width)) +
                " height=" + UIUtilities.getStringQuote(String.valueOf(height)) +
                "/>";
    }
}
