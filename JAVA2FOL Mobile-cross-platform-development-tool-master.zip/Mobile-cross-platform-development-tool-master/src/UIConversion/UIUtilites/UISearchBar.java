package UIConversion.UIUtilites;

public class UISearchBar extends UIViewComponent{
    public UITextInputTraits textInputTraits;
//    <searchBar contentMode="redraw" fixedFrame="YES" translatesAutoresizingMaskIntoConstraints="NO" id="VSb-hb-Tfv">
//                                <rect key="frame" x="0.0" y="446" width="375" height="44"/>
//                                <autoresizingMask key="autoresizingMask" widthSizable="YES" flexibleMaxY="YES"/>
//                                <textInputTraits key="textInputTraits"/>
//                            </searchBar>
    public UISearchBar(){
        contentMode = ContentMode.redraw;
        fixedFrame = true;
        translatesAutoresizingMaskIntoConstraints = false;
        id = UIUtilities.getID();

        frame = new UIRect(375,44);
        autoresizingMask = new UIAutoresizingMask("autoresizingMask");
        autoresizingMask.setFlexibleMinX(false); //to make widthSizable
        textInputTraits = new UITextInputTraits("textInputTraits");
    }

    public String getSearchBarLocalizable(String stringKey, String stringValue) {
        return "\n /* Class = \"UISearchBar\"; text = "
                + UIUtilities.getStringQuote(stringKey)
                + "; ObjectID = " + UIUtilities.getStringQuote(id)
                + "; */\n" + UIUtilities.getStringQuote(id + ".text")
                + " = "
                + UIUtilities.getStringQuote(stringValue);
    }


    @Override
    public String toString() {
        StringBuilder returnValue = new StringBuilder
                ("<searchBar" +
                " contentMode=" + UIUtilities.getStringQuote(contentMode.name()) +
                " fixedFrame=" + UIUtilities.getBooleanStringQuote(fixedFrame) +
                " translatesAutoresizingMaskIntoConstraints=" + UIUtilities.getBooleanStringQuote(translatesAutoresizingMaskIntoConstraints) +
                " id=" + UIUtilities.getStringQuote(id) +
                ">");

        returnValue.append(frame).append(autoresizingMask).append(textInputTraits);

        if(backgroundColor!=null)
            returnValue.append(backgroundColor);

        if(tintColor!=null)
            returnValue.append(tintColor);

        returnValue.append("</searchBar>").append(unSupportedCode);

        return returnValue.toString();
    }
}
