package UIConversion.UIUtilites;

public class UIViewControllerLayoutGuide {
    String type;
    String id;

    public UIViewControllerLayoutGuide(String type) {
        this.type = type;
        this.id = UIUtilities.getID();
    }

    @Override
    public String toString() {
        return "<viewControllerLayoutGuide" +
                " type=" + UIUtilities.getStringQuote(type) +
                " id=" + UIUtilities.getStringQuote(id) +
                "/>";
    }
}
