package UIConversion.UIUtilites;

public class UIView{
    public String key = "view";
    public UIViewComponent.ContentMode contentMode = UIViewComponent.ContentMode.scaleToFill;
    public String id = UIUtilities.getID();

    public UIRect frame;
    public UIAutoresizingMask autoresizingMask;
    private UISubviews subviews;
    public UIColor backgroundColor;

    public UIView() {
        frame = new UIRect("frame");
        autoresizingMask = new UIAutoresizingMask("autoresizingMask");
        subviews = new UISubviews();
        backgroundColor = new UIColor("backgroundColor");
        backgroundColor.white();

        frame.width=375;
        frame.height=667;
        backgroundColor.white();
    }

    public UISubviews getSubviews() {
        return subviews;
    }

    @Override
    public String toString() {
        return "<view" +
                " key=" + UIUtilities.getStringQuote(key) +
                " contentMode=" + UIUtilities.getStringQuote(contentMode.name()) +
                " id=" + UIUtilities.getStringQuote(id) +
                ">" +
                frame+
                autoresizingMask+
                subviews +
                backgroundColor +
                "</view>";
    }
}
