package UIConversion.UIUtilites;

public class UIObjects {
    public UIViewController viewController;
    private UIPlaceholder placeholder;

    public UIObjects() {
        viewController = new UIViewController();
        placeholder = new UIPlaceholder();
    }

    public UIViewController getViewController() {
        return viewController;
    }

    @Override
    public String toString() {
        return "<objects>" +
                viewController+
                placeholder+
                "</objects>";
    }
}
