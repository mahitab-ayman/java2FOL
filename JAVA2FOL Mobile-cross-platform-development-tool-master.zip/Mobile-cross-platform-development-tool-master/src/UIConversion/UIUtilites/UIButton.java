package UIConversion.UIUtilites;

public class UIButton extends UIControlComponent {
    public ButtonType buttonType = ButtonType.roundedRect;
    public UIUtilities.LineBreakMode lineBreakMode = UIUtilities.LineBreakMode.middleTruncation;

    public enum ButtonType{
        contactAdd, custom, detailDisclosure, infoDark,
        infoLight, plain, roundedRect, system
    }

    public UIButton() {
        id=UIUtilities.getID();

        frame = new UIRect(46,30);
        autoresizingMask = new UIAutoresizingMask("autoresizingMask");
        state = new UIState("normal","Button");
    }
    public String getButtonLocalizable(String stringKey, String stringValue){
        return "\n /* Class = \"UIButton\"; normalTitle = "
                + UIUtilities.getStringQuote(stringKey)
                + "; ObjectID = " + UIUtilities.getStringQuote(id)
                + "; */\n" + UIUtilities.getStringQuote(id + ".normalTitle")
                + " = "
                + UIUtilities.getStringQuote(stringValue);
    }

    @Override
    public String toString() {
        StringBuilder returnValue = new StringBuilder
                ("<button" +
                " opaque=" + UIUtilities.getBooleanStringQuote(opaque) +
                " contentMode=" + UIUtilities.getStringQuote(contentMode.name()) +
                " fixedFrame=" + UIUtilities.getBooleanStringQuote(fixedFrame) +
                " contentHorizontalAlignment=" + UIUtilities.getStringQuote(contentHorizontalAlignment.name()) +
                " contentVerticalAlignment=" + UIUtilities.getStringQuote(contentVerticalAlignment.name()) +
                " translatesAutoresizingMaskIntoConstraints=" + UIUtilities.getBooleanStringQuote(translatesAutoresizingMaskIntoConstraints) +
                " buttonType=" + UIUtilities.getStringQuote(buttonType.name()) +
                " lineBreakMode=" + UIUtilities.getStringQuote(lineBreakMode.name()) +
                " id=" + UIUtilities.getStringQuote(id) +
                ">");

        returnValue.append(frame).append(autoresizingMask);

        if(backgroundColor!=null)
            returnValue.append(backgroundColor);
        if(tintColor!=null)
            returnValue.append(tintColor);

        returnValue.append(state);

        if(connections!=null)
            returnValue.append(connections);

        returnValue.append("</button>").append(unSupportedCode);

        return returnValue.toString();
    }
}
