package UIConversion.UIUtilites;

public class UITextField extends UIControlComponent{
    public BorderStyle borderStyle = BorderStyle.roundedRect;
    public UIUtilities.TextAlignment textAlignment = UIUtilities.TextAlignment.natural;
    public int minimumFontSize = 17;
    public UIColor textColor;
    public UIFontDescription fontDescription;
    public UITextInputTraits textInputTraits;

//    <textField opaque="NO" clipsSubviews="YES" contentMode="scaleToFill" fixedFrame="YES" contentHorizontalAlignment="left"
// contentVerticalAlignment="center" borderStyle="roundedRect" textAlignment="natural"
// minimumFontSize="17" translatesAutoresizingMaskIntoConstraints="NO" id="pO5-CA-0EW">
//                                <rect key="frame" x="123" y="186" width="97" height="30"/>
//                                <autoresizingMask key="autoresizingMask" flexibleMaxX="YES" flexibleMaxY="YES"/>
//                                <nil key="textColor"/>
//                                <fontDescription key="fontDescription" type="system" pointSize="14"/>
//                                <textInputTraits key="textInputTraits"/>
//                            </textField>

    public UITextField(){
        clipsSubviews = true;
        contentHorizontalAlignment = ContentHorizontalAlignment.left;
        contentVerticalAlignment = ContentVerticalAlignment.center;
        translatesAutoresizingMaskIntoConstraints = false;

        frame = new UIRect(97,34);
        autoresizingMask = new UIAutoresizingMask("autoresizingMask");

        textInputTraits = new UITextInputTraits("textInputTraits");
        fontDescription = new UIFontDescription("fontDescription");

        id = UIUtilities.getID();
    }

    public String getTextFieldLocalizable(String stringKey, String stringValue) {
        return "\n /* Class = \"UITextField\"; text = "
                + UIUtilities.getStringQuote(stringKey)
                + "; ObjectID = " + UIUtilities.getStringQuote(id)
                + "; */\n" + UIUtilities.getStringQuote(id + ".text")
                + " = "
                + UIUtilities.getStringQuote(stringValue);
    }

    enum BorderStyle{
        bezel, line, none, roundedRect
    }
    @Override
    public String toString() {
        StringBuilder returnValue = new StringBuilder
                ("<textField" +
                " opaque=" + UIUtilities.getBooleanStringQuote(opaque) +
                " clipsSubviews=" + UIUtilities.getBooleanStringQuote(clipsSubviews) +
                " contentMode=" + UIUtilities.getStringQuote(contentMode.name()) +
                " fixedFrame=" + UIUtilities.getBooleanStringQuote(fixedFrame) +
                " contentHorizontalAlignment=" + UIUtilities.getStringQuote(contentHorizontalAlignment.name()) +
                " contentVerticalAlignment=" + UIUtilities.getStringQuote(contentVerticalAlignment.name()) +
                " borderStyle=" + UIUtilities.getStringQuote(borderStyle.name()) +
                " textAlignment=" + UIUtilities.getStringQuote(textAlignment.name()) +
                " minimumFontSize=" + UIUtilities.getStringQuote(String.valueOf(minimumFontSize)) +
                " translatesAutoresizingMaskIntoConstraints=" + UIUtilities.getBooleanStringQuote(translatesAutoresizingMaskIntoConstraints) +
                " id=" + UIUtilities.getStringQuote(id) +
                ">");

        returnValue.append(frame).append(autoresizingMask);

        if(textColor!=null)
            returnValue.append(textColor);
        else
            returnValue.append("<nil key=\"textColor\"/>");

        returnValue.append(fontDescription).append(textInputTraits);

        returnValue.append("</textField>").append(unSupportedCode);

        return returnValue.toString();
    }
}
