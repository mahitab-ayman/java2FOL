package UIConversion.UIUtilites;

import UIConversion.AndroidToIOSUtility;

public class UIOutlet {
    String property="";
    String destination="";
    String id=UIUtilities.getID();

    public UIOutlet(String property, String destination) {
        this.property = property;
        this.destination = AndroidToIOSUtility.getIDForIOS(destination);
    }

    @Override
    public String toString() {
        return "<outlet" +
                " property=" + UIUtilities.getStringQuote(property) +
                " destination=" + UIUtilities.getStringQuote(destination) +
                " id=" + UIUtilities.getStringQuote(id) +
                "/>";
    }
}
