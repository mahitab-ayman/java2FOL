package UIConversion.UIUtilites;

import java.util.ArrayList;

public class UIPrototypes {
    ArrayList<UITableViewCell> tableViewCellArrayList;

    public UIPrototypes() {
        tableViewCellArrayList = new ArrayList<>();
    }

    @Override
    public String toString() {
        StringBuilder value = new StringBuilder("<prototypes>");
        for (UITableViewCell uiTableViewCell:tableViewCellArrayList) {
            value.append(" ").append(uiTableViewCell);
        }
        value.append("</prototypes>");
        return value.toString();
    }
}
