package UIConversion.UIUtilites;

public class UIPoint {
    //todo: maintain key, x, y
    public String key = "canvasLocation";
    public float x = 0, y = 0;
    /*public float x = UIUtilities.getSceneX();
    public float y = UIUtilities.getSceneY();*/

    @Override
    public String toString() {
        return "<point" +
                " key=" + UIUtilities.getStringQuote(key) +
                " x=" + UIUtilities.getStringQuote(String.valueOf(x)) +
                " y=" + UIUtilities.getStringQuote(String.valueOf(y)) +
                "/>";
    }
}
