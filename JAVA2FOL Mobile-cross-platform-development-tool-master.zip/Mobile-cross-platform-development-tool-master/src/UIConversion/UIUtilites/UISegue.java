package UIConversion.UIUtilites;

public class UISegue {
    public String destination = "";
    public String identifier = "";
    public Kind kind;
    public String id = UIUtilities.getID();

    enum Kind{
        show,presentModally,popup,showDetail
    }

    public UISegue(String destination, String identifier) {
        this.destination = destination;
        this.identifier = identifier;
        this.kind = Kind.show;
    }

    @Override
    public String toString() {
        return "<segue" +
                " destination=" + UIUtilities.getStringQuote(destination) +
                " kind=" + UIUtilities.getStringQuote(kind.name()) +
                " identifier=" + UIUtilities.getStringQuote(identifier) +
                " id=" + UIUtilities.getStringQuote(id) +
                "/>";
    }
}
