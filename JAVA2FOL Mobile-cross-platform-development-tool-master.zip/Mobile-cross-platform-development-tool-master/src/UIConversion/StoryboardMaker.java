package UIConversion;

import JavaToSwiftConversion.ConvertedJavaFileData;
import UIConversion.UIUtilites.UIScene;
import UIConversion.UIUtilites.UIUtilities;
import androidToiOS.AndroidProject;
import generatedAntlr.XMLLexer;
import generatedAntlr.XMLParser;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

import java.util.ArrayList;

public class StoryboardMaker {
    private ArrayList<UIScene> scenes;
    private String storyboardLocalizableString = "";
    String initialViewController;

    public String getStoryboardLocalizableString() {
        return storyboardLocalizableString;
    }

    public StoryboardMaker(AndroidProject androidProject) {
        this.scenes = new ArrayList<>();
        initialViewController = AndroidToIOSUtility.getIDForViewController(androidProject.getInitialActivity());
    }

    public StoryboardMaker() {
        scenes = new ArrayList<>();
    }


    public void addNewScene(String xmlCode, ConvertedJavaFileData convertedJavaFileData, AndroidProject androidProject){
        ConvertedSceneItems convertedSceneItems = convertLayout(xmlCode,convertedJavaFileData, androidProject);
        scenes.add(convertedSceneItems.getScene());
        storyboardLocalizableString+=convertedSceneItems.getSceneLocalizableString();
    }

    private ConvertedSceneItems convertLayout(String xmlCode, ConvertedJavaFileData convertedJavaFileData, AndroidProject androidProject) {
        SceneMaker sceneMaker = new SceneMaker(convertedJavaFileData, androidProject);

        XMLParser parser = new XMLParser(null);
        ANTLRInputStream input = new ANTLRInputStream(xmlCode);
        XMLLexer lexer = new XMLLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        parser.setInputStream(tokens);
        ParseTree parseTree = parser.document();

        ParseTreeWalker walker = new ParseTreeWalker();
        walker.walk(sceneMaker, parseTree);

        return sceneMaker.getConvertedSceneItems();
    }

    @Override
    public String toString() {
        String x = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<document type=\"com.apple.InterfaceBuilder3.CocoaTouch.Storyboard.XIB\" version=\"3.0\" " +
                "toolsVersion=\"14810.12\" targetRuntime=\"iOS.CocoaTouch\" " +
                "propertyAccessControl=\"none\" useAutolayout=\"YES\" useTraitCollections=\"YES\" colorMatched=\"YES\" ";

        if(initialViewController!=null)
            x+="initialViewController=\""+initialViewController+"\"";

        x+=">\n    <device id=\"retina4_7\" orientation=\"portrait\">\n" +
                "        <adaptation id=\"fullscreen\"/>\n" +
                "    </device>\n" +
                "    <dependencies>\n" +
                "        <deployment identifier=\"iOS\"/>\n" +
                "        <plugIn identifier=\"com.apple.InterfaceBuilder.IBCocoaTouchPlugin\" version=\"12086\"/>\n" +
                "        <capability name=\"documents saved in the Xcode 8 format\" minToolsVersion=\"8.0\"/>\n" +
                "    </dependencies>\n" +
                "    <scenes>" ;
        StringBuilder returnValue = new StringBuilder(x);
        if(scenes==null){
            returnValue.append("<!--No scenes were added-->");
        }
        else{
            for(UIScene uiScene: scenes){
                returnValue.append(uiScene);
            }
        }
        returnValue.append("\n" +
                "    </scenes>\n" +
                "</document>");
        UIUtilities.resetStaticVariables();
        return returnValue.toString();
    }
}
