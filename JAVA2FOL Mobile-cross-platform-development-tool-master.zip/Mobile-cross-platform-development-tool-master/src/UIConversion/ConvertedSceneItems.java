package UIConversion;

import UIConversion.UIUtilites.UIScene;

public class ConvertedSceneItems {
    UIScene uiScene;
    String sceneLocalizableString;

    public ConvertedSceneItems(UIScene uiScene, String sceneLocalizableString){
        this.uiScene=uiScene;
        this.sceneLocalizableString = sceneLocalizableString;
    }

    public UIScene getScene() {
        return uiScene;
    }

    public String getSceneLocalizableString() {
        return sceneLocalizableString;
    }
}
