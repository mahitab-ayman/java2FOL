package UIConversion;

import JavaToSwiftConversion.AndroidIntent;
import JavaToSwiftConversion.ConvertedJavaFileData;
import UIConversion.UIUtilites.*;
import androidToiOS.AndroidProject;
import generatedAntlr.XMLParser;
import generatedAntlr.XMLParserBaseListener;
import org.antlr.v4.runtime.tree.ParseTree;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SceneMaker extends XMLParserBaseListener {

    private UIScene uiScene;
    private String controllerFileName;
    private HashMap<String,String> mObjectsUIIDs;
    private ArrayList<AndroidIntent> segueExplicitIntents;
    private HashMap<UIViewComponent,String> sceneResultedStrings;
    private HashMap<String,String> androidStringResources;

    private StringBuilder unsupportedCode;

    public SceneMaker(){
        uiScene = new UIScene();
    }

    /**
     * SceneMaker constructor distributes the converted java file data over the pointers
     * and initiates a new Scene
     * @param convertedJavaFileData
     */

    public SceneMaker(ConvertedJavaFileData convertedJavaFileData, AndroidProject androidProject) {
        controllerFileName = convertedJavaFileData.fileName;
        mObjectsUIIDs = convertedJavaFileData.userInterfaceObjectsConnections;
        segueExplicitIntents = convertedJavaFileData.explicitIntents;
        androidStringResources = androidProject.getStringResources();

        uiScene = new UIScene();
        sceneResultedStrings = new HashMap<>();
        unsupportedCode = new StringBuilder();
    }

    /**
     * getConvertedSceneItems finalizes the conversion process by:
     * 1- setting viewController ID
     * 2- setting customClass
     * 3- forming connections as outlets and segues
     * @return
     */

    public ConvertedSceneItems getConvertedSceneItems(){

        String viewControllerID = AndroidToIOSUtility.getIDForViewController(controllerFileName);
        uiScene.getObjects().getViewController().setId(viewControllerID);
        String customClass = AndroidToIOSUtility.getIDForIOS(controllerFileName);
        uiScene.getObjects().getViewController().setCustomClass(customClass);
        formConnections();

        String sceneLocalizableString = getSceneLocalizable();

        uiScene.setUnsupportedCode(unsupportedCode.toString());
        ConvertedSceneItems convertedSceneItems = new ConvertedSceneItems(uiScene,sceneLocalizableString);
        //convertedSceneItems
        return convertedSceneItems;
    }

    private String getSceneLocalizable() {
        StringBuilder storyboardLocalized = new StringBuilder();

        for(Map.Entry<UIViewComponent,String> entry: sceneResultedStrings.entrySet()){
            String stringKey = entry.getValue();
            String stringValue = androidStringResources.get(stringKey);
            storyboardLocalized.append(entry.getKey().getComponentLocalizable(stringKey,stringValue));
        }
        return storyboardLocalized.toString();
    }

    private void formConnections(){
        uiScene.setConnections(new UIConnections());
        if(mObjectsUIIDs !=null) {
            uiScene.setOutletArrayList(new ArrayList<>());
            ArrayList<UIOutlet> uiOutletArrayList = uiScene.getOutletArrayList();

            for (Map.Entry<String, String> entry : mObjectsUIIDs.entrySet()) {
               uiOutletArrayList.add(new UIOutlet(entry.getValue(),entry.getKey()));
            }
        }
        if(segueExplicitIntents !=null) {
            uiScene.setSegueArrayList(new ArrayList<>());
            ArrayList<UISegue> uiSegueArrayList = uiScene.getSegueArrayList();
            for (AndroidIntent androidIntent: segueExplicitIntents) {
                UISegue uiSegue = new UISegue(androidIntent.getSegueDestination(),androidIntent.getSegueIdentifier());
                uiSegueArrayList.add(uiSegue);
            }
        }
        //System.out.println(sceneResultedStrings.toString());
    }

    @Override
    public void enterElement1(XMLParser.Element1Context ctx) {
        String value = "<"+ctx.Name()+ctx.attribute().toString()+"/>";
        //unsupportedCode.append(UIUtilities.getStringCommented(ctx.getText()));
        unsupportedCode.append(UIUtilities.getStringCommented(value));
        UIUtilities.unsupportedComponentsCounter++;
    }

    @Override
    public void enterElement2(XMLParser.Element2Context ctx) {
        //System.out.println("entered Element2");
        XMLTag xmlTag;

        switch (ctx.Name().getText()) {
            case "Button":
                xmlTag = new UIButton();
                break;

            case "TextView":
                xmlTag = new UILabel();
                break;

            case "SearchView":
                xmlTag = new UISearchBar();
                break;

            case "EditText":
                xmlTag = new UITextField();
                break;

//            case "ListView":
//                xmlTag = new UITableView();
//                break;

            default:
                UIUtilities.unsupportedComponentsCounter++;
                unsupportedCode.append(UIUtilities.getStringCommented(ctx.getText()));
                return;
        }
        UIUtilities.supportedComponentsCounter++;
        UIViewComponent uiViewComponent = (UIViewComponent) xmlTag;

        for (ParseTree attribute : ctx.attribute()) {
            String value = attribute.getChild(2).getText();
            value = value.substring(1, value.length() - 1);
            //todo:handle match_parent and wrap_content
            if(value.equals("match_parent")||value.equals("wrap_content")||value.equals("fill_parent")){
                UIUtilities.unsupportedFeaturesCounter++;
                continue;
            }
            switch (attribute.getChild(0).getText()) {
                case "app:layout_constraintBottom_toBottomOf":
                    if(value.equals("parent")){
                        uiViewComponent.autoresizingMask.setFlexibleMaxY(false);
                        UIUtilities.supportedFeaturesCounter++;
                    }
                    else UIUtilities.unsupportedFeaturesCounter++;
                    break;

                case "app:layout_constraintTop_toTopOf":
                    if(value.equals("parent")){
                        uiViewComponent.autoresizingMask.setFlexibleMinY(false);
                        UIUtilities.supportedFeaturesCounter++;
                    }
                    else UIUtilities.unsupportedFeaturesCounter++;
                    break;

                case "app:layout_constraintEnd_toEndOf":
                    if(value.equals("parent")){
                        uiViewComponent.autoresizingMask.setFlexibleMaxX(false);
                        UIUtilities.supportedFeaturesCounter++;
                    }
                    else UIUtilities.unsupportedFeaturesCounter++;
                    break;

                case "app:layout_constraintStart_toStartOf":
                    if(value.equals("parent")) {
                        uiViewComponent.autoresizingMask.setFlexibleMinX(false);
                        UIUtilities.supportedFeaturesCounter++;
                    }
                    else UIUtilities.unsupportedFeaturesCounter++;
                    break;

                case "android:layout_width":
                    uiViewComponent.frame.setWidth(AndroidToIOSUtility.substringMeasurement(value));
                    UIUtilities.supportedFeaturesCounter++;
                    break;

                case "android:layout_height":
                    uiViewComponent.frame.setHeight(AndroidToIOSUtility.substringMeasurement(value));
                    UIUtilities.supportedFeaturesCounter++;
                    break;

                case "tools:layout_editor_absoluteX":
                    uiViewComponent.frame.setX(AndroidToIOSUtility.substringMeasurement(value));
                    UIUtilities.supportedFeaturesCounter++;
                    break;

                case "tools:layout_editor_absoluteY":
                    uiViewComponent.frame.setY(AndroidToIOSUtility.substringMeasurement(value));
                    UIUtilities.supportedFeaturesCounter++;
                    break;

                case "android:background":
                    //todo: different colorspace soln
                    uiViewComponent.backgroundColor=new UIColor("backgroundColor");
                    long temp = Long.valueOf(value.substring(1), 16);
                    uiViewComponent.backgroundColor.blue = (double) (temp & 255) / 255;          //getting blue component from hexadecimal
                    uiViewComponent.backgroundColor.green = (double) ((temp >> 8) & 255) / 255;    //getting green component from hexadecimal
                    uiViewComponent.backgroundColor.red = (double) ((temp >> 16) & 255) / 255;     //getting red from hexadecimal
                    UIUtilities.supportedFeaturesCounter++;
                    break;

                case "android:text":
                    if (value.length()>8 && value.substring(0, 8).equals("@string/")){
                        value = value.substring(8);
                        sceneResultedStrings.put(uiViewComponent,value);
                    }
                    uiViewComponent.setText(value);
                    UIUtilities.supportedFeaturesCounter++;
                    break;

                case "android:id":
                    if (value.length()>5 && value.substring(0, 5).equals("@+id/"))
                        uiViewComponent.id = value.substring(5);
                    else
                        uiViewComponent.id = value;
                    //uiViewComponent.id=uiViewComponent.id.replace('_','-');
                    uiViewComponent.id= AndroidToIOSUtility.getIDForIOS(uiViewComponent.id);
                    UIUtilities.supportedFeaturesCounter++;
                    break;

                case "android:inputType":
                    UITextField textField = (UITextField) uiViewComponent;
                    UIUtilities.supportedFeaturesCounter++;
                    switch(value){
                        case("textPassword"):
                            textField.textInputTraits.textContentType= UITextInputTraits.TextContentType.password;
                            break;

                        case("textEmailAddress"):
                            textField.textInputTraits.textContentType=UITextInputTraits.TextContentType.email;
                            break;

                        default:
                            UIUtilities.supportedFeaturesCounter--;
                            UIUtilities.unsupportedFeaturesCounter++;
                            textField.unSupportedCode+=UIUtilities.getStringCommented(attribute.getText());
                    }
                    break;

                case("android:textSize"):
                    if((uiViewComponent)instanceof UILabel) {
                        ((UILabel) uiViewComponent).fontDescription.pointSize = (int) AndroidToIOSUtility.substringMeasurement(value);
                        UIUtilities.supportedFeaturesCounter++;
                    }
                    else UIUtilities.unsupportedFeaturesCounter++;
                    break;

                default:
                    uiViewComponent.unSupportedCode+=UIUtilities.getStringCommented(attribute.getText());
                    UIUtilities.unsupportedFeaturesCounter++;
            }
        }
        uiScene.getSubviews().addViewComponent(uiViewComponent);
    }

//    private void printChildren(ParserRuleContext p) {
//
//        System.out.println("Printing children of " + p.getText());
//        for (ParseTree t : p.children) {
//            System.out.println(t.getText());
//        }
//    }
}
