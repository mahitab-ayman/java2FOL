package UIConversion;

public class AndroidToIOSUtility {
    public static String getIDForIOS(String id) {
        return id.replace('_','-');
    }

    public static String getIDForViewController(String customClass){
        if(customClass.contains(".java")){
            customClass = customClass.replace(".java","");
        }

        return customClass+"ID";
    }
    public static float substringMeasurement(String value) {
        return Float.valueOf(value.substring(0, value.length() - 2));
    }


}
