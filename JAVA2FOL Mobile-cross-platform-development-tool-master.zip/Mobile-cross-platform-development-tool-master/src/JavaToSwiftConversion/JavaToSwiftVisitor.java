package JavaToSwiftConversion;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import generatedAntlr.JavaBaseVisitor;
import generatedAntlr.JavaParser;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.misc.Interval;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.TerminalNodeImpl;

import java.io.InputStreamReader;
import java.io.Reader;
import java.util.*;

import static JavaToSwiftConversion.JavaToSwiftAssistant.*;

public class JavaToSwiftVisitor extends JavaBaseVisitor<String> {

    private static final Map<String, Map<String, String>> mFunctionsInSwift;
    private static final Map<String, Map<String, String>> mOperatorsInSwift;
    private static final Map<String, Map<String, String>> mStaticFunctionsInSwift;

    private static final Map<String, String> mLibraries;
    private String mSwiftRunCode = "";
    private JavaToSwiftAssistant mJavaToSwiftAssistant;

    /**
     * it controls the number of tab space before a statement
     */
    private static Stack<String> mIndentation = new Stack<>();

    private int totalNumberOfStatements = 0;
    private int unSupportedNumberOfStatements = 0;

    public JavaToSwiftVisitor() {
        mIndentation = new Stack<>();

        mIndentation.push("");
        mJavaToSwiftAssistant = new JavaToSwiftAssistant();
    }

    static {

        HashMap<String, Map<String, String>> temp2 = null;
        HashMap<String, Map<String, String>> temp4 = null;
        HashMap<String, String> temp6 = null;
        HashMap<String, Map<String, String>> temp7 = null;

        Gson gson = new GsonBuilder().create();


        // empty string for testing errors

        Reader reader2 = null;
        reader2 = new InputStreamReader(
                (getFileFromResources("functionsInSwift.json")));


        Reader reader4 = null;
        reader4 = new InputStreamReader(
                (getFileFromResources("operatorsInSwift.json")));
        Reader reader6 = null;
        reader6 = new InputStreamReader((getFileFromResources("Libraries.json")));
        Reader reader7 = null;
        reader7 = new InputStreamReader((getFileFromResources("StaticBuiltInFunctionData.json")));

        temp2 = gson.fromJson(reader2, HashMap.class);
        temp4 = gson.fromJson(reader4, HashMap.class);
        temp6 = gson.fromJson(reader6, HashMap.class);
        temp7 = gson.fromJson(reader7, HashMap.class);

        mFunctionsInSwift = Collections.unmodifiableMap(temp2);
        mOperatorsInSwift = Collections.unmodifiableMap(temp4);
        mLibraries = Collections.unmodifiableMap(temp6);
        mStaticFunctionsInSwift = Collections.unmodifiableMap(temp7);
    }


    @Override
    public String visitCompilationUnit(JavaParser.CompilationUnitContext ctx) {

        String output = "" + "\n";
        if (ctx.packageDeclaration() != null) {
            output += visitPackageDeclaration(ctx.packageDeclaration()) + "\n";
        }
        if (ctx.importDeclaration() != null) {
            for (int i = 0; i < ctx.importDeclaration().size(); i++) {
                String swiftImportSttatement = visitImportDeclaration(ctx.importDeclaration(i));
                if (swiftImportSttatement != null)
                    output += swiftImportSttatement + "\n";

            }
        }
        if (ctx.typeDeclaration() != null) {
            for (int i = 0; i < ctx.typeDeclaration().size(); i++) {
                output += visitTypeDeclaration(ctx.typeDeclaration(i));
            }
        }
        output = mJavaToSwiftAssistant.checkMultipleInheritance(output);
        return output + mSwiftRunCode;
    }

    @Override
    public String visitPackageDeclaration(JavaParser.PackageDeclarationContext ctx) {
        //lesa msh 3arfa f7war el packages f swift
        return "";//for now bs
    }

    @Override
    public String visitImportDeclaration(JavaParser.ImportDeclarationContext ctx) {
        String androidLibraryName = ctx.qualifiedName().getText();
        String equivalentSwiftLibraryName;
        equivalentSwiftLibraryName = mLibraries.get(androidLibraryName);
        if (equivalentSwiftLibraryName != null)
            return " " + androidLibraryName;
        return null;
    }

    @Override
    public String visitForControl(JavaParser.ForControlContext ctx) {
        String value = "";
        if (ctx.enhancedForControl() != null) {

        }
        //normal for loop
        else {
            String forLoopVariableInitialValue;
            if (ctx.forInit().localVariableDeclaration() != null) {

                forLoopVariableInitialValue = visit(ctx.forInit().localVariableDeclaration().variableDeclarators()
                        .variableDeclarator(0).variableInitializer());
            } else {
                forLoopVariableInitialValue = visit(ctx.forInit().expressionList().expression(0).children.get(2));
            }

            JavaParser.RelationalExpressionContext expressionContext = (JavaParser.RelationalExpressionContext) ctx.expression();
            String finalValue = visit(expressionContext.expression(1));
            String finalValueKeyWord;

            if (expressionContext.children.get(2).getText().equals("=")) {
                finalValueKeyWord = "through";
            } else {
                finalValueKeyWord = "to";
            }


            String forUpdateValue = visitForUpdate(ctx.forUpdate());
            value = "stride" + "(" + "from" + ": " + forLoopVariableInitialValue + ", " + finalValueKeyWord +
                    ": " + finalValue + ", by: " + forUpdateValue + ")";

        }

        return value;
    }

    @Override
    public String visitForUpdate(JavaParser.ForUpdateContext ctx) {
        StringBuilder result = new StringBuilder();

        // Process the list of update expressions
        for (ParseTree expression : ctx.expressionList().expression()) {
            String expr = expression.getText();

            // Handle x += value
            if (expr.contains("+=")) {
                String variable = expr.substring(0, expr.indexOf("+=")).trim();
                String value = expr.substring(expr.indexOf("+=") + 2).trim();
                result.append("i(n+").append(value).append(") = i(n)+").append(value).append(" ");
            }
            // Handle x -= value
            else if (expr.contains("-=")) {
                String variable = expr.substring(0, expr.indexOf("-=")).trim();
                String value = expr.substring(expr.indexOf("-=") + 2).trim();
                result.append("i(n-").append(value).append(") = i(n)-").append(value).append(" ");
            }
            // Handle x++
            else if (expr.endsWith("++")) {
                String variable = expr.substring(0, expr.indexOf("++")).trim();
                result.append("i(n+1) = i(n)+1 ");
            }
            // Handle x--
            else if (expr.endsWith("--")) {
                String variable = expr.substring(0, expr.indexOf("--")).trim();
                result.append("i(n-1) = i(n)-1 ");
            }
            // Handle x = x + value
            else if (expr.contains("=") && expr.contains("+")) {
                String variable = expr.substring(0, expr.indexOf("=")).trim();
                String value = expr.substring(expr.indexOf("+") + 1).trim();
                result.append("i(n+").append(value).append(") = i(n)+").append(value).append(" ");
            }
            // Handle x = x - value
            else if (expr.contains("=") && expr.contains("-")) {
                String variable = expr.substring(0, expr.indexOf("=")).trim();
                String value = expr.substring(expr.indexOf("-") + 1).trim();
                result.append("i(n-").append(value).append(") = i(n)-").append(value).append(" ");
            }
            // Throw an exception if the format is unrecognized
            else {
                throw new RuntimeException("Couldn't evaluate update value for loop: " + expr);
            }
        }

        return result.toString().trim();
    }

    @Override
    public String visitForStatement(JavaParser.ForStatementContext ctx) {
        // Convert the for-loop components into equivalent FOL code
        String initialization = visit(ctx.forControl().forInit());
        String condition = visit(ctx.forControl().expression());
        String update = visit(ctx.forControl().forUpdate());
        String body = visit(ctx.statement());

        // Construct the FOL representation
        String equivalentFOLCode = "i(0)=i ^ ∀n<N (" + condition + " → " + body + " ^ " + update + ")";
        return equivalentFOLCode;
    }










    @Override
    public String visitRelationalExpression(JavaParser.RelationalExpressionContext ctx) {
        return getFormattedExpression(ctx);
    }

    @Override
    public String visitForInit(JavaParser.ForInitContext ctx) {
        if (ctx.localVariableDeclaration() != null) {
            return visit(ctx.localVariableDeclaration().variableDeclarators()
                    .variableDeclarator(0).variableDeclaratorId());
        } else {
            return visit(ctx.expressionList().expression(0).getChild(0));
        }

    }


    @Override
    public String visitTypeDeclaration(JavaParser.TypeDeclarationContext ctx) {
        mIndentation.push("\t");
        String output = "\n";
        if (ctx.classOrInterfaceModifier() != null) {
            for (int i = 0; i < ctx.classOrInterfaceModifier().size(); i++) {
                output += visitClassOrInterfaceModifier(ctx.classOrInterfaceModifier(i)) + " ";
            }
        }
        if (ctx.classDeclaration() != null) {
            output += visitClassDeclaration(ctx.classDeclaration());
        } else if (ctx.interfaceDeclaration() != null) {
            output += visitInterfaceDeclaration(ctx.interfaceDeclaration());
        } else { // Type declaration is enum
            output += visitEnumDeclaration(ctx.enumDeclaration());
        }
        mIndentation.pop();
        return output;
    }

    @Override
    public String visitClassOrInterfaceModifier(JavaParser.ClassOrInterfaceModifierContext ctx) {
        // Returns the modifier directly if it's available
        if (ctx.getChild(0) != null) {
            return ctx.getChild(0).toString();
        }
        return "";
    }

    @Override
    public String visitClassDeclaration(JavaParser.ClassDeclarationContext ctx) {
        // Extract the class name
        String className = ctx.Identifier().getText();

        // Visit the class body
        String classBody = visit(ctx.classBody());

        // Fetch modifiers (e.g., public, private)
        String classModifier = "default"; // Default modifier if none found
        if (ctx.parent instanceof JavaParser.TypeDeclarationContext) {
            JavaParser.TypeDeclarationContext parentCtx = (JavaParser.TypeDeclarationContext) ctx.parent;
            if (parentCtx.classOrInterfaceModifier() != null && !parentCtx.classOrInterfaceModifier().isEmpty()) {
                classModifier = visitClassOrInterfaceModifier(parentCtx.classOrInterfaceModifier(0));
            }
        }

        // Construct the output: public(class(Name))=(Body)
        String output =  "(class(" + className + "))=(" + classBody + ")";
        return output;
    }

    @Override
    public String visitClassBody(JavaParser.ClassBodyContext ctx) {
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < ctx.classBodyDeclaration().size(); i++) {
            String classBodyDeclarationString = visitClassBodyDeclaration(ctx.classBodyDeclaration().get(i));
            if (!classBodyDeclarationString.isEmpty()) {
                // Concatenate declarations with logical conjunction (^)
                if (output.length() > 0) {
                    output.append(" ^ ");
                }
                output.append(classBodyDeclarationString);
            }
        }
        return output.toString();
    }

    @Override
    public String visitClassBodyDeclaration(JavaParser.ClassBodyDeclarationContext ctx) {
        try {
            String output = "";

            if (ctx.getChild(0).toString().equals(";")) {
                return output;
            } else if (ctx.block() != null) {
                if (ctx.getChild(0).toString().equals("static")) {
                    output += "static ";
                }
                output += visitBlock(ctx.block());
            } else { //modifiers member
                if (ctx.member().constructorDeclaration() != null) { // member is a constructor
                    output += visitMember(ctx.member());
                } else if (ctx.member().fieldDeclaration() != null && isUserInterface(ctx.member().fieldDeclaration().type().getText())) { // member is a UI member
                    String UIDeclaration = "@IBOutlet weak var " + output;
                    UIDeclaration += visitMember(ctx.member());
                    output = UIDeclaration;
                } else {
                    output += visitModifiers(ctx.modifiers());
                    if (ctx.member().fieldDeclaration() != null) {
                        totalNumberOfStatements++;
                        boolean isConstant = false;
                        if (ctx.modifiers().children != null)  //check if there's constant
                            isConstant = checkIsConstant(ctx.modifiers().children);
                        if (isConstant) {
                            output += "let ";
                        } else {
                            output += "var ";
                        }
                    }
                    output += visitMember(ctx.member());
                }
            }

            return output + "\n";
        } catch (Exception e) {
            if (ctx.member().fieldDeclaration() != null) {
                unSupportedNumberOfStatements++;
                return getToDoCommentedJavaCode(ctx);
            } else throw e;
        }
    }
    @Override
    public String visitMember(JavaParser.MemberContext ctx) {
        String output = "";
        output += visitChildren(ctx);
        return output;
    }


    @Override
    public String visitFieldDeclaration(JavaParser.FieldDeclarationContext ctx) {
        StringBuilder output = new StringBuilder();
        for (JavaParser.VariableDeclaratorContext varCtx : ctx.variableDeclarators().variableDeclarator()) {
            String varType = ctx.type().getText();
            String varName = varCtx.variableDeclaratorId().getText();
            String varValue = visit(varCtx.variableInitializer());
            output.append(varType + "(" + varName + ") = " + varValue + " ^ ");
        }
        if (output.length() > 0) output.setLength(output.length() - 3); // Remove trailing " ^ "
        return output.toString();

    }


    @Override
    public String visitMethodDeclaration(JavaParser.MethodDeclarationContext ctx) {
        // Extract method name and return type
        String methodName = ctx.Identifier().getText();
        String returnType = ctx.type().getText();

        // Format method parameters
        String parameters = visit(ctx.formalParameters());

        // Construct FOL output
        String output = "public func(" + methodName + "(" + parameters + ")) = ";

        // Add method body or any additional content
        if (ctx.getChild(ctx.getChildCount() - 1) != null) {
            output += visit(ctx.getChild(ctx.getChildCount() - 1));
        }
        output += ")";
        return output;
    }



    //This is a function i added not in the baseVisitor due to exceptions position in swift
    public String visitMethodDeclarationRestException(JavaParser.MethodDeclarationRestContext ctx) {
        String output = "";
        if (ctx.children.toString().contains("throws")) {
            output += "throws " + visitQualifiedNameList(ctx.qualifiedNameList());
        }
        return output;
    }

    @Override
    public String visitMethodDeclarationRest(JavaParser.MethodDeclarationRestContext ctx) {
        String output = "";
        ParseTree child = ctx.getChild(ctx.getChildCount() - 1);
        if (child instanceof JavaParser.MethodBodyContext) {
            output += visitMethodBody((JavaParser.MethodBodyContext) child);
        }
        output += "\n";
        return output;
    }


    @Override
    public String visitMethodBody(JavaParser.MethodBodyContext ctx) {
        String output = "";
        output += visitBlock(ctx.block());
        return output;
    }

    @Override
    public String visitBlock(JavaParser.BlockContext ctx) {
        // Increase indentation for nested blocks
        mIndentation.push(mIndentation.peek() + "\t");
        StringBuilder output = new StringBuilder();

        // Iterate through all block statements in the current block
        for (int i = 0; i < ctx.blockStatement().size(); i++) {
            // Visit each block statement (which may include nested blocks)
            String blockStatementString = visitBlockStatement(ctx.blockStatement(i));

            if (blockStatementString.length() > 0) {
                // Handle multi-line statements by ensuring proper indentation
                if (blockStatementString.contains("\n")) {
                    blockStatementString = blockStatementString.replace("\n", "\n" + mIndentation.peek());
                }

                // Append the statement to the output with the current indentation level
                output.append(mIndentation.peek()).append(blockStatementString).append("\n");

                // Insert '^' between blocks and statements if necessary
                if (i < ctx.blockStatement().size() - 1) {
                    output.append(mIndentation.peek()).append(" ^ ").append("\n");
                }
            }
        }

        // Decrease indentation after processing the block
        mIndentation.pop();
        return output.toString();
    }


    @Override
    public String visitTemp2Statement(JavaParser.Temp2StatementContext ctx) {

        StringBuilder output = new StringBuilder();
        output.append(visitStatementExpression(ctx.statementExpression()));

        return output.toString();
    }

    @Override
    public String visitStatementExpression(JavaParser.StatementExpressionContext ctx) {
        StringBuilder output = new StringBuilder();
        output.append(visit(ctx.expression()));
        return output.toString();
    }


    @Override
    public String visitModifiers(JavaParser.ModifiersContext ctx) {
        String output = "";
        for (int i = 0; i < ctx.modifier().size(); i++) {
            output += visitModifier(ctx.modifier(i)) + " ";
        }
        return output;
    }

    @Override
    public String visitModifier(JavaParser.ModifierContext ctx) {
        StringBuilder output = new StringBuilder();
        if (ctx.annotation() != null) {
            output.append(visitAnnotation(ctx.annotation()));
        } else {
            switch (ctx.getChild(0).toString()) {
                case "public":
                    output.append("public");
                    break;

                case "protected":
                    output.append("internal"); //protected doesn't have an equivalent in swift bt internal is the closest thing to it.
                    break;

                case "private":
                    output.append("private");
                    break;

                case "static": //there's static keyword (for classes) in swift.
                    output.append("");

                case "abstract":
                    output.append(""); //todo
                    break;

                case "final":
                    output.append("");
                    break;

                case "native":
                    output.append(""); //todo
                    break;

                case "synchronized":
                    output.append(""); //todo
                    break;

                case "transient":
                    output.append(""); //todo
                    break;

                case "volatile":
                    output.append(""); //todo
                    break;

                case "strictfp":
                    output.append(""); //todo
                    break;

                default:
                    break;
            }
        }
        return output.toString();
    }

    @Override
    public String visitAnnotation(JavaParser.AnnotationContext ctx) { //todo (this function only handles Override)
        String output = "";
        if (ctx.annotationName().getText().equals("Override")) {
            output += "override";
        }
        return output;
    }

    @Override
    public String visitConstructorDeclaration(JavaParser.ConstructorDeclarationContext ctx) {
        String output = "init";
        output += visitFormalParameters(ctx.formalParameters()) + " ";
        output += visitConstructorBody(ctx.constructorBody()) + "\n";
        return output;
    }

    @Override
    public String visitConstructorBody(JavaParser.ConstructorBodyContext ctx) {
        StringBuilder output = new StringBuilder("");
        output.append(" \n");
        if (ctx.explicitConstructorInvocation() != null) {
            //todo
        }
        for (int i = 0; i < ctx.blockStatement().size(); i++) {
            output.append(mIndentation.peek()).append(visitBlockStatement(ctx.blockStatement(i))).append("\n");
        }
        output.append("\n ");
        return output.toString();
    }

    @Override
    public String visitFormalParameters(JavaParser.FormalParametersContext ctx) {
        StringBuilder output = new StringBuilder();
        output.append("(");
        if (ctx.formalParameterDecls() != null) {
            output.append(visitFormalParameterDecls(ctx.formalParameterDecls()));
        }
        output.append(")");
        return output.toString();
    }

    @Override
    public String visitFormalParameterDecls(JavaParser.FormalParameterDeclsContext ctx) {
        StringBuilder output = new StringBuilder();

        // Visit and append variable modifiers (if any), such as "final"
        if (visitVariableModifiers(ctx.variableModifiers()) != null) {
            output.append(visitVariableModifiers(ctx.variableModifiers())).append(" ");
        }

        // Keep the type and name of the parameter in its original form
        String type = ctx.type().getText();  // Original parameter type, e.g., "int", "String"
        String variable = visitVariableDeclaratorId(ctx.formalParameterDeclsRest().variableDeclaratorId());  // Parameter name, e.g., "a", "b"

        output.append(type).append(" ").append(variable);  // Add type and variable in original form

        // Handle further parameter declarations (for cases like multiple parameters)
        output.append(visitFormalParameterDeclsRest(ctx.formalParameterDeclsRest()));

        return output.toString();
    }

    @Override
    public String visitFormalParameterDeclsRest(JavaParser.FormalParameterDeclsRestContext ctx) {
        StringBuilder output = new StringBuilder();

        if (ctx.getChild(0).getText().equals("...")) {
            // Handle varargs (e.g., "int... args")
            output.append(ctx.getChild(1).getText());  // Output vararg as is
        } else {
            // Continue for multiple parameters in case there are more
            if (ctx.formalParameterDecls() != null) {
                output.append(", ").append(visitFormalParameterDecls(ctx.formalParameterDecls()));
            }
        }

        return output.toString();
    }


    @Override
    public String visitBlockStatement(JavaParser.BlockStatementContext ctx) {
        StringBuilder output = new StringBuilder();

        try {
            // Process all child nodes of the block statement
            List<ParseTree> children = ctx.children;
            if (children != null) {
                for (int i = 0; i < children.size(); i++) {
                    // Visit each child node (can be statements, expressions, etc.)
                    String childResult = visit(children.get(i));  // Recursive visit for nested blocks
                    output.append(childResult);

                    // Add ' ^ ' between statements if necessary, but avoid after the last child
                    if (i < children.size() - 1) {
                        output.append(" ^ ");
                    }
                }
            }
        } catch (Exception e) {
            // Handle any exceptions gracefully
            return getToDoCommentedJavaCode(ctx);
        } finally {
            totalNumberOfStatements++;  // Increment the counter for total statements
        }

        return output.toString();
    }

    @Override
    public String visitReturnStatement(JavaParser.ReturnStatementContext ctx) {
        StringBuilder output = new StringBuilder("return");
        if (ctx.expression() != null) {
            output.append(" (").append(visit(ctx.expression())).append(")");
        } else {
            output.append(" ()"); // Add empty parentheses for cases with no expression
        }
        return output.toString();
    }


    @Override
    public String visitPrimaryExpression(JavaParser.PrimaryExpressionContext ctx) {
        return visitPrimary(ctx.primary());
    }

    @Override
    public String visitExpressionTemp1(JavaParser.ExpressionTemp1Context ctx) {
        switch (ctx.expression().getText()) {
            case "this":
                return "self." + ctx.children.get(2).getText();
            case "super":
                return "super." + ctx.children.get(2).getText();
            case "R.string":
                String stringKey = ctx.Identifier().getText();
                return "NSLocalizedString(\"" + stringKey + "\", comment: \"\")";
        }
        StringBuilder output = new StringBuilder();
        String functionCaller = visit(ctx.expression());
        output.append(functionCaller).append(".");
        String className = null;
        if (mJavaToSwiftAssistant.isVariableIdentifiedBefore(functionCaller)) {
            className = getSwiftDataType(mJavaToSwiftAssistant.getVariableJavaDataType(functionCaller));
            int indexOfAngleBracket = className.indexOf("<");
            if (indexOfAngleBracket != -1) {
                className = className.substring(0, indexOfAngleBracket);
            }
        }
        String javaFunctionName = ctx.Identifier().toString();
        String swiftFunctionName = null;
        if (mFunctionsInSwift.containsKey(className))
            swiftFunctionName = mFunctionsInSwift.get(className).get(javaFunctionName);
        if (swiftFunctionName == null) swiftFunctionName = javaFunctionName;
        output.append(swiftFunctionName);
        return output.toString();
    }

    @Override
    public String visitExpressionTemp2(JavaParser.ExpressionTemp2Context ctx) {
        StringBuilder output = new StringBuilder();
        output.append(visit(ctx.expression())).append(".").append("self");
        return output.toString();
    }

    @Override
    public String visitExpressionTemp3(JavaParser.ExpressionTemp3Context ctx) {
        StringBuilder output = new StringBuilder();
        //TODO
        return output.toString();
    }

    @Override
    public String visitExpressionTemp4(JavaParser.ExpressionTemp4Context ctx) {
        StringBuilder output = new StringBuilder();
        //TODO
        return output.toString();
    }

    @Override
    public String visitExpressionTemp5(JavaParser.ExpressionTemp5Context ctx) {
        StringBuilder output = new StringBuilder();
        //TODO
        return output.toString();
    }

    @Override
    public String visitExpressionTemp6(JavaParser.ExpressionTemp6Context ctx) {
        StringBuilder output = new StringBuilder();
        //TODO
        return output.toString();
    }

    @Override
    public String visitExpressionTemp7(JavaParser.ExpressionTemp7Context ctx) {
        StringBuilder output = new StringBuilder();
        output.append(ctx.expression().get(0)).append("[").append(ctx.expression().get(1)).append("]");
        return output.toString();
    }

    @Override
    public String visitExpressionList(JavaParser.ExpressionListContext ctx) {
        StringBuilder stringBuilder = new StringBuilder();
        for (JavaParser.ExpressionContext expressionContext : ctx.expression()) {
            stringBuilder.append(visit(expressionContext)).append(", ");
        }
        stringBuilder.delete(stringBuilder.length() - 2, stringBuilder.length());
        return stringBuilder.toString();
    }


    //function call
    @Override
    public String visitExpressionTemp8(JavaParser.ExpressionTemp8Context ctx) {
        String input = ctx.getText();
        //if statement is setContentView(R.layout.activity_main);
        if (ctx.getChild(0).getText().equals("setContentView")) {//ignore setContentView line
            //layoutfileCompleteName = R.layout.activity_main
            String layoutFileCompleteName = ctx.getChild(2).getText();


            //setlayoutname to activity_main.xml which is the name of the xml file
            mJavaToSwiftAssistant.setLayoutName(layoutFileCompleteName.
                    substring(layoutFileCompleteName.lastIndexOf('.') + 1) + ".xml");
            return "";
        } else if (ctx.expression().getText().equals("startActivity")) {
            AndroidIntent intent = mJavaToSwiftAssistant.getIntent(ctx.expressionList().getText());
            return intent.getEquivalentSwiftCode();
        } else if (ctx.expression().getText().equals("startActivityForResult")) {
            AndroidIntent intent = mJavaToSwiftAssistant.getIntent(ctx.expressionList().expression(0).getText());
            mJavaToSwiftAssistant.addNewIntentActivityResult(ctx.expressionList().expression(1).getText(), intent);
            return intent.getEquivalentSwiftCode();
        }
        else if(ctx.expression().getText().equals("getResources().getString")
                || ctx.expression().getText().equals("getString")){
            String stringKey = ctx.expressionList().expression(0).getChild(2).getText();
            return "NSLocalizedString(\"" + stringKey + "\", comment: \"\")";
        }

        StringBuilder output = new StringBuilder();

        //function()
        if (ctx.expression().getClass() == JavaParser.PrimaryExpressionContext.class) {

            output.append(visitPrimaryExpression((JavaParser.PrimaryExpressionContext) ctx.expression()) + "(");
            if (ctx.expressionList() != null) {
                output.append(visitExpressionList(ctx.expressionList()));
            }
            output.append(")");
        }

        // object.function() or Class.function()
        else {

            String functionString = ctx.getText();
            JavaParser.ExpressionTemp1Context functionCallExpression = (JavaParser.ExpressionTemp1Context) ctx.expression();
            String javaFunctionCaller = functionCallExpression.expression().getText();
            String swiftFunctionCaller = visit(functionCallExpression.expression());


            //  if(ctx.expression().cl)
            //todo
            String functionCallerSwiftDataType = "";
            String functionCallerJavaDataType = "";

            // getting the function caller java data type
            if (mJavaToSwiftAssistant.isVariableIdentifiedBefore(javaFunctionCaller)) {
                functionCallerJavaDataType = mJavaToSwiftAssistant.getVariableJavaDataType(javaFunctionCaller);
                if (functionCallerJavaDataType.equals("Intent")) {
                    AndroidIntent intent = mJavaToSwiftAssistant.getIntent(javaFunctionCaller);
                    String intentJavaFunction = functionCallExpression.Identifier().toString();
                    if (intentJavaFunction.equals("setData")) {
                        String argumentsString =
                                visitExpressionList((JavaParser.ExpressionListContext) ctx.expressionList().expression(0).getChild(2));//argumrnts of Uri.Parse
                        intent.setURI(argumentsString);
                    }
                    return "";
                } else if (functionCallerJavaDataType.equals("SharedPreferences.Editor")) {
                    swiftFunctionCaller = mJavaToSwiftAssistant.getEditorSharedPreference(javaFunctionCaller);
                }
            } else if (javaFunctionCaller.equals("super")) {
                functionCallerJavaDataType = mJavaToSwiftAssistant.getParentClassName();
            } else if (mStaticFunctionsInSwift.containsKey(javaFunctionCaller)) { //todo was made to handle commenting staticBuilt in functions
                functionCallerJavaDataType = javaFunctionCaller;
            } else {
                functionCallerJavaDataType = mJavaToSwiftAssistant.getSwiftFunctionJavaReturnType(javaFunctionCaller);
            }
            // getting the function caller swift data type
            functionCallerSwiftDataType = getSwiftDataType(functionCallerJavaDataType);

            output.append(swiftFunctionCaller).append(".");
            String genericType = null;
            String[] functionArgumentsConvertedToSwift = new String[0];
            String argumentsString = "";
            String argumentsDataTypes = "";

            if (ctx.expressionList() != null) {
                argumentsString = visitExpressionList(ctx.expressionList());
                functionArgumentsConvertedToSwift = argumentsString.split(", *");

                String[] javaFunctionArguments = ctx.expressionList().getText().split(", *");
                argumentsDataTypes = getArgumentsJavaDataTypes(javaFunctionArguments);

            }

            int indexOfAngleBracket = functionCallerSwiftDataType.indexOf("<");
            if (indexOfAngleBracket != -1) {
                genericType = functionCallerSwiftDataType.substring(indexOfAngleBracket + 1, functionCallerSwiftDataType.lastIndexOf(">"));
                functionCallerSwiftDataType = functionCallerSwiftDataType.substring(0, indexOfAngleBracket);
                argumentsDataTypes = argumentsDataTypes.replaceAll(genericType, "Object");
            }
            String javaFunctionName = functionCallExpression.Identifier().toString() + '(' + argumentsDataTypes + ')';


            mJavaToSwiftAssistant.addNewVariableFunction(functionCallerJavaDataType,
                    javaFunctionCaller, javaFunctionName, functionString);

            if (mFunctionsInSwift.containsKey(functionCallerSwiftDataType) && mFunctionsInSwift.get(functionCallerSwiftDataType).containsKey(javaFunctionName)) {
                if (mJavaToSwiftAssistant.hasNoEquivalentFunctionInSwift(functionCallerSwiftDataType, javaFunctionName)) {
                    return "";
                }
                String swiftFunction = mFunctionsInSwift.get(functionCallerSwiftDataType).get(javaFunctionName);
                for (int i = 0; i < functionArgumentsConvertedToSwift.length; i++) {
                    if (!swiftFunction.contains("/"))
                        break;
                    String argument = functionArgumentsConvertedToSwift[i];
                    swiftFunction = swiftFunction.replace('/' + String.valueOf(i), argument);
                }
                output.append(swiftFunction);

            }else if (isSubString(javaFunctionName)){
                String swiftFunction = mJavaToSwiftAssistant.getSubStringEquivalentCode(swiftFunctionCaller, javaFunctionName,functionArgumentsConvertedToSwift);
                output = new StringBuilder(swiftFunction);

            } else if (mOperatorsInSwift.containsKey(functionCallerSwiftDataType) && mOperatorsInSwift.get(functionCallerSwiftDataType).containsKey(javaFunctionName)) {
                output.deleteCharAt(output.length() - 1);
                String swiftFunction = mOperatorsInSwift.get(functionCallerSwiftDataType).get(javaFunctionName);
                for (int i = 0; i < functionArgumentsConvertedToSwift.length; i++) {
                    String argument = functionArgumentsConvertedToSwift[i];
                    swiftFunction = swiftFunction.replace('/' + String.valueOf(i), argument);
                }
                output.append(swiftFunction);

            } else if (JavaToSwiftAssistant.containsStaticFunction(javaFunctionCaller, javaFunctionName)) {
                String swiftFunction = JavaToSwiftAssistant.getEquivalentSwiftForStaticMethod(javaFunctionCaller, javaFunctionName);
                for (int i = 0; i < functionArgumentsConvertedToSwift.length; i++) {
                    String argument = functionArgumentsConvertedToSwift[i];
                    swiftFunction = swiftFunction.replace('/' + String.valueOf(i), argument);
                }
                output = new StringBuilder(swiftFunction);
            } else if (isUserInterfaceAndObserverFunction(functionCallerSwiftDataType,
                    javaFunctionName.substring(0, javaFunctionName.indexOf('(')))) {
                String swiftEquivalentCode = "";
                if (functionCallerJavaDataType.equals("Button")) {
                    String swiftTargetMethod = visitMethodDeclarationRest((JavaParser.MethodDeclarationRestContext) ctx.expressionList().expression(0).getChild(1).getChild(1).getChild(1).getChild(1).getChild(1).getChild(0).getChild(3));
                    swiftEquivalentCode = mJavaToSwiftAssistant.getSwiftEquivalentJavaObserverCode(functionCallerSwiftDataType,
                            javaFunctionName.substring(0, javaFunctionName.indexOf('(')), javaFunctionCaller, swiftTargetMethod, "");

                } else if (functionCallerJavaDataType.equals("EditText")) {
                    if (javaFunctionName.startsWith("addTextChangedListener")) {
                        JavaParser.ClassBodyContext classBodyContext = (JavaParser.ClassBodyContext) ctx.expressionList().expression(0).getChild(1).getChild(1).getChild(1); //get class body
                        if (classBodyContext != null) {
                            //for (int i = 0; i < ctx.expressionList().expression(0).getChild(1).getChild(1).getChild(1).getChildCount(); i++) {
                            for (JavaParser.ClassBodyDeclarationContext classBodyDeclarationContext : classBodyContext.classBodyDeclaration()) {


                                if (classBodyDeclarationContext.getText().contains("afterTextChanged")) {
                                    String targetMethodFormalParameters = visitFormalParameters(classBodyDeclarationContext.member().methodDeclaration().formalParameters());
                                    String swiftTargetMethod = visitMethodDeclarationRest((JavaParser.MethodDeclarationRestContext) classBodyDeclarationContext.getChild(1).getChild(0).getChild(3));
                                    swiftEquivalentCode = mJavaToSwiftAssistant.getSwiftEquivalentJavaObserverCode(functionCallerSwiftDataType,
                                            javaFunctionName.substring(0, javaFunctionName.indexOf('(')), javaFunctionCaller, swiftTargetMethod, targetMethodFormalParameters);

                                }
                            }

                        }
                    }
                } else if (functionCallerJavaDataType.equals("CheckBox")) {
                    if (javaFunctionName.startsWith("setOnCheckedChangeListener")) {
                        JavaParser.ClassBodyContext classBodyContext = (JavaParser.ClassBodyContext) ctx.expressionList().expression(0).getChild(1).getChild(1).getChild(1); //get class body
                        if (classBodyContext != null) {
                            for (JavaParser.ClassBodyDeclarationContext classBodyDeclarationContext : classBodyContext.classBodyDeclaration()) {
                                if (classBodyDeclarationContext.getText().contains("onCheckedChanged")) {
                                    String targetMethodFormalParameters = visitFormalParameters(classBodyDeclarationContext.member().methodDeclaration().formalParameters());
                                    String swiftTargetMethod = visitMethodDeclarationRest((JavaParser.MethodDeclarationRestContext) classBodyDeclarationContext.getChild(1).getChild(0).getChild(3));
                                    swiftEquivalentCode = mJavaToSwiftAssistant.getSwiftEquivalentJavaObserverCode(functionCallerSwiftDataType,
                                            javaFunctionName.substring(0, javaFunctionName.indexOf('(')), javaFunctionCaller, swiftTargetMethod, targetMethodFormalParameters);
                                }
                            }
                        }
                    }
                } else if (functionCallerJavaDataType.equals("ImageView")) {
                    if (javaFunctionName.startsWith("setOnClickListener")) {
                        JavaParser.ClassBodyContext classBodyContext = (JavaParser.ClassBodyContext) ctx.expressionList().expression(0).getChild(1).getChild(1).getChild(1); //get class body
                        if (classBodyContext != null) {
                            for (JavaParser.ClassBodyDeclarationContext classBodyDeclarationContext : classBodyContext.classBodyDeclaration()) {
                                if (classBodyDeclarationContext.getText().contains("onClick")) {
                                    String targetMethodFormalParameters = visitFormalParameters(classBodyDeclarationContext.member().methodDeclaration().formalParameters());
                                    String swiftTargetMethod = visitMethodDeclarationRest((JavaParser.MethodDeclarationRestContext) classBodyDeclarationContext.getChild(1).getChild(0).getChild(3));
                                    swiftEquivalentCode = mJavaToSwiftAssistant.getSwiftEquivalentJavaObserverCode(functionCallerSwiftDataType,
                                            javaFunctionName.substring(0, javaFunctionName.indexOf('(')), javaFunctionCaller, swiftTargetMethod, targetMethodFormalParameters);
                                }
                            }
                        }
                    }
                }
                output = new StringBuilder(swiftEquivalentCode);
            } else {

                try {
                    output.append(JavaToSwiftAssistant.getSwiftFunctionSyntax(functionCallerSwiftDataType, functionArgumentsConvertedToSwift, javaFunctionName));
                } catch (Exception e) {
                    return getToDoCommentedJavaCode(ctx);
                }
            }
        }
        // sometimes functions in java are mapped to nothing ..... for example x.getText().toString in java
        // equivalent to x.text! in swift where toString is converted to  text! but getText has no mapping
        //so when x.getText() is visited here
        // it should be converted to x only ...... and this if is to remove the dot if it waas the last character
        if (output.charAt(output.length() - 1) == '.')
            output.deleteCharAt(output.length() - 1);
        return output.toString();

    }

    private String getArgumentsJavaDataTypes(String[] arguments) {
        StringBuilder stringBuilder = new StringBuilder();
        for (String argument : arguments) {
            stringBuilder.append(mJavaToSwiftAssistant.getJavaDataType(argument));
            //stringBuilder.append(mIdentifersTypes.getOrDefault(argument, defaultDataType));
            stringBuilder.append(',');
        }
        stringBuilder.deleteCharAt(stringBuilder.length() - 1);
        return stringBuilder.toString();
    }

    @Override
    public String visitPostfixExpression(JavaParser.PostfixExpressionContext ctx) {
        String value;
        if (ctx.getChild(1).getText().equals("++"))
            value = "+= 1";
        else {
            value = "-= 1";
        }
        return visit(ctx.expression()) + " " + value;
    }

    @Override
    public String visitUnaryAdditiveExpression(JavaParser.UnaryAdditiveExpressionContext ctx) {
        String postfixOperator = "";
        String operator = ctx.getChild(0).getText();
        if (operator.equals("++")) {
            postfixOperator = "+= 1";
            return visit(ctx.expression()) + " " + postfixOperator;
        } else if (operator.equals("--")) {
            postfixOperator = "-= 1";
            return visit(ctx.expression()) + " " + postfixOperator;
        } else {
            return operator + visit(ctx.expression());

        }

    }

    @Override
    public String visitConditionalExpression(JavaParser.ConditionalExpressionContext ctx) {
        StringBuilder output = new StringBuilder();
        output.append(visit(ctx.expression(0))).append(" ? ").append(visit(ctx.expression(1))).append(" : ").append(visit(ctx.expression(2)));
        return output.toString();
    }

    @Override
    public String visitTypeCastingExpression(JavaParser.TypeCastingExpressionContext ctx) {
        StringBuilder output = new StringBuilder();
        output.append(visit(ctx.expression())).append(": ").append(visitType(ctx.type()));
        return output.toString();
    }


    @Override
    public String visitLocalVariableDeclarationStatement(JavaParser.LocalVariableDeclarationStatementContext ctx) {
        String value = visitLocalVariableDeclaration(ctx.localVariableDeclaration());
        return value;
    }


    @Override
    public String visitPrimitiveType(JavaParser.PrimitiveTypeContext ctx) {
        return ctx.getText();
    }

    /**
     * @param ctx
     * @return the swift equivalent class
     */

    @Override
    public String visitClassOrInterfaceType(JavaParser.ClassOrInterfaceTypeContext ctx) {
        String value;
        String className = getSwiftDataType(ctx.children.get(0).getText());

        value = className;
        if (ctx.typeArguments() != null && !ctx.typeArguments().isEmpty()) {
            value += visitTypeArguments(ctx.typeArguments().get(0));

        }
        return value;
    }

    @Override
    public String visitInstantiativeExpression(JavaParser.InstantiativeExpressionContext ctx) {
        return visitCreator(ctx.creator());
    }

    @Override
    public String visitCreator(JavaParser.CreatorContext ctx) {
        return visitCreatedName(ctx.createdName()) + visitClassCreatorRest(ctx.classCreatorRest());
    }

    @Override
    public String visitClassCreatorRest(JavaParser.ClassCreatorRestContext ctx) {
        /*StringBuilder output = new StringBuilder();
        if (ctx.arguments() != null) {
            output.append(visitArguments(ctx.arguments()));
        }
        if(ctx.classBody()!=null)
            output.append(visitClassBody(ctx.classBody()));

        return output.toString();
 */
        return "()";
    }

    @Override
    public String visitArguments(JavaParser.ArgumentsContext ctx) {
        String output = "(";
        if (ctx.expressionList() != null)
            output += visitExpressionList(ctx.expressionList());
        output += ")";
        return output;
    }

    @Override
    public String visitCreatedName(JavaParser.CreatedNameContext ctx) {
        String constructorName = visit(ctx.getChild(0));
        if (constructorName.endsWith(">")) {
            constructorName = constructorName.substring(0, constructorName.indexOf('<'));
        }
        return constructorName;
    }

    @Override
    public String visitTypeArguments(JavaParser.TypeArgumentsContext ctx) {
        StringBuilder value = new StringBuilder("<");
        for (JavaParser.TypeArgumentContext typeArgumentContext : ctx.typeArgument()) {
            value.append(visitTypeArgument(typeArgumentContext));
            value.append(", ");
        }
        value.delete(value.length() - 2, value.length());
        value.append(">");

        return value.toString();
    }

    @Override
    public String visitTypeArgument(JavaParser.TypeArgumentContext ctx) {
        return getSwiftDataType(ctx.getText());
    }

    @Override
    public String visitType(JavaParser.TypeContext ctx) {
        String value = null;
        if (ctx.primitiveType() != null)
            value = getSwiftDataType(visitPrimitiveType(ctx.primitiveType()));
        else value = visitClassOrInterfaceType(ctx.classOrInterfaceType());
        return value;

    }

    @Override
    public String visitLocalVariableDeclaration(JavaParser.LocalVariableDeclarationContext ctx) {
        String value = "";
        //check if AndroidIntent
        String type = ctx.type().getText();

        saveVariableTypes(ctx.variableDeclarators(), type);
        if (type.equals("Intent")) {
            saveIntent(ctx);
            return "";
        }

        boolean isConstant = false;
        if (ctx.variableModifiers().children != null)  //check if there's constant
            isConstant = checkIsConstant(ctx.variableModifiers().children);
        if (isConstant) {
            value += "";
        } else {
            value += "";
        }

        String variableDeclarations = visitVariableDeclarators(ctx.variableDeclarators());
        if (variableDeclarations.equals("")) { //variable has no equivalent in swift
            return "";
        }
        value += variableDeclarations;
        if (value.contains("else")) { //variable is declared using guard
            value = value.replace("var", "guard let");
        }


        return value;
    }

    /**
     * this fn used to save new intent ... it's called only on declaration of an intent
     * eg.:  Intent intent = new Intent()
     * it's saves the intent in the assistant
     *
     * @param ctx it's the ctx of declaration
     */
    private void saveIntent(JavaParser.LocalVariableDeclarationContext ctx) {
        String objectName = ctx.variableDeclarators().variableDeclarator().get(0).children.get(0).getText(); // gets the variableDeclaratorID (intent name).

        // getting Intent constructor parameters

        JavaParser.InstantiativeExpressionContext instantiativeExpressionContext = (JavaParser.InstantiativeExpressionContext)
                ctx.variableDeclarators().variableDeclarator(0).variableInitializer().expression();
        JavaParser.ExpressionListContext expressionListContext = instantiativeExpressionContext.creator().
                classCreatorRest().arguments().expressionList();
        ArrayList<String> constructorParameters = new ArrayList<>(3);
        for (JavaParser.ExpressionContext expressionContext : expressionListContext.expression()) {
            constructorParameters.add(expressionContext.getText());

        }

        AndroidIntent intent = new AndroidIntent();
        //check if explicit intent
        if (constructorParameters.size() > 1 && constructorParameters.get(1).contains(".class")) {
            intent.setTargetedActivity(constructorParameters.get(1));
            intent.setCurrentActivity(mJavaToSwiftAssistant.getClassName());
        } else {
            intent.setAction(constructorParameters.get(0));
            if (constructorParameters.size() == 2) { //means uri is passed as parameter
                String uriInSwift = visitExpressionList((JavaParser.ExpressionListContext) expressionListContext.expression().get(1).getChild(2));//gets expressionListContext.expressionTemp8.expressionList
                intent.setURI(uriInSwift);
            }
        }


        mJavaToSwiftAssistant.addNewIntent(objectName, intent);

    }

    private void saveVariableTypes(JavaParser.VariableDeclaratorsContext variableDeclaratorsContext, String type) {
        for (ParseTree p : variableDeclaratorsContext.variableDeclarator()) {
            JavaParser.VariableDeclaratorContext temp = (JavaParser.VariableDeclaratorContext) p;
            mJavaToSwiftAssistant.addNewVariable(temp.variableDeclaratorId().getText(), type, "");
        }
    }


    @Override
    public String visitLiteral(JavaParser.LiteralContext ctx) {
        StringBuilder value = new StringBuilder(ctx.getText());


        // if character value  replace single quot with double quotation 'a' --> "a"
        if (value.charAt(0) == '\'' && value.charAt(value.length() - 1) == '\'') {
            value.replace(0, 1, "\"");
            value.replace(value.length() - 1, value.length(), "\"");
        }
        String type = null;
        if (ctx.StringLiteral() != null) {
            type = "String";
        } else if (ctx.integerLiteral() != null) {
            type = "int";
        }
        //todo test regex
        else if (ctx.getText().matches("[-]?[0-9]*\\.?[0-9]+")) {
            type = "double";
        } else if (ctx.toString().startsWith("\"") && ctx.toString().endsWith("\"")) {
            type = "String";
        }
        //todo add all types
        // mJavaToSwiftAssistant.addNewVariable(result, type);
        return value.toString();
    }

    @Override
    public String visitPrimary(JavaParser.PrimaryContext ctx) {
        if (ctx.getChild(0).getText().equals("this")) {
            return "self";
        } else if (ctx.Identifier() != null) {
            return ctx.Identifier().getText();
        } else if (ctx.getChild(0).getText().equals("super")) {
            return "super";
        } else if (ctx.expression() != null) {
            StringBuilder output = new StringBuilder();
            output.append("(").append(visit(ctx.expression())).append(")");
            return output.toString();
        }
        return visitLiteral(ctx.literal());
    }


    @Override
    public String visitVariableInitializer(JavaParser.VariableInitializerContext ctx) {
        String value = "";
        if (ctx.expression() != null) {
            value = visit(ctx.expression());
        } else if (ctx.arrayInitializer() != null) {
            value = visitArrayInitializer(ctx.arrayInitializer());
        }
        return value;
    }


    @Override
    public String visitVariableDeclaratorId(JavaParser.VariableDeclaratorIdContext ctx) {
        return ctx.getText();
    }

    @Override
    public String visitVariableDeclarator(JavaParser.VariableDeclaratorContext ctx) {
        String variableDeclaratorId = visitVariableDeclaratorId(ctx.variableDeclaratorId());
        String javaDataType = mJavaToSwiftAssistant.getVariableJavaDataType(variableDeclaratorId);
        String swiftDataType = getSwiftDataType(javaDataType); // Convert to Swift type if needed
        String value;

        // Format type and variable
        value = javaDataType + " (" + variableDeclaratorId + ")";

        // Add initializer if present
        if (ctx.variableInitializer() != null) {
            value += " = " + visitVariableInitializer(ctx.variableInitializer());
        } else {
            // Default values for uninitialized variables
            switch (javaDataType) {
                case "int":
                case "Integer":
                    value += " = 0";
                    break;
                case "double":
                case "float":
                    value += " = 0.0";
                    break;
                case "String":
                case "char":
                    value += " = \"\"";
                    break;
                case "boolean":
                    value += " = false";
                    break;
                default:
                    value += " = null"; // Generic default
                    break;
            }
        }

        // Return the formatted variable string (caret handling moved to the other method)
        return value;
    }

    @Override
    public String visitVariableDeclarators(JavaParser.VariableDeclaratorsContext ctx) {
        StringBuilder value = new StringBuilder();
        List<JavaParser.VariableDeclaratorContext> variableDeclarators = ctx.variableDeclarator();

        for (int i = 0; i < variableDeclarators.size(); i++) {
            // Visit each variable declarator and append it
            value.append(visitVariableDeclarator(variableDeclarators.get(i)));

            // Append '^' between variable declarations if there's more than one
            if (i < variableDeclarators.size() - 1) {
                value.append(" ^");
            }
        }

        return value.toString();
    }




    private boolean checkIsConstant(List<ParseTree> children) {

        for (ParseTree p : children) {
            if (p.getText().equals("final")) {
                return true;

            }
        }
        return false;

    }

    private void printChildren(ParserRuleContext p) {
        System.out.println("Printing children of " + p.getText());
        for (ParseTree t : p.children) {
            System.out.println(t.getText());
        }
    }

    @Override
    public String visitEnumDeclaration(JavaParser.EnumDeclarationContext ctx) {
        //todo , enumBodyDeclarations
        String value = ctx.children.get(0).getText()
                + " " + ctx.children.get(1).getText()
                + " " + visitEnumBody(ctx.enumBody());
        return value;
    }


    @Override
    public String visitEnumBody(JavaParser.EnumBodyContext ctx) {
        StringBuilder value = new StringBuilder("" +
                "\n" + mIndentation.peek() + "case ");
        for (ParseTree child : ctx.enumConstants().children) {
            value.append(child.getText());
        }
        value.append("\n");
        return value.toString();
    }

    @Override
    public String visitArrayInitializer(JavaParser.ArrayInitializerContext ctx) {
        //todo: make sure variableInitializer doesn't mess this function up
        StringBuilder value = new StringBuilder("[");//[2,4,5,6]
        for (ParseTree child : ctx.variableInitializer()) {
            value.append(visit(child)).append(",");
        }
        value.deleteCharAt(value.length() - 1);
        value.append("]");
        return value.toString();
    }

    /*@Override
    public String visitArrayInitializer(JavaParser.ArrayInitializerContext ctx) {
        //todo: make sure variableInitializer doesn't mess this function up
        StringBuilder value = new StringBuilder("[");//[2,4,5,6]
        for (ParseTree child : ctx.children) {
            if (!child.getText().equals("{") && !child.getText().equals("}"))
                value.append(child.getText());
        }
        value.append("]");
        return value.toString();
    }*/

    @Override
    public String visitIntegerLiteral(JavaParser.IntegerLiteralContext ctx) {
        String value = ctx.children.get(0).getText();
        //mIdentifersTypes.put(value, "int");
        return value;
    }

    @Override
    public String visitArrayCreatorRest(JavaParser.ArrayCreatorRestContext ctx) {
        //todo: find in swift equivalent to: int intArray = new int[20];
        if (ctx.children.get(1).getText().equals("]"))
            return visitArrayInitializer(ctx.arrayInitializer());
        return "";
    }
    @Override
    public String visitIfStatement(JavaParser.IfStatementContext ctx) {
        StringBuilder value = new StringBuilder();


        String condition = visit(ctx.getChild(1)); // Access 'parExpression'
        String ifBlock = visit(ctx.getChild(2));   // Access 'statement' for the 'if' block
        value.append("(").append(condition).append(") → (").append(ifBlock).append(" ^ break)");

        // Handle 'else if' and 'else'
        if (ctx.getChildCount() > 3) { // Check if there is an 'else' block
            if (ctx.getChild(4).getClass().getSimpleName().equals("IfStatementContext")) {
                // 'else if': Recursively visit the nested 'ifStatement'
                value.append(" ∨ (~").append(condition).append(" ∧ (")
                        .append(visit((JavaParser.IfStatementContext) ctx.getChild(4))).append("))");
            } else {
                // Regular 'else'
                String elseBlock = visit(ctx.getChild(4)); // Access 'statement' for the 'else' block
                value.append(" ∨ (~").append(condition).append(") → (").append(elseBlock).append(" ^ break)");
            }
        }

        return value.toString();
    }





    @Override
    public String visitParExpression(JavaParser.ParExpressionContext ctx) {
        return visit(ctx.children.get(1));

    }

    @Override
    public String visitEmptyStatement(JavaParser.EmptyStatementContext ctx) {
        return "";
    }

    @Override
    public String visitWhileStatement(JavaParser.WhileStatementContext ctx) {
        StringBuilder folRepresentation = new StringBuilder();

        // Initial assignment of the variable (no type declaration)
        String initAssignment = "i(0) = i^";

        // Loop condition
        String condition = visitParExpression(ctx.parExpression());

        // Body of the loop
        String returnStatement = "return i";

        // Determine increment/decrement behavior
        String incrementStatement = processIncrementDecrement(ctx);

        // Build the FOL structure
        folRepresentation.append(initAssignment)
                .append("\n\t∀n<N ( ")
                .append(condition)
                .append(" → \n\t")
                .append(returnStatement)
                .append("\n^ ")
                .append(incrementStatement)
                .append("\n)");

        return folRepresentation.toString();
    }

    // Helper method to process increment and decrement operations
    private String processIncrementDecrement(JavaParser.WhileStatementContext ctx) {
        // Assume ctx has an expression for the update (i.e., increment or decrement)
        String updateExpression = visit(ctx.statement()); // Assuming the update is part of the statement

        if (updateExpression.contains("+=")) {
            return "i(n+1) = i(n) + 1";  // i++ or i += 1
        } else if (updateExpression.contains("-=")) {
            return "i(n-1) = i(n) - 1";  // i-- or i -= 1
        } else if (updateExpression.contains("=")) {
            // Handle explicit assignments like "i = i + 1" or "i = i - 1"
            String assignmentValue = updateExpression.substring(updateExpression.indexOf("=") + 1).trim();
            if (assignmentValue.contains("+")) {
                return "i(n+1) = i(n) + " + extractIncrement(assignmentValue);
            } else if (assignmentValue.contains("-")) {
                return "i(n-1) = i(n) - " + extractDecrement(assignmentValue);
            }
        }
        return ""; // Default case if no increment or decrement is found
    }

    // Helper method to extract the increment value from expressions like "i = i + 1"
    private String extractIncrement(String expression) {
        String[] parts = expression.split("\\+");
        return parts[1].trim();  // Extract the value after the "+"
    }

    // Helper method to extract the decrement value from expressions like "i = i - 1"
    private String extractDecrement(String expression) {
        String[] parts = expression.split("-");
        return parts[1].trim();  // Extract the value after the "-"
    }




    @Override
    public String visitDoWhileStatement(JavaParser.DoWhileStatementContext ctx) {
        //todo: test more after expression is finished
        StringBuilder value = new StringBuilder("repeat ");
        value.append(visit(ctx.children.get(1))).append(" while ").append(visitParExpression(ctx.parExpression()));
        //value.append(visitParExpression(ctx.parExpression())).append(" ").append(ctx.children.get(2).getText());
        return value.toString();
    }

    @Override
    public String visitAssignmentExpression(JavaParser.AssignmentExpressionContext ctx) {
        //todo >>>= operator
        return getFormattedExpression(ctx);
    }

    @Override
    public String visitShiftExpression(JavaParser.ShiftExpressionContext ctx) {
        //todo >>>= operator
        return getFormattedExpression(ctx);
    }

    @Override
    public String visitMultiplicativeExpression(JavaParser.MultiplicativeExpressionContext ctx) {
        return getFormattedExpression(ctx);
    }

    @Override
    public String visitEqualityExpression(JavaParser.EqualityExpressionContext ctx) {
        return getFormattedExpression(ctx);
    }


    /**
     * @param ctx root node of expression
     * @return the expression as string after putting spaces behind and after each operator
     */
    private String getFormattedExpression(ParserRuleContext ctx) {
        if (ctx.getChild(2).getText().contains("findViewById")) {
            String referencingIdExpression = ctx.getChild(2).getText();
            String objectName = ctx.getChild(0).getText();
            String id = referencingIdExpression.substring(referencingIdExpression.indexOf("id.") + 3, referencingIdExpression.length() - 1);//store the id and objectName
            mJavaToSwiftAssistant.addNewObjectId(id, objectName);
            return ""; //ignore findViewById
        }

        StringBuilder value = new StringBuilder();
        for (ParseTree child : ctx.children) {
            if (child.getClass() == TerminalNodeImpl.class) {
                value.append(child.getText());
            } else {
                if (child.getText().contains("substring")){
                    String childOutput = visit(child);
                    String[] subStringDeclarationLines = childOutput.split("\n");
                    subStringDeclarationLines[3] = value.substring(1) + " " + subStringDeclarationLines[3];
                    value = new StringBuilder(" ").append(subStringDeclarationLines[0]).append("\n").append(subStringDeclarationLines[1]).append("\n")
                            .append(subStringDeclarationLines[2]).append("\n").append(subStringDeclarationLines[3]).append("\n");
                } else{

                    value.append(" ").append(visit(child)).append(" ");
                }
            }

        }
        value.deleteCharAt(0);
        value.deleteCharAt(value.length() - 1);
        return value.toString();
    }

    @Override
    public String visitBitwiseORExpression(JavaParser.BitwiseORExpressionContext ctx) {
        return getFormattedExpression(ctx);
    }

    @Override
    public String visitBitwiseANDExpressiom(JavaParser.BitwiseANDExpressiomContext ctx) {
        return getFormattedExpression(ctx);
    }

    @Override
    public String visitBitwiseXORExpression(JavaParser.BitwiseXORExpressionContext ctx) {
        return getFormattedExpression(ctx);
    }

    @Override
    public String visitAdditiveExpression(JavaParser.AdditiveExpressionContext ctx) {


        return getFormattedExpression(ctx);
    }

    @Override
    public String visitLogicalANDExpression(JavaParser.LogicalANDExpressionContext ctx) {
        return getFormattedExpression(ctx);
    }

    @Override
    public String visitLogicalORExpression(JavaParser.LogicalORExpressionContext ctx) {
        return getFormattedExpression(ctx);
    }

    @Override
    public String visitUnaryNotExpression(JavaParser.UnaryNotExpressionContext ctx) {
        return ctx.children.get(0) + visit(ctx.expression());
    }

    @Override
    public String visitConstantExpression(JavaParser.ConstantExpressionContext ctx) {
        return visit(ctx.expression());
    }

    @Override
    public String visitSwitchLabel(JavaParser.SwitchLabelContext ctx) {
        StringBuilder value = new StringBuilder("case ")
                .append(visit(ctx.constantExpression()))
                .append(":");
        return value.toString();
    }

    @Override
    public String visitSwitchBlockStatementGroup(JavaParser.SwitchBlockStatementGroupContext ctx) {
        //todo: more tests using assignment after expressions are done
        //does not support "case 2: case 3:" *two cases may be in the same group*
        //does not support "default: wala 7aga"
        StringBuilder value = new StringBuilder();
        for (JavaParser.SwitchLabelContext switchLabelContext : ctx.switchLabel()) {
            value.append("\n").append(mIndentation.peek()).append(visitSwitchLabel(switchLabelContext));
            value.append("\n\tfallthrough");
        }
        mIndentation.push(mIndentation.peek() + "\t");
        value.delete(value.lastIndexOf("\n\tfallthrough"), value.length());
        for (JavaParser.BlockStatementContext blockStatementContext : ctx.blockStatement()) {
            value.append("\n").append(mIndentation.peek()).append(visitBlockStatement(blockStatementContext));
        }
        mIndentation.pop();
        return value.toString();
    }

    @Override
    public String visitSwitchBlock(JavaParser.SwitchBlockContext ctx) {
        mIndentation.push(mIndentation.peek() + "\t");
        StringBuilder value = new StringBuilder("");
        for (JavaParser.SwitchBlockStatementGroupContext switchBlockStatementGroupContext : ctx.switchBlockStatementGroup()) {
            value.append(visitSwitchBlockStatementGroup(switchBlockStatementGroupContext));
        }
        mIndentation.pop();
        value.append("\n").append(mIndentation.peek()).append("");


        return value.toString();
    }

    @Override
    public String visitSwitchStatement(JavaParser.SwitchStatementContext ctx) {
        //todo: more tests using assignment after expressions are done
        StringBuilder value = new StringBuilder("switch ")
                .append(visitParExpression(ctx.parExpression()))
                .append(" ")
                .append(visitSwitchBlock(ctx.switchBlock()));
        return value.toString();
    }

    @Override
    public String visitBreakStatement(JavaParser.BreakStatementContext ctx) {
        return "break";
    }


    private String getSwiftVariableDeclaration(String javaVariableDeclaration) {
        try {
            String[] x = javaVariableDeclaration.split(" +");
            mJavaToSwiftAssistant.addNewVariable(x[1], x[0], "");
            return x[1] + ":" + getSwiftDataType(x[0]);
        } catch (Exception e) {
            return getToDoCommentedJavaCode(javaVariableDeclaration) + "\t";

        }
    }
    private String getToDoCommentedJavaCode(ParserRuleContext ctx){
        // didn't use getText directly to get the original text with spacing.
        int a = ctx.start.getStartIndex();
        int b = ctx.stop.getStopIndex();
        Interval interval = new Interval(a,b);

        String codeCouldntConvert = ctx.start.getInputStream().getText(interval);
        if(ctx instanceof JavaParser.FieldDeclarationContext ||
                ctx instanceof JavaParser.ExpressionTemp8Context
                || ctx instanceof JavaParser.BlockStatementContext) {
            unSupportedNumberOfStatements++;
        }
        if(codeCouldntConvert.contains(System.lineSeparator()))
            return "" +System.lineSeparator() +"\t" +codeCouldntConvert+System.lineSeparator() +"*/";
        else {
            return ""+codeCouldntConvert;
        }

    }
    private String getToDoCommentedJavaCode(String string){
        // didn't use getText directly to get the original text with spacing.


        return "" + string+System.lineSeparator();


    }
    public ConvertedJavaFileData convertToSwift(JavaParser.CompilationUnitContext parseTree) {

        String swiftCode = visitCompilationUnit(parseTree);
        ConvertedJavaFileData convertedJavaFileData;
        convertedJavaFileData = new ConvertedJavaFileData();
        convertedJavaFileData.swiftCode = swiftCode;
        convertedJavaFileData.isActivity = mJavaToSwiftAssistant.isAndroidActivity();
        convertedJavaFileData.userInterfaceObjectsConnections = mJavaToSwiftAssistant.getObjectsUIIDs();
        convertedJavaFileData.layoutFile = mJavaToSwiftAssistant.getLayoutName();
        convertedJavaFileData.explicitIntents = mJavaToSwiftAssistant.getExplicitIntents();
        convertedJavaFileData.setNumberOfStatements(totalNumberOfStatements);
        convertedJavaFileData.setNumberOfStatementsTobeConvertedManually(unSupportedNumberOfStatements);
        return convertedJavaFileData;
    }
}
