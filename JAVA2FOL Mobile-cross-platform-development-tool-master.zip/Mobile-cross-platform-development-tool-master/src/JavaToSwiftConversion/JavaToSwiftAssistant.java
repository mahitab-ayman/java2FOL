package JavaToSwiftConversion;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.misc.Interval;
import androidToiOS.AndroidProject;
import java.io.*;
import java.util.*;

public class JavaToSwiftAssistant {
    /***
     *   Maps the class name to a Hashmap of functions and every function maps to arraylist of its arguments
     *   function is written in this syntax func(int,string) where int and string are java data types
     */

    private static HashMap<String, HashMap<String, ArrayList<String>>> functionArgumentNames;
    /**
     * maps the ID of an object in the layout.xml to its java object name
     * to be used later in converting the android layout to scene in IOS
     */
    private HashMap<String, String> objectsUIIDs;
    private String mJavaClassName;
    private String mJavaParentClassName;
    private static final Map<String, String> DATA_TYPES_HASH_MAP;
    private static final Map<String, String> mUserInterfaceDataTypesHashMap;
    private static final Map<String, Map<String, String>> mUserInterfaceObservers;
    private static final Map<String, Map<String, String>> JAVA_FUNCTIONS_RETURN_TYPES;
    private static final Map<String, Map<String, String>> mStaticFunctionsInSwift;
    private static final Map<String, Map<String, String>> mFunctionsInSwift;
    private ArrayList<String> targetSwiftMethods;
    //private ArrayList<String> currentSwiftImagePickers;
    private String mLayoutName;

    /**
     * this is a map to keep the mapping between ActivityResults of Intents
     */
    private HashMap<String, AndroidIntent> intentsActivityResults;
    /**
     * this is a map to keep the mapping between objectNames of Intents
     */
    private HashMap<String, AndroidIntent> currentIntents;
    /**
     * this is to map sharedPreferences to their editors
     */
    private HashMap<String, String> sharedPrefrencesEditors;
    /**
     * this stores the explicit Intents That Will Be Converted To Seague
     */
    private ArrayList<AndroidIntent> explicitIntentsOfActivity;


    /**
     * used to store objects data types Key is variable name and value is its data type and its value
     */
    private Map<String, String> mIdentifiersTypes;
    public JavaToSwiftAssistant() {
        objectsUIIDs = new HashMap<>();
        targetSwiftMethods = new ArrayList<>();
        mIdentifiersTypes = new HashMap<>();
        currentIntents = new HashMap<>();
        explicitIntentsOfActivity = new ArrayList<>();
        intentsActivityResults = new HashMap<>();
        sharedPrefrencesEditors = new HashMap<>();
        //currentSwiftImagePickers = new ArrayList<>();
    }

    static {
        functionArgumentNames = new HashMap<>();
        HashMap<String, String> temp;
        HashMap<String, Map<String, String>> temp9;
        HashMap<String, Map<String, String>> temp11;
        HashMap<String, Map<String, String>> temp3;

        HashMap<String, String> temp10;

        HashMap<String, Map<String, String>> temp5;

        Gson gson = new GsonBuilder().create();


        Reader reader = new InputStreamReader(getFileFromResources("DataTypes.json"));

        Reader reader10 = new InputStreamReader((getFileFromResources("UserInterfaceDataTypes.json")));
        Reader reader11 = new InputStreamReader((getFileFromResources("JavaFunctionsReturnTypes.json")));
        Reader reader5 = new InputStreamReader((getFileFromResources("StaticBuiltInFunctionData.json")));
        Reader reader3 = new InputStreamReader((getFileFromResources("functionsInSwift.json")));

        Reader reader9 = new InputStreamReader((getFileFromResources("UIObserverToTarget.json")));
        temp = gson.fromJson(reader, HashMap.class);
        temp5 = gson.fromJson(reader5, HashMap.class);
        temp3 = gson.fromJson(reader3, HashMap.class);

        temp9 = gson.fromJson(reader9, HashMap.class);
        temp10 = gson.fromJson(reader10, HashMap.class);
        temp11 = gson.fromJson(reader11, HashMap.class);

        DATA_TYPES_HASH_MAP = Collections.unmodifiableMap(temp);
        mUserInterfaceObservers = Collections.unmodifiableMap(temp9);
        mUserInterfaceDataTypesHashMap = Collections.unmodifiableMap(temp10);
        JAVA_FUNCTIONS_RETURN_TYPES = Collections.unmodifiableMap(temp11);
        mStaticFunctionsInSwift = Collections.unmodifiableMap(temp5);
        mFunctionsInSwift = Collections.unmodifiableMap(temp3);


    }


    public static InputStream getFileFromResources(String fileName) {

        InputStream is = JavaToSwiftAssistant.class.getClassLoader().getResourceAsStream(fileName);


        return is;
    }

    public String getParentClassName() {
        return mJavaParentClassName;
    }

    public void setClassName(String className) {
        mJavaClassName = className;
        functionArgumentNames.put(className, new HashMap<>());
    }

    public String getClassName() {
        return mJavaClassName;
    }

    public void addNewObjectId(String id, String object) {
        objectsUIIDs.put(id, object);
    }

    public void addNewFunctionDefinition(String functionDefinition) {
        HashMap<String, ArrayList<String>> currentClassFunctionMap = functionArgumentNames.get(mJavaClassName);
        String argumentString = functionDefinition.substring(functionDefinition.indexOf('(') + 1, functionDefinition.indexOf(')'));
        String functionName = functionDefinition.substring(0, functionDefinition.indexOf('('));
        //arguments contain values like x:Int
        String[] arguments = argumentString.split(",");
        ArrayList<String> argumentsVariableNamesList = new ArrayList<>();
        if (arguments.length == 0) {
            currentClassFunctionMap.put(functionName + "()", argumentsVariableNamesList);
        } else if (arguments[0].equals("")) {
            currentClassFunctionMap.put(functionName + "()", argumentsVariableNamesList);
        } else {
            functionName += "(";
            for (String s : arguments) {
                s = s.trim();
                String[] argumentNameAndType = s.split(":");
                functionName += argumentNameAndType[1];
                functionName += ",";
                argumentsVariableNamesList.add(
                        argumentNameAndType[0]);

            }
            functionName = functionName.substring(0, functionName.length() - 1);
            functionName += ")";
            currentClassFunctionMap.put(functionName, argumentsVariableNamesList);
        }
    }

    public HashMap<String, String> getObjectsUIIDs() {
        return objectsUIIDs;
    }

    public static String getSwiftDataType(String javaDataType) {
        if (javaDataType == null) return "";
        javaDataType = javaDataType.trim();
        if (javaDataType.endsWith("]")) {
            return '[' + getSwiftDataType(javaDataType.substring(0, javaDataType.indexOf('['))) + "]";
        } else if (javaDataType.contains("<")) {
            return getSwiftDataType(javaDataType.substring(0, javaDataType.indexOf("<"))) +
                    "<" + getSwiftDataType(javaDataType.substring(javaDataType.indexOf("<") + 1, javaDataType.length() - 1))
                    + ">";

        } else {
            if (DATA_TYPES_HASH_MAP.containsKey(javaDataType)) {
                return DATA_TYPES_HASH_MAP.get(javaDataType);
            } else if (mUserInterfaceDataTypesHashMap.containsKey(javaDataType)) {
                return mUserInterfaceDataTypesHashMap.get(javaDataType);
            } else if (mStaticFunctionsInSwift.containsKey(javaDataType)){
                return "";//    todo was made to handle commenting StaticBuiltInFunctions
            } else {
                try {
                    if (AndroidProject.getCurrentAndroidProject().containsClass(javaDataType))

                        return javaDataType;
                    else {
                        throw new RuntimeException("Class isn't supported");
                    }
                } catch (NullPointerException e) {
                    return javaDataType;
                }
            }

        }
    }

    public static boolean isUserInterface(String javaDataType) {
        return mUserInterfaceDataTypesHashMap.containsKey(javaDataType);
    }


    public static String getSwiftFunctionSyntax(String className, String[] arguments, String javaFunctionDefenition) {
        HashMap<String, ArrayList<String>> currentClassFunctionMap = functionArgumentNames.get(className);
        String argumentString = javaFunctionDefenition.substring(javaFunctionDefenition.indexOf('(') + 1, javaFunctionDefenition.indexOf(')'));
        String functionName = javaFunctionDefenition.substring(0, javaFunctionDefenition.indexOf('('));
        String[] argumentsTypes = argumentString.split(",");
        String swiftFunctionDefinition = functionName + "(";
        for (String argumentsType : argumentsTypes) {
            swiftFunctionDefinition += getSwiftDataType(argumentsType);
            swiftFunctionDefinition += ",";
        }
        swiftFunctionDefinition = swiftFunctionDefinition.substring(0, swiftFunctionDefinition.length() - 1);
        swiftFunctionDefinition += ")";
        ArrayList<String> argumentVariableNames = currentClassFunctionMap.get(swiftFunctionDefinition);
        functionName += "(";
        for (int i = 0; i < arguments.length; i++) {
            functionName += argumentVariableNames.get(i) + ":" + arguments[i] + " ,";
        }
        functionName = functionName.substring(0, functionName.length() - 2);
        functionName += ")";

        return functionName;
    }

    public void addParentClass(String childClass, String parentClass) {
        //todo this if to solve bug of inner classes
        if(mJavaParentClassName != null) return;
        mJavaParentClassName = parentClass;
        HashMap<String, ArrayList<String>> childClassFunctionMap = functionArgumentNames.get(childClass);
        HashMap<String, ArrayList<String>> parentClassFunctionMap = functionArgumentNames.get(parentClass);
        if (parentClassFunctionMap != null) {
            for (Map.Entry<String, ArrayList<String>> stringArrayListEntry : parentClassFunctionMap.entrySet()) {
                childClassFunctionMap.put(stringArrayListEntry.getKey(), stringArrayListEntry.getValue());
            }
        }
    }

    public static boolean isUserInterfaceAndObserverFunction(String javaDataType, String javaMethod) {

        if (mUserInterfaceObservers.containsKey(javaDataType)) {
            if (mUserInterfaceObservers.get(javaDataType).containsKey(javaMethod))
                return true;
        }
        return false;

    }
    public static boolean isSubString(String javaFunctionName){
        if(javaFunctionName.contains("substring")){
            return true;
        }
        return false;
    }

    public ArrayList<String> getTargetSwiftMethods() {
        return targetSwiftMethods;
    }

    public String getSwiftEquivalentJavaObserverCode(String swiftDataType, String javaMethod,
                                                     String functionCaller, String targetMethod, String targetMethodFormalParameters) {

        targetMethodFormalParameters = targetMethodFormalParameters.replace("(", "(_ ");
        String[] swiftStatements = mUserInterfaceObservers.get(swiftDataType).get(javaMethod).split("\n");
        String newTargetMethodName = "targetMethod" + String.valueOf(targetSwiftMethods.size());
        /*if (swiftDataType.equals("UIButton")) {
            swiftStatements[1] = swiftStatements[1].replace("targetMethod", newTargetMethodName);
            swiftStatements[0] = functionCaller + '.' + swiftStatements[0];
            swiftStatements[1] = functionCaller + '.' + swiftStatements[1];
        } else if (swiftDataType.equals("UITextField")) {
            swiftStatements[1] = swiftStatements[0].replace("targetMethod", newTargetMethodName);
            swiftStatements[0] = functionCaller + '.' + swiftStatements[0];
        }
*/
        for (int i = 0; i < swiftStatements.length; i++) {
            if (swiftStatements[i].contains("targetMethod"))
                swiftStatements[i] = swiftStatements[i].replace("targetMethod", newTargetMethodName);
            swiftStatements[i] = functionCaller + '.' + swiftStatements[i];

        }


        targetMethod = formatMethod(targetMethod);
        String targetSwiftSignature = "@objc func " + newTargetMethodName;
        if (swiftDataType.equals("UIButton")) {
            targetSwiftMethods.add(targetSwiftSignature + "(_ sender: UIButton)" + targetMethod);
        } else if (swiftDataType.equals("UITextField")) {
            targetSwiftMethods.add(targetSwiftSignature + targetMethodFormalParameters + targetMethod);
        } else if (swiftDataType.equals("UISwitch")) {
            String[] formalParametersArray = targetMethodFormalParameters.substring(2, targetMethodFormalParameters.length() - 1).split(", ");
            for (int i = 0; i < formalParametersArray.length; i++) {
                if (formalParametersArray[i].contains("Bool")) { //the boolean representing if checkbox is checked
                    String booleanName = formalParametersArray[i].substring(0, formalParametersArray[i].indexOf(":"));
                    if (targetMethod.contains(booleanName)) {
                        targetMethod = targetMethod.replace(booleanName, functionCaller + ".isOn");
                    }
                    break;
                }
            }
            targetSwiftMethods.add(targetSwiftSignature + "(" + functionCaller + " : UISwitch)" + targetMethod);
        } else if (swiftDataType.equals("UIImageView")) {
            targetSwiftMethods.add(targetSwiftSignature + "(_ sender: UIGestureRecognizer)" + targetMethod);
        }

        String output = "";
        for (int i = 0; i < swiftStatements.length; i++) {
            output += swiftStatements[i] + "\n";
        }
        output = output.substring(0, output.length() - 1);
        return output;
    }

    private static String formatMethod(String targetMethod) {
        targetMethod = targetMethod.replace("\t", "").trim();
        targetMethod = targetMethod.replace("\n", "\n\t\t");
        int lastTapIndex = targetMethod.lastIndexOf("\t");
        targetMethod = targetMethod.substring(0, lastTapIndex)
                + targetMethod.substring(lastTapIndex + 1);
        return targetMethod;
    }

    public boolean isAndroidActivity() {
        if (mJavaParentClassName == null) return false;
        return (mJavaParentClassName.equals("AppCompatActivity"));
    }

    public String getJavaDataType(String expression) {
        expression = expression.trim();
        if (isString(expression))
            return "String";
        // if it's already a saved variable then return it
        if (isVariableIdentifiedBefore(expression))
            return getVariableJavaDataType(expression);

        if (isInteger(expression)) return "int";

        if (isDouble(expression)) return "double";

        //since there's no operators overloading in java if there's any operator + - / *
        // therefore the expression is either int or double or String
        if (!isFunctionCall(expression)) {
            String[] addedparts = expression.split("[+\\-*%/]");
            if (addedparts.length > 1) {
                for (String addedPart : addedparts) {
                    addedPart = addedPart.trim();
                    if (addedPart.startsWith("\"") || addedPart.endsWith("\"") || mIdentifiersTypes.getOrDefault(addedPart, "").equals("String"))
                        return "String";

                    else if (!isInteger(addedPart) && isDouble(addedPart))
                        return "double";
                    else if (addedPart.contains("OnClickListener")){
                        return "";
                    }
                    else { // if part of the expression is a string then it must be concatenated with a string also
                        if (getJavaDataType(addedPart).equals("String")){
                            return "String";
                        }
                    }
                }
                return "int";
            }
        }

        if (expression.startsWith("R."))
            return "R";
        else if (expression.endsWith(")") && expression.contains("new")) //expression is a class creator.
            return expression.substring(0, expression.length() - 2);
        else if (isFunctionCall(expression)) {
            String[] functionCallParts = expression.split("\\.");
            String javaFunctionCaller = functionCallParts[0];
            String javaFunctionName = functionCallParts[1].substring(0, functionCallParts[1].indexOf('('));
            String argumentsPart = functionCallParts[1].substring(functionCallParts[1].indexOf('(') + 1
                    , functionCallParts[1].indexOf(')'));
            String[] javaFunctionArguments = argumentsPart.split(", *");
            StringBuilder javaArgumentsDataTypes = new StringBuilder();
            if (javaFunctionArguments.length > 0) {
                for (String javaFunctionArgument : javaFunctionArguments) {
                    javaArgumentsDataTypes.append(getJavaDataType(javaFunctionArgument));
                }
            }
            String javaFunctionSignature = javaFunctionName + '(' + javaArgumentsDataTypes + ')';
            String javaFunctionCallerDataType;
            if (isVariableIdentifiedBefore(javaFunctionCaller)) {
                javaFunctionCallerDataType = getVariableJavaDataType(javaFunctionCaller);
            } else {
                // static function
                javaFunctionCallerDataType = javaFunctionCaller;
            }
            if (JAVA_FUNCTIONS_RETURN_TYPES.containsKey(javaFunctionCallerDataType)) {
                return JAVA_FUNCTIONS_RETURN_TYPES.get(javaFunctionCallerDataType).
                        getOrDefault(javaFunctionSignature, "");
            } else {
                return JAVA_FUNCTIONS_RETURN_TYPES.get("Object").getOrDefault(javaFunctionSignature, "");
            }


        }
        if (expression.equals("null")){
            return "null";
        }
        return "";
    }

    private boolean isString(String expression) {
        return (expression.startsWith("\"") && expression.endsWith("\""));
    }

    private boolean isFunctionCall(String expression) {
        int indexOfOpeningBracket = expression.indexOf('(');
        int indexOfClosingBracket = expression.indexOf(')');
        if (indexOfOpeningBracket >= indexOfClosingBracket)
            return false;
        int tempIndex = expression.indexOf('+');
        if (((tempIndex != -1) && (tempIndex < indexOfOpeningBracket))
                || (tempIndex > indexOfClosingBracket))
            return false;
        tempIndex = expression.indexOf('-');
        if ((tempIndex != -1) && (tempIndex < indexOfOpeningBracket)
                || (tempIndex > indexOfClosingBracket))
            return false;
        tempIndex = expression.indexOf('/');
        if ((tempIndex != -1) && (tempIndex < indexOfOpeningBracket)
                || (tempIndex > indexOfClosingBracket))
            return false;

        tempIndex = expression.indexOf('*');
        if ((tempIndex != -1) && (tempIndex < indexOfOpeningBracket)
                || (tempIndex > indexOfClosingBracket))
            return false;

        return expression.contains(".") && expression.trim().endsWith(")");
    }

    private static boolean isDouble(String value) {
        try {
            Double.parseDouble(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }


    public boolean isVariableIdentifiedBefore(String variableName) {
        return mIdentifiersTypes.containsKey(variableName);
    }

    public String getVariableJavaDataType(String variableName) {
        return mIdentifiersTypes.get(variableName);
    }

    public void addNewVariable(String variableName, String javaDataType, String value) {
        mIdentifiersTypes.put(variableName, javaDataType);
    }

    private static boolean isInteger(String s) {
        return isInteger(s, 10);
    }

    private static boolean isInteger(String s, int radix) {
        if (s.isEmpty()) return false;
        for (int i = 0; i < s.length(); i++) {
            if (i == 0 && s.charAt(i) == '-') {
                if (s.length() == 1) return false;
                else continue;
            }
            if (Character.digit(s.charAt(i), radix) < 0) return false;
        }
        return true;
    }

    public static boolean containsStaticFunction(String functionCaller, String javaFunctionName) {
        if (mStaticFunctionsInSwift.containsKey(functionCaller))
            return mStaticFunctionsInSwift.get(functionCaller).containsKey(javaFunctionName);
        return false;
    }

    public static String getEquivalentSwiftForStaticMethod(String functionCaller, String javaFunctionName) {
        return mStaticFunctionsInSwift.get(functionCaller).get(javaFunctionName);
    }

    /**
     * this add function calls as variables and saves it's return types so when it's used inside another function it can
     * be converted correctly
     * e.g :   Math.pow("dav".length(),2)  -> to convert this correctly "dav".length() is saved as a variable that
     * returns int
     *
     * @param functionCallerJavaDataType
     * @param functionCaller
     * @param javaFunctionName
     * @param functionString
     */
    public void addNewVariableFunction(String functionCallerJavaDataType, String functionCaller, String javaFunctionName, String functionString) {
        if (functionCallerJavaDataType.equals("")) {
            functionCallerJavaDataType = functionCaller;
        }
        if (JAVA_FUNCTIONS_RETURN_TYPES.containsKey(functionCallerJavaDataType)) {
            if (JAVA_FUNCTIONS_RETURN_TYPES.get(functionCallerJavaDataType).containsKey(javaFunctionName)) {
                String returnTypeOfFunction = JAVA_FUNCTIONS_RETURN_TYPES.get(functionCallerJavaDataType).get(javaFunctionName);
                addNewVariable(functionString, returnTypeOfFunction, null);
            }
        }
    }

    public String getSwiftFunctionJavaReturnType(String functionCallExpression) {
        if (functionCallExpression.contains(".")) {
            String lastSwiftFunctionCall = functionCallExpression.substring(functionCallExpression.lastIndexOf('.') + 1);
            String lastJavaFunctionCall = "";
            for (Map.Entry<String, Map<String, String>> entry : mFunctionsInSwift.entrySet()) {
                for (Map.Entry<String, String> entry1 : entry.getValue().entrySet()) {
                    if (entry1.getValue().equals(lastSwiftFunctionCall)) {
                        lastJavaFunctionCall = entry1.getKey(); // getting equivalent function in java
                        break;
                    }
                }
            }
            for (Map.Entry<String, Map<String, String>> entry : JAVA_FUNCTIONS_RETURN_TYPES.entrySet()) {
                if (entry.getValue().containsKey(lastJavaFunctionCall)) {
                    return JAVA_FUNCTIONS_RETURN_TYPES.get(entry.getKey()).get(lastJavaFunctionCall); // return java function return type.
                }
            }

        }
        return "";

    }

    public void setLayoutName(String layoutName) {
        mLayoutName = layoutName;
    }

    public String getLayoutName() {
        return mLayoutName;
    }

    public void addNewIntent(String objectName, AndroidIntent androidIntent) {
        currentIntents.put(objectName, androidIntent);
        if (currentIntents.containsValue(androidIntent))
            explicitIntentsOfActivity.add(androidIntent);

    }

    public AndroidIntent getIntent(String objectName) {
        return currentIntents.get(objectName);
    }

    public ArrayList<AndroidIntent> getExplicitIntents() {
        return explicitIntentsOfActivity;
    }

    public void addNewIntentActivityResult(String requestCode, AndroidIntent intent) {
        intentsActivityResults.put(requestCode, intent);
    }

    public String createNewSwiftImagePickerFunction() {
        String function = "@IBAction func openCamera(sender: AnyObject) {\n" +
                "\tif UIImagePickerController.isSourceTypeAvailable(.camera) {\n";
        String name = "imagePicker";
        function += declareSwiftImagePicker(name) + "}";
        return function;
    }

    public String declareSwiftImagePicker(String name) {
        return "\t\tlet " + name + " = UIImagePickerController()\n" +
                "\t\t" + name + ".delegate = self\n" +
                "\t\t" + name + ".sourceType = .camera\n" +
                "\t\t" + name + ".allowsEditing = false\n" +
                "\t\tself.present(" + name + ", animated: true, completion: nil)" + "\n";
    }

    public String getOnActivityResultEquivalentCode(String methodBody) {
        String output = "";
        String[] methodBodyLines = methodBody.split("\n");
        for (Map.Entry<String, AndroidIntent> entry : intentsActivityResults.entrySet()) {
            if (entry.getValue().getmIntentAction().equals(AndroidIntent.IntentAction.IMAGE_CAPTURE)) { //check intent action type
                output += "func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {\n" +
                        "\t\timagePicker.dismiss(animated: true, completion: nil)\n";
                for (String methodBodyLine : methodBodyLines) {
                    if (methodBodyLine.contains(".image = ")) {
                        output += methodBodyLine.replaceAll(".image = (.*)", ".image = info[.originalImage] as? UIImage");
                        break;
                    }
                }
                break;
            }
        }
        return output + "}";
    }

    public String checkMultipleInheritance(String outputSwiftCode) {
        //check for multiple inheritance caused by camera intent
        for (Map.Entry<String, AndroidIntent> intent : currentIntents.entrySet()) {
            AndroidIntent.IntentAction intentAction = intent.getValue().getmIntentAction();
            //intentAction maybe null when it's explicit
            if(intentAction != null) {
                if (intentAction.equals(AndroidIntent.IntentAction.IMAGE_CAPTURE)) {
                    outputSwiftCode =
                            outputSwiftCode.replace(": UIViewController", ": UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate");
                }
            }
        }
        return outputSwiftCode;
    }



    public Boolean hasNoEquivalentFunctionInSwift(String functionCallerSwiftDataType, String javaFunctionName) {
        if (mFunctionsInSwift.get(functionCallerSwiftDataType).get(javaFunctionName) == null) {
            return true;
        }
        return false;
    }
   public void addSharedPreferencesEditor(String sharedPreferenceEditorName, String sharedPreferenceName){
       sharedPrefrencesEditors.put(sharedPreferenceEditorName, sharedPreferenceName);
   }
   public String getEditorSharedPreference(String sharedPreferenceEditorName){
       return sharedPrefrencesEditors.get(sharedPreferenceEditorName);
   }

    public String getSubStringEquivalentCode(String swiftFunctionCaller, String javaFunctionName, String[] functionArgumentsConvertedToSwift) {
        String startIndexDeclaration, endIndexDeclaration, rangeDeclaration;
        startIndexDeclaration = "let start = " + swiftFunctionCaller + ".index(" + swiftFunctionCaller+ ".startIndex, offsetBy: "
                + functionArgumentsConvertedToSwift[0] + ")\n";
        if (functionArgumentsConvertedToSwift.length == 2){
            endIndexDeclaration = "let end = " + swiftFunctionCaller + ".index(" + swiftFunctionCaller+ ".startIndex, offsetBy: "
                    + functionArgumentsConvertedToSwift[1] + ")\n";
        }
        else {
            endIndexDeclaration = "let end = " + swiftFunctionCaller + ".index(" + swiftFunctionCaller+ ".startIndex, offsetBy: "
                    + swiftFunctionCaller + ".count)\n";
        }
        rangeDeclaration = "let range = start..<end\n";
        String subStringExpression = "String("+ swiftFunctionCaller + "[range])";

        return startIndexDeclaration + endIndexDeclaration + rangeDeclaration + subStringExpression;
    }
}
