package JavaToSwiftConversion;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public  class ConvertedJavaFileData {
    public HashMap<String, String> userInterfaceObjectsConnections;
    public boolean isActivity;
    public String swiftCode;
    /**
     *  If the converted fileName is MainActivity.java then
     *  filename = MainActivity
     */
    public String fileName;
    public String layoutFile;
    public ArrayList<AndroidIntent> explicitIntents;
    private int numberOfStatementsTobeConvertedManually = 0;
    private int numberOfStatements = 0;

    public int getNumberOfStatementsTobeConvertedManually() {
        return numberOfStatementsTobeConvertedManually;
    }

    public void setNumberOfStatementsTobeConvertedManually(int numberOfStatementsTobeConvertedManually) {
        this.numberOfStatementsTobeConvertedManually = numberOfStatementsTobeConvertedManually;
    }

    public void setNumberOfStatements(int numberOfStatements) {
        this.numberOfStatements = numberOfStatements;
    }

    public int getNumberOfStatements() {
        return numberOfStatements;
    }
    public float percentageOfSuccessfulConversion(){
        return 100* (numberOfStatements-numberOfStatementsTobeConvertedManually) /(float)numberOfStatements;

    }
    public void setExplicitIntents(ArrayList<AndroidIntent> explicitIntents) {
        this.explicitIntents = explicitIntents;
    }

    public ConvertedJavaFileData(String swiftCode, HashMap<String, String> userInterfaceObjectsConnections, String outputFileName) {
        this.swiftCode = swiftCode;
        this.userInterfaceObjectsConnections = userInterfaceObjectsConnections;
        this.fileName = outputFileName;
    }

    public ConvertedJavaFileData() {
    }
}
