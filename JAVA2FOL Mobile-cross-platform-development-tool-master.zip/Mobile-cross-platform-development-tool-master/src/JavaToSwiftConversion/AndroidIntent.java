package JavaToSwiftConversion;

import UIConversion.AndroidToIOSUtility;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Objects;


public class AndroidIntent {
    private boolean isExplicitIntent;
    private String targetedActivity;
    private String currentActivity;
    private IntentAction mIntentAction;
    private String uriExpressionInSwift;
    /**
     * intent.putExtra()
     */
    private HashMap<String,String> intentExtras;
    private JavaToSwiftAssistant mJavaToSwiftAssistant = new JavaToSwiftAssistant();

    public String getCurrentActivity() {
        return currentActivity;
    }

    public void setCurrentActivity(String currentActivity) {
        this.currentActivity = currentActivity;
    }

    public boolean isExplicitIntent() {
        return isExplicitIntent;
    }

    public String getTargetedActivity() {
        return targetedActivity;
    }



    public void setTargetedActivity(String targetedActivity) {
        isExplicitIntent = true;
        if (targetedActivity.contains(".class"))
            this.targetedActivity = targetedActivity.replace(".class", "");
        else
            this.targetedActivity = targetedActivity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AndroidIntent intent = (AndroidIntent) o;
        return isExplicitIntent == intent.isExplicitIntent &&
                Objects.equals(targetedActivity, intent.targetedActivity) &&
                Objects.equals(currentActivity, intent.currentActivity);
    }

    @Override
    public int hashCode() {
        return Objects.hash(isExplicitIntent, targetedActivity, currentActivity);
    }

    public String getEquivalentSwiftCode() {
        if (isExplicitIntent)
            return "performSegue(withIdentifier: "+ "\"" + getSegueIdentifier() + "\""+", "+"sender: nil)";
        else{
            if (mIntentAction.equals(IntentAction.VIEW)){
                return "UIApplication.shared.open(URL(string:" + uriExpressionInSwift + ")! as URL, options: [:], completionHandler: nil)";
            }
            else if (mIntentAction.equals(IntentAction.DIAL)){
                uriExpressionInSwift = uriExpressionInSwift.replace(":", "://"); // in android only : is needed before number while in ios :// is needed
                return "guard let url = URL(string: " + uriExpressionInSwift + ") else { return }\n" +
                        "UIApplication.shared.open(url)\n";
            }
            else if (mIntentAction.equals(IntentAction.IMAGE_CAPTURE)){
                return mJavaToSwiftAssistant.createNewSwiftImagePickerFunction();
            }
            return "";
        }
    }

    public String getSegueDestination(){
        return AndroidToIOSUtility.getIDForViewController(targetedActivity);
    }
    public String getSegueIdentifier(){
        return "From"+getCurrentActivity()+"To"+getTargetedActivity()+"ID";
    }

    @Override
    public String toString() {
        return "AndroidIntent{" +
                "isExplicitIntent=" + isExplicitIntent +
                ", targetedActivity='" + targetedActivity + '\'' +
                ", currentActivity='" + currentActivity + '\'' +
                ", uri='" + uriExpressionInSwift + '\'' +
                '}';
    }

    public void setAction(String actionParameter) {
        if(actionParameter.equals("Intent.ACTION_VIEW"))
            mIntentAction = IntentAction.VIEW;
        else if(actionParameter.equals("Intent.ACTION_DIAL"))
            mIntentAction = IntentAction.DIAL;
        else if (actionParameter.equals("MediaStore.ACTION_IMAGE_CAPTURE")){
            mIntentAction = IntentAction.IMAGE_CAPTURE;
        }


    }

    public IntentAction getmIntentAction() {
        return mIntentAction;
    }

    public void setURI(String uri) {
        this.uriExpressionInSwift = uri;

    }


    enum IntentAction{
        VIEW,
        DIAL,
        IMAGE_CAPTURE
    }
}
