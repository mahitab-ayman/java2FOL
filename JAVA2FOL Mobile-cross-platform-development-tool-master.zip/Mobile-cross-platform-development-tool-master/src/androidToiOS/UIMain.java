package androidToiOS;

import UIConversion.StoryboardMaker;

import java.io.IOException;
import java.util.HashMap;

public class UIMain {
    public static void main(String[] args) throws IOException {
        HashMap<String,String> mHash = new HashMap<>();
        mHash.put("L","l");
        mHash.put("M","m");
        System.out.println(mHash.toString());
    }
    public static void main4(String[] args) throws IOException {
        /*String androidXML ="<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<android xmlns:android=\"http://schemas.android.com/apk/res/android\"\n" +
                "    xmlns:app=\"http://schemas.android.com/apk/res-auto\"\n" +
                "    xmlns:tools=\"http://schemas.android.com/tools\"\n" +
                "    android:layout_width=\"match_parent\"\n" +
                "    android:layout_height=\"match_parent\"\n" +
                "    tools:context=\".MainActivity\">\n" +
                "\n" +
                "    <Button\n" +
                "        android:id=\"@+id/davidbutton\"\n" +
                "        android:layout_width=\"wrap_content\"\n" +
                "        android:layout_height=\"wrap_content\"\n" +
                "        android:text=\"Button\"\n" +
                "        android:onClick=\"play\"\n" +
                "        app:layout_constraintBottom_toBottomOf=\"parent\"\n" +
                "        app:layout_constraintEnd_toEndOf=\"parent\"\n" +
                "        app:layout_constraintStart_toStartOf=\"parent\"\n" +
                "        app:layout_constraintTop_toTopOf=\"parent\" />\n" +
                "\n" +
                "</android>\n";*/
//        String androidXML = "<Button\n" +
//                "android:id=\"@+id/button1\"\n" +
//                "android:layout_width=\"110dp\"\n" +
//                "android:layout_height=\"40dp\"\n" +
//                "android:background=\"#4056FF\"\n" +
//                "android:text=\"save\"\n" +
//                "android:textColor=\"#fff\"\n" +
//                "tools:layout_editor_absoluteX=\"183dp\"\n" +
//                "tools:layout_editor_absoluteY=\"251dp\"\n" +
//                "/>";

        String inputFile;
        String outputFile;
        if (args.length == 0) {
            System.out.println("usage: convert2swift [INPUT_JAVA_FILE] [OUTPUT_SWIFT_FILE]");
            System.out.println("You must supply at least the input file");
            return;
        }
        inputFile = args[0];
        String androidXML = Main.readFile(inputFile);

        /*UIConverter uiConverter = new UIConverter("tunaController");

        XMLParser parser = new XMLParser(null);
        ANTLRInputStream input = new ANTLRInputStream(androidXML);
        XMLLexer lexer = new XMLLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        parser.setInputStream(tokens);
        ParseTree parseTree = parser.document();

        ParseTreeWalker walker = new ParseTreeWalker();
        walker.walk(uiConverter, parseTree);


        String iosStoryBoard = uiConverter.getStoryboardCode().toString();
        outputFile = inputFile.replace(".xml", "IOS.xml");

        androidToiOS.Main.writeFile(outputFile,iosStoryBoard);*/

        StoryboardMaker storyboardMaker = new StoryboardMaker();
        //storyboardMaker.addNewScene(androidXML,"tunaController", javaToSwiftConverter.getUserInterfaceObjectsConnections());
        String xmlStoryBoard = storyboardMaker.toString();
        outputFile = inputFile.replace(".xml", "IOS.xml");

        Main.writeFile(outputFile,xmlStoryBoard);
    }
}
