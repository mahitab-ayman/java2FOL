package androidToiOS;

import JavaToSwiftConversion.ConvertedJavaFileData;
import JavaToSwiftConversion.JavaToSwiftVisitor;
import UIConversion.StoryboardMaker;
import UIConversion.UIUtilites.UIUtilities;
import generatedAntlr.JavaLexer;
import generatedAntlr.JavaParser;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static androidToiOS.Main.SEPARATOR;
import static org.antlr.v4.runtime.misc.Utils.writeFile;

public class Controller {
    /**
     * @param inputDirectory
     * @param outputDirectory
     * @param produceCompleteXcodeProject
     * @throws IOException
     */
    private static DecimalFormat numberFormat = new DecimalFormat("#");

    static String convertToIOS(File inputDirectory, File outputDirectory, boolean produceCompleteXcodeProject) throws IOException {
        StringBuilder backEndResults = new StringBuilder();
        StringBuilder frontEndResults = new StringBuilder();
        AndroidProject.setUpAndroidProjectDirectory(inputDirectory);
        AndroidProject androidProject = AndroidProject.getCurrentAndroidProject();
        ArrayList<File> javaFilesArrayList = androidProject.getJavaFilesArrayList();
        ArrayList<File> xmlLayoutArrayList = androidProject.getXmlLayoutFilesArrayList();
        String swiftDirectoryPath;
        String storyboardDirectoryPath;
        if (produceCompleteXcodeProject) {
            swiftDirectoryPath = outputDirectory.getPath() + File.separator +
                    outputDirectory.getName();
            storyboardDirectoryPath = swiftDirectoryPath + File.separator + "Base.lproj";
        } else {
            swiftDirectoryPath = outputDirectory.getPath();
            storyboardDirectoryPath = swiftDirectoryPath;
        }
        StoryboardMaker storyboardMaker = new StoryboardMaker(androidProject);
        for (File androidProjectFile : javaFilesArrayList) {
            ConvertedJavaFileData convertedJavaFileData = convertJavaFile(androidProjectFile);
            //outputfilename = MainActivity
            String outputFile = swiftDirectoryPath + File.separator +
                    convertedJavaFileData.fileName + ".swift";
            Main.writeFile(outputFile, convertedJavaFileData.swiftCode);

            String outputFileName = convertedJavaFileData.fileName + ".swift";
            String outputFileWithPath = swiftDirectoryPath + File.separator +
                    outputFileName;
            Main.writeFile(outputFileWithPath, convertedJavaFileData.swiftCode);
            backEndResults.append(getconvertedFileOutputFormat(
                    androidProjectFile.getName(), outputFileName,
                    convertedJavaFileData.percentageOfSuccessfulConversion()
            ));
            // ✔
            if (convertedJavaFileData.isActivity) {
                String layoutFileName = convertedJavaFileData.layoutFile;
                if (xmlLayoutArrayList.size() > 0) {
                    File xmlFile = Main.findFileWhoseName(layoutFileName, xmlLayoutArrayList);

                    String xmlAndroidCode = Main.readFile(xmlFile);
                    storyboardMaker.addNewScene(xmlAndroidCode, convertedJavaFileData, androidProject);

                    double conversionPercentage = UIUtilities.getConversionPercentage();

                    UIUtilities.resetCounters();
                    frontEndResults.append(getconvertedFileOutputFormat(
                            convertedJavaFileData.layoutFile,
                            "Main.storyboard", conversionPercentage)
                    );
                }
            }
        }
        if (xmlLayoutArrayList.size() > 0) {
            String xmlStoryBoard = storyboardMaker.toString();
            Main.writeFile(storyboardDirectoryPath + File.separator
                            + "Main.storyboard",
                    xmlStoryBoard);
            String stringsStoryboard = storyboardMaker.getStoryboardLocalizableString();
            /***
             * Producing Main.strings
             */
            if (stringsStoryboard.length() > 0)
                Main.writeFile(storyboardDirectoryPath + File.separator
                                + "Main.strings",
                        stringsStoryboard);
        }
        produceLocalizableStrings(androidProject.getStringResources(), swiftDirectoryPath);
        //remove last new line
        return backEndResults.append(SEPARATOR).append(frontEndResults).toString();
    }

    private static String getconvertedFileOutputFormat(String originalFileName,
                                                       String fileNameAfterConversion,
                                                       double percentageOfSuccessfulConversion) {

        return originalFileName + " \u2192 " + fileNameAfterConversion + ":\t" + numberFormat.format(percentageOfSuccessfulConversion)
                + "% \u2705" + System.lineSeparator();
    }


    private static void produceLocalizableStrings(HashMap<String, String> stringResources, String swiftDirectoryPath) throws IOException {
        String appLocalizableName = stringResources.get("app_name");
        String infoPlistContent = "/* \n" +
                "  InfoPlist.strings\n" +
                "  LocalizationTutorialApp\n" +
                "\n" +
                "  Created by [USER_NAME] on YYYY/MM/DD.\n" +
                "  Copyright © YYYY [Copyrights Inc.] All rights reserved.\n" +
                "*/\n" +
                "\"CFBundleDisplayName\" = \"" + appLocalizableName + "\";\n" +
                "//\"NSHumanReadableCopyright\" = \"YYYY [Copyrights Inc.] All rights reserved.\";";
        Main.writeFile(swiftDirectoryPath + File.separator
                        + "InfoPlist.strings",
                infoPlistContent.toString());

        StringBuilder localizableFileContent = new StringBuilder();
        if (!stringResources.isEmpty()) {
            for (Map.Entry<String, String> entry : stringResources.entrySet()) {
                localizableFileContent.append("\"").append(entry.getKey()).append("\" = \"").append(entry.getValue()).append("\";\n");
            }
            Main.writeFile(swiftDirectoryPath + File.separator
                            + "Localizable.strings",
                    localizableFileContent.toString());
        }
    }

    public static ConvertedJavaFileData convertJavaFile(File javaFile) throws IOException {
        String javaCode = Main.readFile(javaFile);
        //todo to update grammar file to java8 to allow this type of
        // declaration ArrayList<String> a = new ArrayList<>();
        //this S is ath just to ignore the errors
        javaCode = javaCode.replace("<>", "<S>");
        JavaToSwiftVisitor javaToSwiftVisitor = new JavaToSwiftVisitor();
        JavaParser parser = new JavaParser(null);
        ANTLRInputStream input = new ANTLRInputStream(javaCode);
        JavaLexer lexer = new JavaLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        parser.setInputStream(tokens);
        ParseTree parseTree = parser.compilationUnit();
        ConvertedJavaFileData convertedJavaFileData = javaToSwiftVisitor.convertToSwift((JavaParser.CompilationUnitContext) parseTree);

        String outputFileName = javaFile.getName().replace(".java", "");
        convertedJavaFileData.fileName = outputFileName;
        return convertedJavaFileData;
    }


    public static void convertToSwift(String inputFile, String outputFile) throws IOException {

        ConvertedJavaFileData convertedJavaFileData = Controller.convertJavaFile(new File(inputFile));
        Main.writeFile(outputFile, convertedJavaFileData.swiftCode);

    }


}
