package androidToiOS;

import ResourcesConversion.StringsParser;
import generatedAntlr.XMLLexer;
import generatedAntlr.XMLParser;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Objects;

public  class AndroidProject {
    private ArrayList<File> javaFilesArrayList;
    private ArrayList<File> xmlLayoutFilesArrayList;
    private static final ArrayList<String> NOT_NEEDED_ANDROID_DIRECTORIES;
    private HashMap<String,String> stringsHashMap;

    private String initialActivity = "MainActivity";
    private HashSet<String> userDefinedClasses ;
    private static AndroidProject androidProject;
    public String getInitialActivity() {
        return initialActivity;
    }

    static {
        NOT_NEEDED_ANDROID_DIRECTORIES = new ArrayList<>();
        NOT_NEEDED_ANDROID_DIRECTORIES.add(".gradle");
        NOT_NEEDED_ANDROID_DIRECTORIES.add(".idea");
        NOT_NEEDED_ANDROID_DIRECTORIES.add("build");
        NOT_NEEDED_ANDROID_DIRECTORIES.add("androidTest");

        NOT_NEEDED_ANDROID_DIRECTORIES.add("test");

    }
    public AndroidProject(){
    }


    private AndroidProject(File androidProjectDirectory) throws IOException {
        javaFilesArrayList = new ArrayList<>();
        xmlLayoutFilesArrayList = new ArrayList<>();
        organizeTheProjectFilesInAndroidProject(androidProjectDirectory);
        parseAndroidManifestFile();
        getUserDefinedClasses();

        parseAndroidStringsFile();
    }

    public static void setUpAndroidProjectDirectory(File androidProjectDirectory) throws IOException {
        androidProject = new AndroidProject(androidProjectDirectory);
    }

    public static AndroidProject getCurrentAndroidProject() {
        return androidProject;
    }

    private void parseAndroidStringsFile() throws IOException {
        File stringsFile = Main.findFileWhoseName("strings.xml",xmlLayoutFilesArrayList);

        String stringsXML = Main.readFile(stringsFile);
        StringsParser stringsParser = new StringsParser();

        XMLParser parser = new XMLParser(null);
        ANTLRInputStream input = new ANTLRInputStream(stringsXML);
        XMLLexer lexer = new XMLLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        parser.setInputStream(tokens);
        ParseTree parseTree = parser.document();

        ParseTreeWalker walker = new ParseTreeWalker();
        walker.walk(stringsParser, parseTree);

        stringsHashMap = stringsParser.getStrings();
    }

    public ArrayList<File> getJavaFilesArrayList() {
        return javaFilesArrayList;
    }

    public ArrayList<File> getXmlLayoutFilesArrayList() {
        return xmlLayoutFilesArrayList;
    }
    private void getUserDefinedClasses()  {
       userDefinedClasses = new HashSet<>();
        for (File javaFile : javaFilesArrayList){
            try {
                String javaCode = Main.readFile(javaFile);
                javaCode = javaCode.replaceAll("class( *)", "class "); //remove extra space after class keyword.
                int startIndex = javaCode.indexOf(" class ");
                while (startIndex != -1){
                    try {
                        int classNameEndIndex = Math.min(javaCode.indexOf(" ", startIndex + 7), javaCode.indexOf("{", startIndex + 5));
                        String userDefinedClass = javaCode.substring(startIndex + 6, classNameEndIndex).trim();
                        //todo handle ClassName.class.fn()
                        userDefinedClasses.add(userDefinedClass);
                        startIndex = javaCode.indexOf("class", startIndex + 5);
                    } catch (Exception e) {
                        // if error happened then there's no class
                        startIndex = -1;
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }


    private void parseAndroidManifestFile() {
        File androidManifestFile = Main.findFileWhoseName("AndroidManifest.xml",
                xmlLayoutFilesArrayList);
        if(androidManifestFile!=null) {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setValidating(true);
            factory.setIgnoringElementContentWhitespace(true);
            DocumentBuilder builder = null;
            try {
                builder = factory.newDocumentBuilder();
                Document doc = builder.parse(androidManifestFile);
                NodeList activities = doc.getElementsByTagName("activity");
                for (int i = 0; i < activities.getLength(); i++) {
                    Element activity = (Element) activities.item(i);

                    NodeList intentFilters = activity.getElementsByTagName("intent-filter");
                    if (intentFilters.getLength() > 0) {
                        // since there's one intent filter tag in the
                        // activity so i will get the first element to get it

                        Element intentFilter = (Element) intentFilters.item(0);
                        NodeList categories = intentFilter.getElementsByTagName("category");
                        if (categories.getLength() > 0) {
                            Element category = (Element) categories.item(0);
                            if (category.getAttribute("android:name").equals("android.intent.category.LAUNCHER")) {
                                //removing first character since the value will be .MainActivity
                                initialActivity = activity.getAttribute("android:name").substring(1);
                            }
                        }
                    }
                }
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            } catch (SAXException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void organizeTheProjectFilesInAndroidProject(File folder) {
        for (final File fileEntry : Objects.requireNonNull(folder.listFiles())) {
            if (fileEntry.isDirectory() &&
                    !AndroidProject.NOT_NEEDED_ANDROID_DIRECTORIES.contains(fileEntry.getName())) {
                organizeTheProjectFilesInAndroidProject(fileEntry);
            } else {
                if (fileEntry.getName().endsWith(".java"))
                    javaFilesArrayList.add(fileEntry);
                else if (fileEntry.getName().endsWith(".xml")) {
                    xmlLayoutFilesArrayList.add(fileEntry);
                }
            }
        }

    }

    public HashMap<String, String> getStringResources() {
        return stringsHashMap;
    }
    public boolean containsClass(String javaDataType) {
        return userDefinedClasses.contains(javaDataType);
    }
}
