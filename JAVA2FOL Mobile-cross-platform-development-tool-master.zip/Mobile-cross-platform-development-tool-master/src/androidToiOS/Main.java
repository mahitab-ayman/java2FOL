package androidToiOS;

import org.apache.commons.io.FileUtils;

import java.io.*;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.List;

public class Main {
    // u can edit run configurations to add any java files as arguments for example src/main/java/Temp.java
    private static final String xCodeProjName = "EmptyProject";
    private static final String OPEN_INPUT_FAILED = "Couldn't read the input project directory";
    public static final char SEPARATOR = ']';

    public static void writeFile(String filePath, String content) throws IOException {
        BufferedWriter output = null;
        try {
            File file = new File(filePath);
            output = new BufferedWriter(new FileWriter(file));
            output.write(content);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (output != null) {
                output.close();
            }
        }
    }

    public static String readFile(String file) throws IOException {
        return readFile(new BufferedReader(new FileReader(file)));
    }

    public static String readFile(File file) throws IOException {
        return readFile(new BufferedReader(new FileReader(file)));
    }

    public static File findFileWhoseName(String fileName, List<File> filesArrayList) {
        for (File file : filesArrayList) {
            if (file.getName().equals(fileName))
                return file;
        }
        return null;
    }

    public static String readFile(BufferedReader reader) throws IOException {
        String line;
        StringBuilder stringBuilder = new StringBuilder();
        String ls = System.getProperty("line.separator");

        try {
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
                stringBuilder.append(ls);
            }

            return stringBuilder.toString();
        } finally {
            reader.close();
        }

    }

    public static String removeAllWhiteSpaces(String code) {
        code = code.replaceAll("\r\n", "");
        code = code.replaceAll("\n", "");
        code = code.replaceAll(" ", "");
        code = code.replaceAll("\t", "");
        return code;
    }

    public static String convertAndroidToIOSProject(File inputFileDirectory, boolean produceCompleteXcodeProject) throws IOException {
        if (!inputFileDirectory.exists() && !inputFileDirectory.isDirectory()) {
            return OPEN_INPUT_FAILED;
        }
        File outputDirectory = prepareProjectOutputDirectory(inputFileDirectory, produceCompleteXcodeProject);
        String results = Controller.convertToIOS(inputFileDirectory, outputDirectory,produceCompleteXcodeProject);
        String output = results + SEPARATOR + outputDirectory.getAbsolutePath();
        return output;
    }

    private static File prepareProjectOutputDirectory(File inputFileDirectory, boolean produceCompleteXcodeProject) throws IOException {
        File outputDirectory = null;
       if(produceCompleteXcodeProject) {
           List<File> filesInXcodeDir;
           try {
               filesInXcodeDir = Arrays.asList(new File(Main.class.getResource("/" + xCodeProjName).toURI()).listFiles());
               String inputDirectoryParent = "";
               if (inputFileDirectory.getParent() != null)
                   inputDirectoryParent = inputFileDirectory.getParent();
               String outPutDirectoryName = inputFileDirectory.getName() + " iOS Output";
               String outputDirectoryPath = inputDirectoryParent + File.separator + outPutDirectoryName;
                outputDirectory = new File(outputDirectoryPath);
                if(outputDirectory.exists()){

                    throw new RuntimeException("plz delete or remove :"+outputDirectory.getPath()+
                            ". first to complete");

                }
               outputDirectory.mkdirs();
                File swiftFilesDirectory = findFileWhoseName(xCodeProjName, filesInXcodeDir);
               File dotXcodeProjDir = findFileWhoseName(xCodeProjName+".xcodeproj", filesInXcodeDir);
               copyDirectoryAndRename(swiftFilesDirectory, outputDirectory, outPutDirectoryName);
               copyDirectoryAndRename(dotXcodeProjDir, outputDirectory, outPutDirectoryName
                       + ".xcodeproj");


           } catch (URISyntaxException | IOException e) {
               e.printStackTrace();
           }
       }
       else {
           String inputDirectoryPath = "";
           if (inputFileDirectory.getParent() != null)
               inputDirectoryPath = inputFileDirectory.getParent() + "/";
           String outputDirectoryPath = inputDirectoryPath + inputFileDirectory.getName() + " IOS Output";
           boolean mkdirsSuccessfully = new File(outputDirectoryPath).mkdirs();
           outputDirectory = new File(outputDirectoryPath);

       }
       // todo solve this bug
        // and remove that line of code workaround to delete an empty folder which was generated idk why :"D
       new File(outputDirectory.getPath()+File.separator
       +outputDirectory.getName()+File.separator+outputDirectory.getName()).delete();
        return outputDirectory;
    }

    public static void renameDirectory(File dir, String newDirName) {
        if (!dir.isDirectory()) {
            System.err.println("There is no directory @ given path");
        } else {
            File newDir = new File(dir.getParent() + File.separator + newDirName);
            boolean rename = dir.renameTo(newDir);
        }
    }

    public static File copyDirectoryToDirectory(File srcDir, File destDir) throws IOException {
        FileUtils.copyDirectoryToDirectory(srcDir,
                destDir);
        return new File(destDir.getPath() + File.separator + srcDir.getName());
    }

    public static void copyDirectoryAndRename(File srcDir,
                                              File destDir,
                                              String dirNewName) throws IOException {
        File newDir = copyDirectoryToDirectory(srcDir, destDir);
        renameDirectory(newDir, dirNewName);
    }


}