package androidToiOS;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import javax.swing.*;


public class ProjectLauncher {
    private static final boolean TESTING = false;
    private static final boolean PRODUCE_COMPLETE_XCODE_PROJECT = false;

    public static void main(String[] args) throws IOException {
        String inputDirectory = null;
        if (TESTING) {
            System.out.print("\u2192");

            System.out.print("\u2705");
            System.out.print("\u2714");


        }
        if (args.length == 0) {
            JFileChooser f = new JFileChooser();
            f.setDialogTitle("Choose Input Directory");
            f.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            f.setApproveButtonMnemonic('a');
            f.setApproveButtonToolTipText("New Approve Tool Tip");

            f.showDialog(f,"Select");

            inputDirectory = f.getSelectedFile().getPath();
        } else {
            inputDirectory = args[0];
        }
        File inputFileDirectory;
        inputFileDirectory = new File(inputDirectory);
        String printedMsg = Main.convertAndroidToIOSProject(inputFileDirectory, PRODUCE_COMPLETE_XCODE_PROJECT);
        PrintStream out = new PrintStream(System.out, true, StandardCharsets.UTF_8);

        out.println(printedMsg);


    }

}



