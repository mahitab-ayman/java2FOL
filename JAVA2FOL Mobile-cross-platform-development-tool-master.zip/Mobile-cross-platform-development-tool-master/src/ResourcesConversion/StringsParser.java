package ResourcesConversion;

import generatedAntlr.XMLParser;
import generatedAntlr.XMLParserBaseListener;

import java.util.HashMap;

public class StringsParser extends XMLParserBaseListener {
    private HashMap<String,String> mStrings;
    private String key = "";
    private String value = "";

    public StringsParser(){
        mStrings = new HashMap<>();
    }
    @Override
    public void enterElement1(XMLParser.Element1Context ctx) {
        if(ctx.Name().get(0).getText().equals("string")){
            key = ctx.attribute().get(0).STRING().getText();
            value = ctx.content().chardata().get(0).getText();
            mStrings.put(key.substring(1,key.length()-1),value);
        }
    }

    public HashMap<String, String> getStrings() {
        return mStrings;
    }
}
